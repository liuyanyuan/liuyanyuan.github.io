var config = require("../config"),
    rootPath = config.km.rootPath,
    authPath = config.auth.rootPath;
var rq = require("../utils/request");
var request = require('request');
var async = require("async");
var utilsCommon = require('../utils/common');



//获取未完成任务数
exports.getTaskCount = function(token, userId, cb) {
    rq.getData({
        url: rootPath + '/task/personal/' + userId + '/1',
        token: token
    }, function(err, result) {
        var text;
        if(result.count > 0) {
            text = result.count;
        }
        if(result.count > 100) {
            text = '100+';
        }
        cb(err, {count: text});
    });
}


//获取我的任务的回复列表
exports.getTaskReplys = function(token, id, params, cb) {

    rq.getData({
        url: rootPath + '/task/replys/' + id,
        params: params,
        token: token
    }, cb)
};
//提交回复任务
exports.postTaskReply = function(token, data, cb) {

    rq.postData({
        url: rootPath + '/task/reply',
        params: data,
        token: token
    }, function(err, body) {
        if(!err && body.code == 201) {
            data.createTime = Date.now();
            data.replyable = true;
        }
        cb(err, data);
    });
};
//删除我发起的任务
exports.deleteTask = function(token, taskId, cb) {

    rq.postData({
        url: rootPath + '/task/delete/' + taskId,
        token: token
    }, cb);
};
//新增任务
exports.addTask = function(token, data, req, cb) {

    rq.postData({
        url: rootPath + '/task/add',
        params: data,
        token: token
    }, function(err, body) {
        if(!err) {


            var userName = req.session.userName,
                title = data.title,
                message = utilsCommon.dealContent(data.message, 40).text;


            //通知执行人
            rtxPop(data.performers, '你有一条来自' + userName + '的新任务。\n任务标题：' + title + '\n任务内容：' + message, req);

            //关注的人
            rtxPop(data.followers, '你有一条来自' + userName + '的关注的任务。\n任务标题：' + title + '\n任务内容：' + message, req);

            cb(null,{success: true, data: body.data});

        } else {
            cb(err,{success: false});
        }
    })
};

//rtx弹窗通知
function rtxPop(members, msg, req) {
    if(members) {
        var receiver = [];
        members.forEach(function(member) {
            receiver.push(member.userName.split('|')[1]);
        })
        receiver.join(',');
        utilsCommon.rtxPop('km', msg + '[\n查看|' + req.headers.host + '/personal#personalNav=my-task' + ']', receiver, 0);
    }
}
//编辑任务
exports.modifyTask = function(token, data, req, cb) {


    rq.postData({
        url: rootPath + '/task/' + data.id + '/modify',
        params: data,
        token: token
    }, function(err, body) {
        if(!err) {

            var title = data.title,
                message = utilsCommon.dealContent(data.message, 40).text;
            //通知执行人
            rtxPop(data.performers, '你有一条任务被重新编辑了。\n任务标题：' + title + '\n任务内容：' + message, req);
            //关注的人
            rtxPop(data.followers, '你有一条关注的任务被重新编辑了。\n任务标题：' + title + '\n任务内容：' + message, req);
        }
        cb(err, body);
    })
}

//搜索任务
exports.searchTask = function(token, params, cb) {

    rq.getData({
        url: rootPath + '/task/search',
        params: params,
        token: token
    }, cb);
};

//个人任务
exports.getPersonalTask = function(token, userId, status, params, cb) {
    params = params;
    params.limit = 15;


    rq.getData({
        url: rootPath + '/task/personal/' + userId + '/' + status,
        token: token,
        params: params
    },cb);
}

exports.getGroupTask = function(token, sourceId, status, params, cb) {
    params.limit = 15;
    rq.getData({
        url: rootPath + '/task/group/' + sourceId + '/' + status,
        token: token,
        params: params
    }, cb);
}

//群组未完成任务
exports.getUndoneGroupTask = function(token, sourceId, params, cb) {
    params = params;
    params.limit = 15;
    rq.getData({
        url: rootPath + '/task/group/' + sourceId + '/1',
        token: token,
        params: params
    }, cb);
};

//群组已完成任务
exports.getFinishGroupTask = function(token, sourceId, params, cb) {
    params = params;
    params.limit = 15;
    rq.getData({
        url: rootPath + '/task/group/' + sourceId + '/2',
        token: token,
        params: params
    }, cb);
};

//认领任务
exports.claimTask = function(token, taskId, cb) {
    rq.postData({
        url: rootPath + '/task/' + taskId + '/claim',
        token: token
    }, cb);
}

//开始任务
exports.startTask = function(token, taskId, cb) {


    rq.postData({
        url: rootPath + '/task/' + taskId + '/start',
        token: token
    }, cb);
}

//完成任务
exports.finishTask = function(token, taskId, data, req, cb) {
    rq.postData({
        url: rootPath + '/task/' + taskId + '/finish',
        token: token
    }, function(err, body) {
        //通知审核人
        console.log(data)
        if(!err) {
            var title = data.taskTitle,
                message = utilsCommon.dealContent(data.taskMessage, 40).text;
            rtxPop(body.data, '你有一条待审核的任务。\n任务标题：' + title + '\n任务内容：' + message, req);
        }
        cb(err, body)
    });
}

//重启任务
exports.restartTask = function(token, taskId, cb) {
    rq.postData({
        url: rootPath + '/task/' + taskId + '/restart',
        token: token
    }, cb);
}

//任务审核
exports.checkTask = function(token, taskId, check, cb) {
    rq.postData({
        url: rootPath + '/task/' + taskId + '/check/' + check,
        token: token
    }, cb)
}

//任务优先级
exports.setTaskPriority = function(token, taskId, priority, cb) {
    rq.postData({
        url: rootPath + '/task/' + taskId + '/priority/' + priority,
        token: token
    }, cb);
}

exports.getGroupMembers = function(token, groupId, cb) {
    rq.getData({
        url:  rootPath + '/groups/' + groupId + '/members',
        token: token
    }, cb);
}

//分配任务
exports.allotTask = function(token, taskId, data, req, cb) {
    rq.postData({
        url: rootPath + '/task/' + taskId + '/allot',
        params: data.params,
        token: token
    }, function(err, body) {
        //通知执行人
        if(!err) {
            var title = data.rest.taskTitle,
                message = utilsCommon.dealContent(data.rest.taskMessage, 40).text;
            rtxPop(data.params.performers, req.session.userName + '给你分配了一条新任务。\n任务标题：' + title + '\n任务内容：' + message, req);
        }

        cb(err, body)
    });
}

