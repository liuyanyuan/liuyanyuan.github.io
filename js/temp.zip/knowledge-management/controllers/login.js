var request = require("request");
var config = require("../config"),
    rootPath = config.auth.rootPath;

/**
 * 登录接口
 * http://172.16.1.102:8000/#/article/52a5440d7cbabb242e000033
 */
exports.loginaction = function (req4exp, cb) {
    var reqBody = req4exp.body;
    var name = reqBody.username;
    var pwd = reqBody.password;
    var ip = req4exp.ip;

    var data = {
        useraccount: name,
        password: pwd,
        systemtype: 1,
        domain: "7road.com",
        loginip: ip
    };

    request.post({
        url: rootPath + "/login",
        json: data,
        timeout: 10000
    }, function (err, res, body) {
        if (err) {
            console.log("login error happend");
            cb(err);

        }
        else if (res.statusCode == 200) {
            req4exp.session.token = body.token;
            req4exp.session.userId = body.userId;
            req4exp.session.userName = body.name;
            req4exp.session.isInner = body.isInner
            cb(null, body);
        }
        else {
            console.log(body);
            cb(new Error(body));
        }

    })
}

/**
 * 判断用户是否登录
 * http://172.16.1.102:8000/#/article/532ba4535bb0316714000006
 */
exports.checklogin = function (req4exp, cb) {
    var token = req4exp.session.token;

    var data = {
        token: token
    };

    request.get({
        url: rootPath + "/islogin",
        qs: data,
        json: true,
        timeout: 10000
    }, function (err, res, body) {
        //console.log(res)

        if (err) {
            console.log("islogin error happend");
            cb(err);
        }
        else if (res.statusCode == 200 && body.exists == true) {
            cb(null, body);
        }
        else {
            console.log(body);
            cb(new Error(body));
        }

    })
}

/**
 * 通过RTX登录接口
 */
exports.loginByRTX = function (req4exp, useraccount, sign, ip, cb) {
    var data = {
        useraccount: useraccount,
        sign: sign,
        domain: "7road.com",
        loginip: ip
    };

    request.post({
        url: rootPath + "/gatewayauth",
        json: data,
        timeout: 10000
    }, function (err, res, body) {
        if (err) {
            console.log("login error happend");
            cb(err);
        }
        else if (res.statusCode == 200) {
            req4exp.session.token = body.token;
            req4exp.session.userId = body.userId;
            req4exp.session.userName = body.name;
            req4exp.session.isInner = body.isInner
            cb(null, body);
        }
        else {
            console.log(body);
            cb(new Error(body));
        }

    })
}
















