/**
 * Created by peng.xie on 14-1-6.
 */
var request = require("../utils/request");
var async = require("async");
var config = require("../config"),
    rootPath = config.km.rootPath;
var utilsCommon = require('../utils/common');

/**
 * 知识库首页
 */
exports.getIndexData = function (token, cb) {
    async.parallel({
        /**
         * 获取知识库分类树
         */
        tabsData: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/category",
                token: token
            }, callback);
        },
        /**
         * 获取最佳实践
         */
        bestPractice: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/best-practice",
                token: token
            }, callback);
        },
        /**
         * 获取市场战略
         */
        marketStrategy: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/market-strategy",
                token: token
            }, callback);
        },
        /**
         * 获取最新知识树
         */
        newKnowledges: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/new-knowledges",
                params: {
                    level: 1
                },
                token: token
            }, callback);
        },
        /**
         * 获取热点知识
         */
        hotKnowledges: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/hot-knowledges",
                token: token
            }, callback);
        },
        /**
         * 获取知识贡献榜和知识高分榜
         */
        rankingList: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/queryKnowledgeList",
                params: {
                    limit: 5
                },
                token: token
            }, callback);
        }
    }, cb)
};
/**
 * 最新知识树分页加载
 */
exports.getNewKnowledges = function (token, data, cb) {
    request.getData({
        url: rootPath + "/knowledge/new-knowledges",
        params: {
            level: data.level
        },
        token: token
    }, cb);
};
exports.getNewKnowledgesList = function (token, data, cb) {
    request.getData({
        url: rootPath + "/knowledge/levelknowledges",
        params: {
            level: data.level,
            page: data.page,
            limit: 10
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 10)
            };
        cb(err, body);
    });
};
/**
 * 知识库分类跳转页面
 */
exports.classifiedData = function (token, cb) {
    async.parallel({
        /**
         * 获取知识库分类树
         */
        tabsData: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/category",
                token: token
            }, callback);
        }
    }, cb)
};
/**
 * 获取分类知识库列表
 */
exports.classifiedList = function (token, id, page, cb) {
    request.getData({
        url: rootPath + "/knowledge/category-knowledge/list",
        params: {
            categoryId: id,
            page: page,
            limit: 10
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 10)
            };
        cb(err, body);
    });
};
/**
 * 市场战略列表
 */
exports.marketStrategyList = function (token, cb) {
    request.getData({
        url: rootPath + "/knowledge/market-strategy/list",
        params: {
            page: 1,
            limit: 10
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 10)
            };
        cb(err, body);
    });
};
/**
 * 最佳实践列表
 */
exports.bestPracticeList = function (token, cb) {
    request.getData({
        url: rootPath + "/knowledge/best-practice/list",
        params: {
            page: 1,
            limit: 10
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 10)
            };
        cb(err, body);
    });
};
/**
 * 玩法库首页
 */
exports.gameGuide = function (token, params, cb) {
    async.parallel({
        /**
         * 获取玩法库分类
         */
        guideCategory: function (callback) {
            request.getData({
                url: rootPath + '/knowledge/gameGuideCategory',
                token: token
            }, callback);
        },
        /**
         * 获取玩法库文档默认列表
         */
        guideDocs: function(callback){
            request.postData({
                url: rootPath + '/knowledge/listPlayingKnowledge',
                params:params,
                token: token
            }, callback);
        },
        /**
         * 获取玩法库推荐文档
         * url: rootPath + '/knowledge/gameGuide/recommendDocs',
         */
        recommendDocs: function(callback){
            request.getData({
                url: rootPath + '/knowledge/gameGuide/recommendDocs',
                token: token
            }, callback);
        },
        /**
         * 获取玩法库玩法排行
         * url: rootPath + '/knowledge/gameGuide/rankList',
         */
        rankList: function(callback){
            request.getData({
                url: rootPath + '/knowledge/gameGuide/rankList',
                token: token
            }, callback);
        },
        /**
         * 获取玩法库玩热门标签
         * url: rootPath + '/knowledge/gameGuide/hotTags',
         */
        hotTags: function(callback){
            request.getData({
                url: rootPath + '/knowledge/gameGuide/hotTags',
                token: token
            }, callback);
        }
    }, cb)
};
/**
 * 玩法库新增文档
 */
exports.uploadFiles = function(token, req, cb) {
    async.auto({
        upload: function(callback) {    //上传头像

            req.pipe(request.postData({
                url: rootPath + '/files/upload/',
                token: token
            }, callback));
        },
        add: ['upload', function(callback, result) {     //获取玩法库分类
            request.getData({
                url: rootPath + '/knowledge/gameGuideCategory',
                token: token
            }, callback);
        }]
    }, function(err, result){
        console.log(err, result);
        cb(err, result);
    });

};
/**
 * 上传知识库图片
 * @param token
 * @param req
 * @param cb
 */
exports.setKnowledgeImg = function(token, req, cb) {
    req.pipe(
        request.postData({
            url: rootPath + '/files/upload/avatar',
            token: token
        }, function(err, body) {
            console.log(body);
            if(!err && body.code == 201) {
                cb({success: true,data:body.data});
            } else {
                cb({success: false});
            }
        })
    );
};
//获取玩法库分类
exports.getCategory = function(token, cb) {
    request.postData({
        url: rootPath + '/knowledge/selCategoryTree',
        params: {
            id: 1002,
            type: 4
        },
        token: token
    }, cb);
};
//获取玩法库列表
exports.getGuideDocList = function(token, params, cb){
    request.postData({
        url:rootPath+'/knowledge/listPlayingKnowledge',
        token:token,
        params:params
    },cb);
}
/**
 * 获取玩法库
 */
exports.getGameGuideDoc = function (token, id, cb) {

    async.auto({
        docInfo: function(callback) {    //知识点信息
            request.getData({
                url: rootPath + '/knowledge/' + id,
                token: token
            }, callback)
        },
        category: ['docInfo', function(callback) {     //获取玩法库分类
            request.getData({
                url: rootPath + '/knowledge/gameGuideCategory',
                token: token
            }, callback);
        }]
    }, function(err, result){
        console.log(err, result);
        cb(err, result);
    });

}
/**
 * 热点知识列表
 */
exports.hotKnowledgeList = function (token, cb) {
    request.getData({
        url: rootPath + "/knowledge/hot-knowledge/list",
        params: {
            page: 1,
            limit: 10
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 10)
            };
        cb(err, body);
    });
};
/**
 * 分页获取知识列表
 * @param token
 * @param page  页码
 * @param type  接口类型；0：最佳实践，1：市场战略，2：热点知识
 * @param cb
 */
exports.knowledgeByPage = function (token, page, type, cb) {
    var url = rootPath;
    switch (parseInt(type)) {
        case 0:
            url += "/knowledge/best-practice/list";
            break;
        case 1:
            url += "/knowledge/market-strategy/list";
            break;
        case 2:
            url += "/knowledge/hot-knowledge/list";
            break;
    }
    request.getData({
        url: url,
        params: {
            page: page,
            limit: 10
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 10)
            };
        cb(err, body);
    });
};
/**
 * 获取知识详情
 */
exports.getKnowledgeByID = function (token, id, cb) {
    async.auto({
        knowledge: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/preview",
                params: {
                    knowledgeId: id
                },
                token: token
            }, callback)
        },
        replyList: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/reply/" + id + "/list",
                params: {
                    page: 1,
                    limit: 5
                },
                token: token
            }, callback)
        },
        myScore: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/" + id + "/getScore",
                token: token
            }, callback)
        },
        hotTags: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/gameGuide/hotTags",
                token: token
            }, callback)
        },
        author: ['knowledge', function (callback, results) {
            if (results.knowledge.data) {
                request.getData({
                    url: rootPath + "/knowledge/authors/" + results.knowledge.data.userId + "/detail",
                    token: token
                }, callback)
            }
            else {
                callback(null, null);
            }
        }]
    }, cb)
};
/**
 * 获取更多回复
 */
exports.getMoreReply = function (token, id, page, limit, cb) {
    request.getData({
        url: rootPath + "/knowledge/reply/" + id + "/list",
        params: {
            page: page,
            limit: limit
        },
        token: token
    }, cb)
};
/**
 * 获取文档下载流
 */
exports.getSWF = function (token, res, data) {
    async.auto({
        getUrl: function (callback) {
            request.getData({
                url: rootPath + '/knowledge/previewKnowledge',
                params: {
                    flag: 0,
                    id: data.fileId,
                    knowledgeId: data.knowledgeId
                },
                token: token
//                accept: "application/x-shockwave-flash"
            }, callback)
        },
        loadStream: ['getUrl', function (callback, results) {
            if (results.getUrl.data && results.getUrl.data.remoteUrl) {
                res.set('content-type','application/x-shockwave-flash');
                request.getStream({
//                    url: results.getUrl.data.remoteUrl,
//                    token: token,
//                    accept: "application/x-shockwave-flash"
//                    url: "http://192.168.1.43/M00/00/00/wKgBLFNR7t6AMMApAABNfpFPNMk127.swf"
                    url: results.getUrl.data.remoteUrl
                }).pipe(res);
            }
            else {
                utilsCommon.renderError404(res);
            }
        }]
    })
};
/**
 * 知识点评分
 */
exports.setScore = function (token, data, cb) {
    request.postData({
        url: rootPath + "/knowledge/score",
        params: {
            knowledgeId: data.knowledgeId,
            score: data.score,
            userId: data.userId
        },
        token: token
    }, cb)
}
/**
 * 知识点印象+1
 */
exports.favourEffect = function (token, data, cb) {
    request.postData({
        url: rootPath + "/knowledge/favourEffect",
        params: {
            id: data.id,
            knowledgeId: data.knowledgeId
        },
        token: token
    }, cb)
}
/**
 * 添加知识点印象
 */
exports.setEffect = function (token, data, cb) {
    request.postData({
        url: rootPath + "/knowledge/addEffect",
        params: {
            knowledgeId: data.knowledgeId,
            description: data.description
        },
        token: token
    }, cb)
}
/**
 * 知识点评论
 */
exports.setReply = function (token, data, cb) {

    request.postData({
        url: rootPath + "/knowledge/reply",
        params: {
            refId: data.knowledgeId,
            content: data.content,
            parentId: data.parentId,
            parentUserId: data.parentUserId,
            parentUserName: data.parentUserName,
            userId: data.userId,
            userName: data.userName
        },
        token: token
    }, cb)
}
/**
 * 获取文档知识点
 */
exports.getDocKnowledge = function (token, id, cb) {
    request.getData({
        url: rootPath + '/knowledge/' + id,
        token: token
    }, function (err, body) {
        cb(err, body.data);
    })
}
/**
 * 知识点搜索
 */
exports.searchByKeywords = function (token, data, cb) {
    request.getData({
        url: rootPath + "/knowledge/search",
        params: {
            keyword: data.keyword,
            page: data.page || 1,
            pagesize: 10
        },
        token: token
    }, function (err, body) {
        if (body && body.data)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.data.count / 10)
            }
        cb(err, body);
    });
};
var testUrl = 'http://172.16.8.34:8080/km';