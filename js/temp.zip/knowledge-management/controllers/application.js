var config = require('../config'),
    rootPath = config.km.rootPath,
    request = require('../utils/request');

/**
 * flappy_bird接口
 */
exports.FB_addScore = function (token, body, cb) {
    console.log(JSON.stringify(body));
    request.postData({
        url: rootPath + '/flappy_api/addScore',
        params: body,
        token: token
    }, function (err, body) {
        cb(err, body);
    });
};
exports.FB_queryTop = function (token, cb) {
    request.postData({
        url: rootPath + '/flappy_bird/queryTop',
        token: token
    }, function (err, body) {
        cb(err, body);
    });
};
exports.FB_queryTopList = function (token, cb) {
    request.postData({
        url: rootPath + '/flappy_bird/queryTopList',
        token: token
    }, function (err, body) {
        cb(err, body);
    });
};