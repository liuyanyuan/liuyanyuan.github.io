var rq = require('../utils/request');
var async = require('async');
var config = require('../config');
var rootPath = config.km.rootPath;
var authPath = config.auth.rootPath;

/**
 * 加载动态 √
 * @param token
 * @param data
 * @param cb
 */
exports.getMoreMsg = function(token, id, type, params, cb) {
    params = params || {};
    params.limit = 15;

    var url = {
        0: rootPath + '/messages',      //全部动态
        1: rootPath + '/messages/user/message/' + id,      //消息
        2: rootPath + '/messages/user/' + id   //某个人的动态
    };
    async.auto({
        trends: function(callback) {
            rq.getData({
                url: url[type],
                params: params,
                token: token
            }, function(err, body) {
                if(!err && body) {
                    if(body.data) {
                        if(body.data.length > 0) {
                            body.max = body.data[body.data.length - 1].messageId;
                        }else {
                            body.max = 'false';
                        }
                    }
                }
                callback(err, body);
            });
        },
        unreadMsg: function(callback) {
            rq.getData({
                url: rootPath + '/messages/user/count/' + id,
                token: token
            }, function (err, result) {
                var text;
                console.log(result)
                if(result.data > 0) {
                    text = result.data;
                }
                if(result.data > 100) {
                    text = '100+';
                }
                callback(err, {count: text});
            })
        }
    }, cb);
}
//获取某个人动态
exports.getUserTrends = function(token, userId, params, cb) {
    params = params || {};
    params.limit = 15;
    rq.getData({
        url: rootPath + '/messages/user/' + userId,
        params: params,
        token: token
    }, function(err, body) {

        if(!err && body) {
            if(body.data) {
                if(body.data.length > 0) {
                    body.max = body.data[body.data.length - 1].messageId;
                }else {
                    body.max = 'false';
                }
            }
        }
        cb(err, body);
    })
}

/**====================================================================================
 * 获取个人动态
 * @param token
 * @param id
 * @param cb
 ====================================================================================*/
exports.getUserInfo = function(token, id, cb) {
    async.auto({
        //个人姓名
        userInfo: function(callback) {
            var url = rootPath + '/users/' + id;

            rq.getData({
                url: url,
                token: token
            }, callback);
        },
        //个人积分和经验
        //totalScore: 96, totalExp: 1600
        scoreAndExp: function(callback) {
            rq.getData({
                url: rootPath + '/users/' + id + '/scoreAndExp',
                token: token
            }, function(err, result) {
                if(err) {
                    result = {data: 0}
                }
                callback(err, result)
            });
        }
    }, cb);
};

/**
 * 获取积分兑换
 * @param token
 * @param params
 * @param cb
 */
exports.getEcList = function(token, params, cb) {
    rq.getData({
        url: rootPath + '/score/exchange/list',
        params: params,
        token: token
    }, function(err, result) {
        if(!err) {
            result.data.forEach(function(item) {
                if(item.scaleImgs) {
                    item.img = item.scaleImgs.split(',')[0];
                } else if(item.imgs) {
                    item.img = item.imgs.split(',')[0];
                } else {
                    item.img = 0;
                }
            })
        }
        cb(err, result);
    });
}

/**
 * 查询获取动态 √
 */
exports.getSearchTrend = function(token, params, cb) {
    params.limit = 15;

    rq.getData({
        url: rootPath + '/messages/search',
        params: params,
        token: token
    },function(err, body) {
        if(!err) {
            if(body.data.length > 0) {
                body.max = body.data[body.data.length - 1].id
            }else {
                body.max = 'false';
            }
        }
        cb(err, body);
    });


}

/**
 * 踩和顶 回答
 * @param token
 * @param data
 * @param cb
 */
exports.voteAnswer = function(token, data, cb) {
    rq.putData({
        url: rootPath + '/comments/'+ data.commentId +'/vote?updown=' + data.updown,
        token: token
    }, function(err, body) {
        if(!err) {
            cb({success: true});
        } else {
            cb({success: false});
        }

    })


}

//动态赞
exports.applaudTrend = function(token, params, cb) {
    var url = {
        1: rootPath + '/knowledge/applaud?knowledgeId=' + params.knowledgeId  //知识点的赞
    }
    rq.postData({
        url: url[params.type],
        token: token
    }, function(err, body) {
        var result;

        if(!err) {
            if(body.message) {
                result = {success: false, message: body.message};
            } else {
                result = {success: true};
            }
        }
        cb(err, result);
    });
}
//动态评论
exports.answerTrend = function(token, userId, data, cb) {

    if(data.type == 4) {
        data.params.userId = userId;
    }
    var url = {
        1: rootPath + '/knowledge/reply',   //知识库
        4: rootPath + '/group/'+ data.params.topicId  + '/comments/'
    };
    rq.postData({
        url: url[data.type],
        token: token,
        params: data.params
    }, cb);
}

/**
 * 点赞
 * @param token
 * @param id
 * @param cb
 */
exports.favQues = function(token, data, cb) {
    var url = {
        1: rootPath + '/messages/applaud/' + data.id,  //微博 已不需要
        2: rootPath + '/questions/' + data.id +  '/favour',    //问答
        3: rootPath, //知识库
        4: rootPath   //群组话题
    }

   rq.putData({
       url: url[data.type],
       token: token
   }, function(err, body) {
       if(body.code == 204) {
           cb({success: true})
       } else {
           cb({success: false})
       }
   })

};

/**
 * 获取回复列表
 * @param token
 * @param data
 * @param cb
 */
exports.getMsgReply = function(token, data, cb) {

    var url = {
        1: rootPath + '/knowledge/reply/' + data.id + '/list',  //知识库
        2: rootPath + '/questions/' + data.id + '/comments',    //问答
        3: rootPath, //知识库
        4: rootPath + '/groups/topics/'+ data.id +'/comments'   //群组话题
    }

    rq.getData({
        url: url[data.type],
        token: token,
        params: {limit: 5, page: 1}
    }, function(err, body) {

        cb(err, body);
    });
};

/**
 * 添加一条回复
 * @param token
 * @param data
 * @param cb
 */
exports.addMsgReply = function(token, userId, data, cb) {
    var url = {
        1: rootPath + "/knowledge/reply",    //知识库
        2: rootPath + '/questions/'+ data.info.questionId + '/comments/',   //问答
        3: rootPath + '/knowledge/reply/' + data.info.questionId,   //知识库
        4: rootPath + '/group/'+ data.info.topicId  + '/comments/'   //群组话题
    }

    var params = {};
        params = data.info;
        params.userId = userId;
    rq.postData({
        url: url[data.type],
        token: token,
        params: params
    }, cb);
};


/**
 * 进入个人主页获取信息
 * @param token
 * @param id
 * @param cb
 */
exports.getPersonal = function(token, id, cb) {
    async.auto({
        userInfo: function(callback) {      //个人信息
            rq.getData({
                url: rootPath + '/users/' + id,
                token: token
            }, callback);

        },
        basicInfo: function(callback) {     //用户基本信息


            var url = authPath + '/user/' + id;
            rq.getData({
                url: url,
                params: {token: token}
            }, callback);
        },
        knowledgeLevelCount: function(callback) {
            rq.getData({
                url: rootPath + '/knowledge/personal/' + id + '/knowledgeLevelCount',
                token: token
            }, callback);
        }
    }, cb);
};

/**
 * 编辑我的资料获取用户资料
 * @param token
 * @param id
 * @param cb
 */
exports.getUsersInfo = function(token, id, cb) {
    async.auto({
        basicInfo: function(callback) {     //用户基本信息
            var url = authPath + '/user/' + id;
            rq.getData({
                url: url,
                params: {token: token}
            }, callback);
        },
        restInfo: function(callback) {  //用户其他信息
            var url = rootPath + '/users/' + id;

            rq.getData({
                url: url,
                token: token
            }, callback);
        }
    }, cb);
};
//更新我的zi
exports.updateUsersInfo = function(token, id, data, cb) {
    var restUrl = rootPath + '/users/update',
        basicUrl = authPath + '/user/' + id + '/update',
        url = null;
    if(data.type == 1) {
        url = restUrl;
        data.data.id = id;
    } else if(data.type == 0) {
        url = basicUrl;
        if(data.data.birthday) {
            var birthday = +data.data.birthday;
            data.data = {birthday: birthday};
        }
    }
    rq.postData({
        url: url,
        token: token,
        params: data.data
    }, function(err, body) {

        if(err) {
            cb({success: false});
        } else {
            cb({success: true});
        }
    });
};

/**
 * 保存头像
 * @param token
 * @param id
 * @param req
 * @param cb
 */
exports.uploadAvatar = function(token, id, req, cb) {

    async.auto({
        upload: function(callback) {    //上传头像
            req.pipe(rq.postData({
                url: rootPath + '/files/upload/avatar',
                token: token
            }, function(err, body) {
                callback(err, body);
            }));
        },
        update: ['upload', function(callback, result) {     //更新个人信息 头像ID
            rq.postData({
                url: rootPath + '/users/update',
                token: token,
                params: {headId: result.upload.data, id: id}
            }, callback);
        }]
    }, function(err, results) {

        if(!err && results.upload.code == 201 && results.update.data) {
            cb({success: true, data: results.upload.data});
        } else {
            cb({success: false});
        }
    });
};

/**
 * 修改用户密码
 * @param token
 * @param id
 * @param data
 * @param cb
 */
exports.updatePassword = function(token, id, data, cb) {
    data.token = token;
    var url = authPath + '/user/' + id + '/update/password';
    rq.postData({
        url: url,
        token: token,
        params: data
    }, function(err, body) {
        if(err) {
            cb({success: false, data: body});
        } else {
            cb({success: true, data: body});
        }
    });
};

//我的问答
exports.getQuestions = function(token, id, data, cb) {
    async.parallel({
        publishQa: function(callback) {
            var id = 888888;
            rq.getData({
                url: rootPath + '/users/' + id + '/questions',
                token: token,
                params: data
            }, callback);
        },
        favouriteQa: function(callback) {
            rq.getData({
                url: rootPath + '/users/' + id + '/favourite/questions',
                token: token,
                params: data
            }, callback);
        },
        replyQa: function(callback) {
            rq.getData({
                url: rootPath + '/users/' + 888888 + '/reply/questions',
                token: token,
                params: data
            }, callback);
        }
    }, function(err, results) {
        cb(err, results);
    });
};

exports.getMoreQuestions = function(token, id, type, params, cb) {

    var url = {
        0: rootPath + '/users/' + 888888 + '/questions',    //我的问题
        1: rootPath + '/users/' + id + '/reply/questions',   //我的问答
        2: rootPath + '/users/' + 888888 + '/favourite/questions'  //我收藏的问答

    }
    rq.getData({
        url: url[type],
        token: token,
        params: params
    }, cb);
};

//删除我的问答
exports.deleteQuestion = function(token, userId, data, cb) {

    var url = {
        0: rootPath + '/questions/' + data.id,    //我的问题
        1: rootPath + '/comments/' + data.id,   //我的问答
        2: rootPath + '/user/' + userId + '/collect'  //我收藏的问答
    };
    parmas = null;
    if(data.type == 2) {
        var params = {referenceId: data.id, type: data.type};
    }


    rq.delData({
        url: url[data.type],
        token: token,
        params: params
    }, function(err, body) {
        if(err) {
            cb({success: false});
        } else {
            cb({success: true});
        }
    });

}




//个人知识库
exports.getPersonalKnowledge = function(token, params, cb) {

    rq.getData({
        url: rootPath + '/knowledge/' + params.attachedType  + '/' + params.attachedId  +'/list',
        token: token,
        params: {id: params.catalog}
    }, cb);
};
//获取知识库分类
exports.getCategory = function(token, cb) {


    rq.getData({
        url: rootPath + '/knowledge/category',
        token: token
    }, cb)
};

//新增知识点
exports.addKnowledge = function(token, params, cb) {

    async.auto({
        addFile: function(callback) {
            rq.postData({
                url: rootPath + '/knowledge/add',
                token: token,
                params: params.knowledge
            }, callback);
        },
        getFile: ['addFile', function(callback, result) {

            if(!result.addFile.message || result.addFile.message == 'true') {
                rq.getData({
                    url: rootPath + '/knowledge/' + result.addFile.data.id,
                    token: token
                }, callback)
            } else {
                callback(null, {message: '上传知识点失败，请填写完整信息并重新上传。'})
            }

        }]
    }, cb)
}
//更新知识点
exports.updateKnowledge = function(token, params, knowledgeId, cb) {

    rq.postData({
        url: rootPath + '/knowledge/update/' + knowledgeId,
        token: token,
        params: params.knowledge
    }, function(err, results) {

        var data = {};
        if(!results.message || results.message == 'true') {
            data.success = true;
        } else {
            data.success = false;
            data.message = '修改知识点失败，请填写完整信息并重新上传。';
        }
        cb(err, data);
    });

}
//新增目录
exports.addCatalog = function(token, params, cb) {

    rq.postData({
        url: rootPath + '/knowledge/catalog/add',
        token: token,
        params: params
    }, function(err, body) {
        var result;
        if(!err) {
            if(body.message) {
                result = {success: false, message: body.message};
            } else {
                result = {success: true, data: body.data};
            }
        }
        cb(err, result);
    });
};
//修改目录
exports.editCatalog = function(token, data, cb) {

    rq.postData({
        url: rootPath + '/knowledge/catalog/update/' + data.catalog.flag + '/' + data.catalog.id,
        token: token,
        params: data.params
    }, function(err, body) {
        var result;

        if(!err) {
            if(body.message) {
                result = {success: false, message: body.message};
            } else {
                result = {success: true};
            }
        }
        cb(err, result);
    })
};
//删除目录
exports.deleteCatalog = function(token, data, cb) {

    var url = '';

    if(data.catalog.flag == 0) {
        url = rootPath + '/knowledge/delete/' + data.catalog.id;
    } else {
        url = rootPath + '/knowledge/catalog/delete/' + data.catalog.id;
    }

    rq.delData({
        url: url,
        token: token
    }, function(err, body) {

        var data = {};
        if(!err && body) {
            if(body.message) {
                data.success = false;
                data.message = body.message;
            } else {
                data.success = true;
            }
        }
        cb(err, data);
    })


}

exports.previewKnowledge = function(token, id, cb) {

    rq.getData({
        url: rootPath + "/knowledge/preview",
        params: {
            knowledgeId: id
        },
        token: token
    }, cb);
}

exports.downKnowledge = function(token, catalog, cb) {
    rq.getData({
        url: rootPath + '/knowledge/download/' + catalog.flag + '/' + catalog.id,
        token: token
    }, function(err, body) {

    })
}
//目录树
exports.getCatalogTree = function(token, params, cb) {

    rq.getData({
        url: rootPath + '/knowledge/catalog',
        params: params,
        token: token
    }, cb)
}
//我关注的人
exports.getFollowing = function(token, userId, params, cb) {
//    var rootPath = 'http://172.16.8.14:8080/km';

    params.limit = 18;
    rq.getData({
        url: rootPath + '/users/' + userId + '/following',
        params: params,
        token: token
    }, cb);
};

exports.addFollow = function(token, id, params, cb) {
//    var rootPath = 'http://172.16.8.14:8080/km';
    rq.postData({
        url: rootPath + '/users/' + id + '/follow/',
        params: params,
        token: token
    }, cb);
}

exports.cancelFollow = function(token, id, cb) {
//    var rootPath = 'http://172.16.8.14:8080/km';

    rq.delData({
        url: rootPath + '/users/' + id + '/follow/',
        token: token
    },cb);
}

exports.getApply = function(token, cb) {
    rq.getData({
        url: rootPath,
        token: token
    },cb);
};



exports.uploadFiles = function(token, req, cb) {
    req.pipe(rq.postData({
        url: rootPath + '/files/upload/',
        token: token
    }, function(err, body) {
        cb(err, body);
    }));
};



exports.addApply = function(token, params, cb) {

    rq.postData({
        url: rootPath,
        token: token,
        params: params
    }, cb);
}

//获取我的群组
exports.getMyGroup = function(token, userId, params, cb) {
    rq.getData({
        url: rootPath + '/users/'+userId+'/group/',
        token: token,
        params: params
    }, cb);
}

/**
 * 获取文档知识点
 */
exports.getDocKnowledge = function (token, id, cb) {

    rq.getData({
        url: rootPath + '/knowledge/' + id,
        token: token
    }, function (err, body) {

        cb(err, body.data);
    })
}



