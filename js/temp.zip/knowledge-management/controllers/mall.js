var config = require("../config"),
    rootPath = config.km.rootPath;
var rq = require("../utils/request");
var async = require("async");
var fs = require('fs');
var path = require('path');

//积分兑换列表
exports.getExchangeList = function(token, id, params, cb) {
    async.auto({
        //个人积分和经验
        //totalScore: 96, totalExp: 1600
        scoreAndExp: function(callback) {
            rq.getData({
                url: rootPath + '/users/' + id + '/scoreAndExp',
                token: token
            }, callback);
        },

        exchangeList: function(callback){
            rq.getData({
                url: rootPath + '/score/exchange/list',
                token: token,
                params : params
            }, callback);
        }
    }, cb);
}

//积分兑换 物品详情
exports.getExchangeItemDetail = function(token, id, cb) {
    rq.getData({
        url: rootPath + '/score/item/' + id,
        token: token
    }, cb);
}


//积分兑换 兑换按钮
exports.exchangeItemBuy = function(token, id, params, cb) {

    rq.getData({
        url: rootPath + '/score/exchange/buy/' + id,
        token: token,
        params : params
    }, cb);
}

//积分竞拍 竞拍按钮
exports.auctionItemBuy = function(token, id, params, cb) {
    rq.getData({
        url: rootPath + '/score/auction/buy/' + id,
        token: token,
        params : params
    }, cb);
}

//竞拍历史
exports.getAuctionHistory = function(token, cb) {
    rq.getData({
        url: rootPath + '/score/auction/history',
        token: token
    }, cb);
}

//热门兑换
exports.getExchangeHot = function(token, cb) {
    rq.getData({
        url: rootPath + '/score/exchange/recommend',
        token: token
    }, cb);
}

//获取 正在 积分竞拍 的id
exports.getNowAuctionItemId = function(token, cb) {
    rq.getData({
        url: rootPath + '/score/auction/item/now',
        token: token
    }, cb);
}

//积分竞拍 商品详情
exports.getAuctionItemDetail = function(token, id, cb) {
    rq.getData({
        url: rootPath + '/score/auction/' + id,
        token: token
    }, cb);
}


//积分历史首页
exports.getUserScore = function(token, userId, cb) {
    var params = {
        page: 1,
        limit: 12
    };
    async.auto({
        scoreAndExp: function(callback) {   //个人积分和经验
            rq.getData({
                url: rootPath + '/users/' + userId + '/scoreAndExp',
                token: token
            }, function(err, result) {
                if(err) {
                    result = {data: 0}
                }
                callback(err, result)
            });
        },
        scoreHistory: function(callback) {  //积分历史
            rq.getData({
                url: rootPath + '/users/' + userId + '/score/history/search',
                token: token,
                params: params
            }, callback);
        }
    }, function(err, result) {
        if(!err) {
            result.scoreHistory.limit = params.limit;
        }
        cb(err, result);
    })
};

//积分历史分页获取
exports.getScoreHistory = function(token, userId, params, cb) {
    params.limit = 12;
    rq.getData({
        url: rootPath + '/users/' + userId + '/score/history/search',
        token: token,
        params: params
    },cb);
};

//积分历史搜索
exports.searchScore = function(token, userId, params, cb) {
    rq.getData({
        url: rootPath + '/users/' + userId + '/score/history/search',
        token: token,
        params: params
    }, cb);
}