/**
 * Created by peng.xie on 14-1-6.
 */
var request = require("../utils/request");
var async = require("async");
var config = require("../config"),
    rootPath = config.km.rootPath,
    rootPath2 = config.auth.rootPath;
var utilsCommon = require('../utils/common');

/**
 * 问答首页
 */
exports.getIndexData = function (token, cb) {
    async.parallel({
        /**
         * 获取问答分类树
         */
        tabsData: function (callback) {
            request.getData({
                url: rootPath + "/questions/category",
                token: token
            }, callback);
        },
        /**
         * 1：本周问答之星；2：本周采纳排行；3：本周被赞榜；4：本周回答数榜
         */
        userVoInfo: function (callback) {
            request.getData({
                url: rootPath + "/users/selectUserVoInfoByExample",
                params: {
                    source: '1,2,3,4'
                },
                token: token
            }, callback);
        },
//        /**
//         * 高分悬赏
//         */
//        hideScore: function (callback) {
//            request.getData({
//                url: rootPath + "/questionsList",
//                params: {
//                    page: 1,
//                    sortBy: 'score desc',
//                    limit: 6
//                },
//                token: token
//            }, function (err, body) {
//                if (body && body.data) {
//                    body.paging = {
//                        limit: 5,
//                        total: Math.ceil(body.count / 6),
//                        thisPage: 1
//                    };
//                }
//                callback(err, body);
//            });
//        },
//        /**
//         * 热点问题
//         */
//        hotSpot: function (callback) {
//            request.getData({
//                url: rootPath + "/questions/getHotSpotQuestions",
//                params: {
//                    page: 1,
//                    limit: 6
//                },
//                token: token
//            }, function (err, body) {
//                if (body && body.data) {
//                    body.paging = {
//                        limit: 5,
//                        total: Math.ceil(body.count / 6),
//                        thisPage: 1
//                    };
//                }
//                callback(err, body);
//            });
//        },
//        /**
//         * 常见问题
//         */
//        specialColumn: function (callback) {
//            request.getData({
//                url: rootPath + "/questions/getColumnQuestions",
//                params: {
//                    page: 1,
//                    limit: 6
//                },
//                token: token
//            }, function (err, body) {
//                if (body && body.data) {
//                    body.paging = {
//                        limit: 5,
//                        total: Math.ceil(body.count / 6),
//                        thisPage: 1
//                    };
//                }
//                callback(err, body);
//            });
//        },
        /**
         * 热搜关键字
         */
        hotKey: function (callback) {
            request.getData({
                url: rootPath + "/questions/hotKey",
                token: token
            }, callback);
        }
    }, cb)
};

/**
 * 问答首页分页列表
 */
exports.getQuestionList = function (token, data, cb) {
    //data.type,0:待解答问题,1:高分悬赏
    var url = {
        0: rootPath + "/questionsList/unresolved",
        1: rootPath + "/questionsList"
    }
    var params = {
        page: data.page,
        limit: 6
    }
    if (data.type == 1) {
        params.sortBy = 'score desc';
    }

    request.getData({
        url: url[data.type],
        params: params,
        token: token
    }, function (err, body) {
        if (body && body.data) {
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / 6),
                thisPage: data.page
            };
        }
        cb(err, body);
    });
}

/**
 * 问题详情
 */
exports.getdetailedQuestion = function (token, qid, cb) {
    async.parallel({
//        /**
//         * 获取问答分类树
//         */
//        tabsData: function (callback) {
//            request.getData({
//                url: rootPath + "/questions/category",
//                token: token
//            }, callback);
//        },
        /**
         * 问题详情
         */
        detailedQuestion: function (callback) {
            request.getData({
                url: rootPath + "/getQuestions/" + qid.toString(),
                params: {
                    page: 1,
                    limit: 6,
                    sortBy: 'id desc'
                },
                token: token
            }, function (err, body) {
                if (body && body.data) {
                    body.data.thisPage = 1;
                    body.data.thisPageSize = 6;
                    body.data.totalPage = Math.ceil(body.data.answerCount / 6);
                }
                callback(err, body);
            });
        }
    }, cb)
};
/**
 * 获取问答分类
 */
exports.getQuestionSort = function (token, cb) {
    async.parallel({
        /**
         * 获取问答分类树
         */
        tabsData: function (callback) {
            request.getData({
                url: rootPath + "/questions/category",
                token: token
            }, callback);
        }
    }, cb)
};
/**
 * 获取更多答案
 */
exports.getMoreAnswers = function (token, data, cb) {
    request.getData({
        url: rootPath + "/getQuestions/" + data.questionId.toString(),
        params: {
            page: data.page,
            limit: 6,
            sortBy: 'id desc'
        },
        token: token
    }, function (err, body) {
        if (body) {
            var answers = {
                'isBest': false,
                'hasAdopted': body.data.bestAnswer == null ? false : true,
                'questionId': body.data.id,
                'score': body.data.score,
                'data': body.data.answerList};
        }
        cb(err, answers);
    });
};
/**
 * 设置为采纳答案
 */
exports.adoptedAnswer = function (token, data, cb) {
    request.putData({
        url: rootPath + "/comments/" + data.userId.toString() + "/best-answer",
        params: data,
        token: token
    }, function (err, result) {
        if (result && result.message) {
            cb(null, {message: result.message});
        } else {
            cb(err, {code: 200});
        }
    });
}
/**
 * 查询自己的答案
 */
exports.searchMyAnswer = function (token, data, cb) {
    request.getData({
        url: rootPath + "/questions/myAnswer",
        params: data,
        token: token
    }, cb);
}
/**
 * 发起问题
 */
exports.setQuestion = function (token, data, userId, req, cb) {
    request.postData({
        url: rootPath + "/addQuestion",
        params: {
            content: data.question,
            appendContent: data.content,
            category: data.sortID,
            userId: userId,
            score: data.score,
            anonymous: data.type,
            inviteUser: data.inviteID
        },
        token: token
    }, function (err, body) {
        if (body && body.data) {
            var msg = '你被邀请回答问题。\n问题：' + data.question;
            utilsCommon.rtxPop('km', msg + '[\n查看|' + req.headers.host + '/question/detailedQuestion/' + body.data.id + ']', data.inviteName, 0);
        }
        cb(err, body);
    });
};
/**
 * 修改问题
 */
exports.updateQuestion = function (token, body, cb) {
    var data = {};
    if (body.content) {
        data.appendContent = body.content;
    }
    if (body.score) {
        data.score = body.score;
    }
    request.putData({
        url: rootPath + "/question/" + body.questionId.toString() + "/update",
        params: data,
        token: token
    }, function (err, result) {
        if (result && result.message) {
            cb(null, {message: result.message});
        } else {
            cb(err, {code: 200});
        }
    });
}
/**
 * 获取分类知识库列表
 */
exports.classifiedList = function (token, data, cb) {
    request.getData({
        url: rootPath + "/questionsList",
        params: {
            page: data.page,
            limit: data.limit,
            sortBy: 'id desc',
            categoryId: data.categoryId
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                limit: 5,
                total: Math.ceil(body.count / data.limit)
            };
        cb(err, body);
    });
}
/**
 * 通过关键字查询问题
 */
exports.searchByKeywords = function (token, data, cb) {
    request.getData({
        url: rootPath + "/questionsList",
        params: {
            page: data.page || 1,
            keyword: data.question,
            limit: data.pageSize || 15,
            sortBy: data.sortBy || 'CREATE_TIME desc'
        },
        token: token
    }, function (err, body) {
        if (body)
            body.paging = {
                total: Math.ceil(body.data.count / (data.pageSize || 15)),
                limit: 5,
                pageSize: data.pageSize || 15,
                sortBy: data.sortBy || 'CREATE_TIME desc'
            }
        cb(err, body);
    });
};

//**********************************************************
/**
 * 获取选择用户/群组模板
 */
exports.getOrganization = function (token, data, cb) {
    var type = ",";
    //若不传模板类型，则默认为选择用户模板
    if (data) {
        if (data.type && data.type.length > 0) {
            data.type.forEach(function (item) {
                type += item + ",";
            });
        }
        else {
            type += "person,"
        }
    }
    else {
        type += "person,"
    }
    async.parallel({
        /**
         * 获取组织结构
         */
        persons: function (callback) {
            if (type.indexOf(",person,") >= 0) {
                request.getData({
                    url: rootPath + "/organization/" + config.km.organizationID,
                    token: token
                }, callback);
            }
            else {
                callback(null, null);
            }
        },
        /**
         * 获取群组信息
         */
        groups: function (callback) {
            if (type.indexOf(",group,") >= 0) {
                request.getData({
                    url: rootPath + "/groups/all",
                    params: {
                        sortBy: "create_Time",
                        order: "desc"
                    },
                    token: token
                }, callback);
            }
            else {
                callback(null, null);
            }
        }
    }, cb)
};
/**
 * 通过组织结构ID获取用户
 */
exports.getUsersByGroup = function (token, data, cb) {
    request.getData({
        url: rootPath + "/organization/" + data.groupID + "/member",
        token: token
    }, cb);
};
/**
 * 模糊搜索组织结构用户
 */
exports.getUsersByName = function (token, data, cb) {
    request.getData({
        url: rootPath2 + "/organization/member/search",
        params: {
            groupId: config.km.organizationID,
            username: data.name
        },
        token: token
    }, cb);
};
//**********************************************************