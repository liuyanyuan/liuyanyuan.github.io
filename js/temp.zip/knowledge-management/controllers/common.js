var config = require('../config'),
    rootPath = config.km.rootPath,
    request = require('../utils/request');
var async = require("async");
var utilsCommon = require('../utils/common');

//获取头像
exports.getAvatar = function (token, id, res) {
    async.auto({
        getUrl: function (callback) {
            request.getData({
                url: rootPath + '/user/' + id + '/avatar',
                token: token
            }, callback)
        },
        loadStream: ['getUrl', function (callback, results) {
            if (results.getUrl.data && results.getUrl.data.remoteUrl) {
                request.getStream({
                    url: results.getUrl.data.remoteUrl
                }).pipe(res);
            }
            else {
                utilsCommon.renderError404(res);
            }
        }]
    })
}

//获取文件
exports.showFile = function (token, id, res) {
    async.auto({
        getUrl: function (callback) {
            request.getData({
                url: rootPath + '/files/show/' + id,
                token: token
            }, callback)
        },
        loadStream: ['getUrl', function (callback, results) {
            if (results.getUrl.data && results.getUrl.data.remoteUrl) {
                request.getStream({
                    url: results.getUrl.data.remoteUrl
                }).pipe(res);
            }
            else {
                utilsCommon.renderError404(res);
            }
        }]
    })
}

//分享
exports.share = function (token, params, body, cb) {
    var url = {
        1: rootPath + '/knowledge/messages/forward'  //知识库的分享
    }
    if (body.type == 1) {
        body.flag = params.flag;
        body.ref_id = params.id;
    }
    console.debug(url[body.type])
    console.debug(body)
    request.postData({
        url: url[body.type],
        token: token,
        params: body
    }, function (err, result) {
        console.log(err, result);
        if (err) {
            cb({success: false});
        } else {
            cb({success: true});
        }
    });
}

//删除文件
exports.deleteFiles = function (token, id, cb) {
    request.delData({
        url: rootPath + '/files/delete/' + id,
        token: token
    }, function (err, data) {
        if (!err) {
            cb({success: true});
        } else {
            cb({success: false});
        }
    });
};
//上传文件
exports.uploadFiles = function (token, req, cb) {
    req.pipe(request.postData({
        url: rootPath + '/files/upload',
        token: token
    }, function (err, body) {
        cb(err, body);
    }));
};

//下载文件
exports.downloadFile = function (token, fileId, knowledgeId, req, res, cb) {
    async.auto({
        getUrl: function (callback) {
            request.getData({
                url: rootPath + '/knowledge/download',
                params: {flag: 0, id: fileId, knowledgeId: knowledgeId},
                token: token
            }, function(err, result) {
                if(err) {
                    cb(err);
                } else {
                    callback(err, result);
                }
            })
        },
        loadStream: ['getUrl', function (callback, results) {
            if (results.getUrl.data && results.getUrl.data.remoteUrl) {
                var userAgent = (req.headers['user-agent'] || '').toLowerCase();
                if (userAgent.indexOf('msie') >= 0 || userAgent.indexOf('chrome') >= 0) {
                    res.set('Content-Disposition', 'attachment;filename="' + encodeURIComponent(results.getUrl.data.fileName) + '"');
                } else if (userAgent.indexOf('firefox') >= 0) {
                    res.set('Content-Disposition', 'attachment;filename*="utf-8\'\'' + encodeURIComponent(results.getUrl.data.fileName) + '"');
                } else {
                    res.set('Content-Disposition', 'attachment;filename="' + new Buffer(results.getUrl.data.fileName).toString('binary') + '"');
                }
                request.getStream({
                    url: results.getUrl.data.remoteUrl
                }).pipe(res);
            }
            else {
                utilsCommon.renderError404(res);
            }
        }]
    })
}

//上传图片
exports.uploadImage = function (token, fieldName, imageFileStream, options, cb) {

    request.postFileStream({
        url: rootPath + '/files/upload/image',
        token: token
    }, fieldName, imageFileStream, options, cb);

}


/**
 * RTX弹窗页获取数据
 */
exports.getRSSIndex = function (token, id, cb) {
    async.parallel({
        /**
         * 获取任务条数
         */
        taskNum: function (callback) {
            request.getData({
                url: rootPath + '/task/personal/' + id + '/1',
                token: token
            }, function (err, result) {
                if (err) {
                    result = {data: 0};
                } else {
                    result = {data: result.count};
                }
                callback(null, result)
            });
        },
        /**
         * 获取消息条数
         */
        unreadMsg: function (callback) {
            request.getData({
                url: rootPath + '/messages/user/count/' + id,
                token: token
            }, function (err, result) {
                if (err) {
                    result = {data: 0};
                }
                callback(null, result)
            });
        },
        /**
         * 获取最新知识
         */
        newKnowledges: function (callback) {
            request.getData({
                url: rootPath + "/knowledge/new-knowledges",
                params: {
                    level: 1
                },
                token: token
            }, callback);
        },
        /**
         * 获取最新话题
         */
        newTopics: function (callback) {
            request.getData({
                url: rootPath + "/groups/new-topic",
                token: token
            }, callback)
        },
        /**
         * 获取最新群组
         */
        lastestGroups: function (callback) {
            request.getData({
                url: rootPath + "/groups/new",
                token: token
            }, callback);
        }
    }, cb)
}
