var request=require("../utils/request");
var async=require("async");
var config=require("../config"),
    rootPath=config.km.rootPath;

var groupCategoryURL = rootPath+"/groups/category";
//rootPath = "http://172.16.8.2:8080/km";

/**
 * 获取群组分类树
 */
exports.getTabsData = function(token,cb){
    request.getData({
        url:groupCategoryURL,
        token:token
    },cb);
}

/**
 * 群组列表（搜索、分类）
 * @param token
 * @param type
 * @param categoryId
 * @param keyword
 * @param params
 * @param cb
 */
exports.getGroups = function(token,type,categoryId,keyword,params,cb) {
    var url = {
        "search":rootPath + '/group/search?keyword='+keyword,
        "category":rootPath + '/group/category/'+categoryId+'/list'
    }
    async.parallel({
        /**
         * 获取群组分类树
         */
        tabsData:function(callback){
            request.getData({
                url:groupCategoryURL,
                token:token
            },callback);
        },
        //群组公告（活动）
        groupNotice:function(callback){
            request.getData({
                url: rootPath + '/group/group-notice',
                token: token
            },callback);
        },
        groups:function(callback){
            request.getData({
                url: url[type],
                token: token,
                params:params
            },callback);
        }
    },cb);
}

/**
 * 群组列表（搜索、分类）分页
 * @param token
 * @param type
 * @param categoryId
 * @param params
 * @param cb
 */
exports.getGroups_paging = function(token,type,categoryId,keyword,params,cb) {
    var url = {
        "search":rootPath + '/group/search?keyword='+keyword,
        "category":rootPath + '/group/category/'+categoryId+'/list'
    }
    request.getData({
        url: url[type],
        token: token,
        params:params
    },cb);
}

/**
 * 获取群组首页数据（最新群组、优秀群管理员、热门群组、热点话题）
 * @param token
 * @param cb
 */
exports.getIndexData=function(token,cb){
    async.parallel({
        /**
         * 获取群组分类树
         */
        tabsData:function(callback){
            request.getData({
                url:groupCategoryURL,
                token:token
            },callback);
        },
        //群组公告（活动）
        groupNotice:function(callback){
            request.getData({
                url: rootPath + '/group/group-notice',
                token: token
            },callback);
        },
        //最新群组
        lastestGroups:function(callback){
            request.getData(
                {
                    url:rootPath+"/groups/new",
                    token:token
                }
               ,callback);

        },
        //优秀群管理员
        bestAdmin:function(callback){
            request.getData({
                url:rootPath+"/groups/managers/best/",
                token:token
            },callback);
        },
        //热门群组
        hotGroups:function(callback){
            request.getData({
                url:rootPath+"/groups/hot/",
                token:token
            },callback)
        },
        //最新话题
        newTopics:function(callback){
            request.getData({
                url:rootPath+"/groups/new-topic",
                token:token
            },callback)
        },
        //热点话题
        hotTopics:function(callback){
            request.getData({
                url:rootPath+"/groups/hot-topics/",
                token:token
            },callback)
        }
    },cb);
}

/**
 * 获取群组详细信息数据（话题、文档、成员）
 * @param token
 * @param groupid
 * @param cb
 */
exports.getDetailData=function(token,groupid,params,cb){
    async.parallel({
        /**
         * 获取群组分类树
         */
        tabsData:function(callback){
            request.getData({
                url:groupCategoryURL,
                token:token
            },callback);
        },
        //群组公告（活动）
        groupNotice:function(callback){
            request.getData({
                url: rootPath + '/group/group-notice',
                token: token
            },callback);
        },
        //获取单个群组详细信息
        groupInfo:function(callback){
            request.getData({
                url:  rootPath+'/group/'+groupid+'/info',
                token: token
            }, callback);
        },
        //获取群组话题
        topics:function(callback){
            request.getData({
                url:  rootPath+'/group/'+groupid+'/topics',
                token: token,
                params:params.topic
            }, callback);
        },
        //获取群组任务人员
        personnel:function(callback){
            request.getData({
                url:  rootPath+'/task/group/'+groupid+'/personnel',
                token: token,
                params:params.personnel
            }, callback);
        },
        //获取群组成员
        members:function(callback){
            request.getData({
                url:  rootPath+'/groups/'+groupid+'/members',
                token: token,
                params:params.member
            }, callback);
        },
        //获取群内活跃成员
        activeMembers:function(callback){
            request.getData({
                url:  rootPath+'/groups/'+groupid+'/members/active',
                token: token,
                params: {size: 6}
            }, callback);
        }
    },cb);
}

/**
 * 群组详情根据type获取不同数据
 * @param token
 * @param groupid
 * @param type
 * @param params
 * @param cb
 */
exports.getGroupInfos = function(token,groupid,type,params,cb){
    console.log(params);
    var url = {
        1:rootPath+'/group/'+groupid+'/topics',
        2:rootPath+'/groups/'+groupid+'/members',
        3:rootPath+'/task/group/'+groupid+'/personnel'
    };
    request.getData({
        url:url[type],
        token:token,
        params:params
    },cb);
}

/**
 * 获取群组文档（知识库）
 * @param token
 * @param params
 * @param cb
 */
exports.getGroupDocs = function(token, params, cb) {
//    var rootPath = 'http://172.16.8.2:8080/km';
    console.log('群组文档----------------------');
    console.log(rootPath + '/knowledge/2/' + params.attachedId  +'/list');
    console.log({order: params.order, id: params.catalog})
    request.getData({
        url: rootPath + '/knowledge/2/' + params.attachedId  +'/list',
        token: token,
        params: {order: params.order, id: params.catalog}
    }, cb);
};

/**
 * 获取话题详细信息数据（群组信息、话题详情、话题回复列表、群内活跃成员）
 * @param token
 * @param groupid
 * @param cb
 */
exports.getTopicDetailData=function(token,groupid,topicid,params,cb){
    async.parallel({
        /**
         * 增加话题的查看数量
         */
        setVisit:function(callback){
            request.putData({
                url:rootPath+'/group/look-topic/'+topicid,
                token:token
            },callback);
        },
        /**
         * 获取群组分类树
         */
        tabsData:function(callback){
            request.getData({
                url:groupCategoryURL,
                token:token
            },callback);
        },
        //群组公告（活动）
        groupNotice:function(callback){
            request.getData({
                url: rootPath + '/group/group-notice',
                token: token
            },callback);
        },
        //获取单个群组详细信息
        groupInfo:function(callback){
            request.getData({
                url:  rootPath+'/group/'+groupid+'/info',
                token: token
            }, callback);
        },
        //话题详情
        topicInfo:function(callback){
            request.getData({
                url:  rootPath+'/groups/topics/'+topicid,
                token: token
            }, callback);
        },
        //话题回复列表
//        replys:function(callback){
//            request.getData({
//                url:  rootPath+'/groups/topics/'+topicid+'/comments',
//                token: token,
//                params: params
//            }, callback);
//        },
        //获取群内活跃成员
        activeMembers:function(callback){
            request.getData({
                url:  rootPath+'/groups/'+groupid+'/members/active',
                token: token,
                params: {size: 6}
            }, callback);
        }
    },cb);
}

/**
 * 获取话题回复列表
 * @param token
 * @param topicid
 * @param params
 * @param cb
 */
exports.getTopicReplys = function(token,topicid,params,cb){
    request.getData({
        url:rootPath+'/groups/topics/'+topicid+'/comments',
        token:token,
        params:params
    },cb);
}

/**
 * 添加话题回复
 * @param token
 * @param data
 * @param cb
 */
exports.addTopicReply = function(token, userId, data, cb) {
    var params = {};
    params = data.info;
    params.userId = userId;
    request.postData({
        url: rootPath + '/group/'+ data.info.topicId  + '/comments/',
        token: token,
        params: params
    }, cb);
};

/**
 * 添加群成员
 * @param token
 * @param groupid
 * @param data
 * @param cb
 */
exports.addMember = function(token,groupid,data,cb) {
    request.postData({
        url: rootPath + '/group/'+groupid,
        params: data,
        token: token
    }, function(err, body) {
        console.log(body);
        if(!err && body.code == 201) {
            cb(err,{success: true,data:body.data});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 申请加入群验证(同意或拒绝)
 * @param token
 * @param userid
 * @param groupid
 * @param joinType
 * @param cb
 */
exports.askForJoin = function(token,userid,groupid,joinType,cb) {
    request.postData({
        url: rootPath + '/group/'+userid+'/join/'+groupid+'/'+joinType,
        token: token
    }, function(err, body) {
        console.log(body);
        if(!err && body.code == 201) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 是否已申请加入群
 * @param token
 * @param userid
 * @param groupid
 * @param cb
 */
exports.isApplyJoinGroup = function(token,userid,groupid,cb) {
    request.getData({
        url: rootPath + '/task/'+userid+'/isApply/'+groupid+'/3',//3 代表群组
        token: token
    }, function(err, body) {
        console.log(body);
        if(!err) {
            cb(err,{success: true,isApply: body.data});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 删除群成员(踢出/群成员退出)
 * @param token
 * @param groupId
 * @param userId
 * @param type
 * @param cb
 */
exports.delMember = function(token,groupId,userId,type,cb) {
    var url = {
        "del":rootPath + '/group/'+groupId+'/del-member/'+userId,
        "exit":rootPath + '/group/'+groupId+'/member-exit/'+userId
    }
    request.delData({
        url: url[type],
        token: token
    }, function(err, body) {
        console.log(body);
        if(!err && body.code == 200) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 取消或授权管理员（设置群员角色）
 * @param token
 * @param groupid
 * @param data
 * @param cb
 */
exports.setUserRole = function(token,groupid,userid,role,cb) {
    request.postData({
        url: rootPath + '/groups/'+groupid+'/admin/'+userid,
        params: {role:role},
        token: token
    }, function(err, body) {
        if(!err && body.code == 201) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 添加话题页初始
 * @param token
 * @param groupid
 * @param cb
 */
exports.getAddTopicData=function(token,groupid,cb){
    async.parallel({
        //获取群组分类树
        tabsData:function(callback){
            request.getData({
                url:groupCategoryURL,
                token:token
            },callback);
        },
        //获取单个群组详细信息
        groupInfo:function(callback){
            request.getData({
                url:  rootPath+'/group/'+groupid+'/info',
                token: token
            }, callback);
        }
    },cb);
}

/**
 * 编辑话题页初始
 * @param token
 * @param groupid
 * @param topicid
 * @param cb
 */
exports.getEditTopicData=function(token,groupid,topicid,cb){
    async.parallel({
        //获取群组分类树
        tabsData:function(callback){
            request.getData({
                url:groupCategoryURL,
                token:token
            },callback);
        },
        //获取单个群组详细信息
        groupInfo:function(callback){
            request.getData({
                url:  rootPath+'/group/'+groupid+'/info',
                token: token
            }, callback);
        },
        //话题详情
        topicInfo:function(callback){
            request.getData({
                url:  rootPath+'/groups/topics/'+topicid,
                token: token
            }, callback);
        }
    },cb);
}

/**
 * 添加群话题
 * @param token
 * @param groupid
 * @param data
 * @param cb
 */
exports.addTopic = function(token,groupid,data,cb) {
    request.postData({
        url: rootPath + '/group/'+groupid+'/topic',
        params: data,
        token: token
    }, function(err, body) {
        if(!err && body.code == 201) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 编辑群话题
 * @param token
 * @param data
 * @param cb
 */
exports.editTopic = function(token,data,cb) {
    request.putData({
        url: rootPath + '/group/topic/update',
        params: data,
        token: token
    }, function(err, body) {
        if(!err) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 删除群话题
 * @param token
 * @param topicId
 * @param cb
 */
exports.delTopic = function(token,topicId,cb) {
    request.delData({
        url: rootPath + '/groups/topics/'+topicId+'/delete',
        token: token
    }, function(err, body) {
        if(!err && body.code == 200) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 新建群组
 * @param token
 * @param data
 * @param cb
 */
exports.addGroup = function(token,data,cb) {
    console.log(data);
    request.postData({
        url: rootPath + '/group',
        params: data,
        token: token
    }, function(err, body) {
        if(!err && body.code == 201) {
            cb(err,{success: true,message:body.message});
        }else{
            cb(err,{success: false,message:body.message});
        }
    });
}

/**
 * 解散群、删除群
 * @param token
 * @param groupId
 * @param cb
 */
exports.delGroup = function(token,groupId,cb) {
    request.delData({
        url: rootPath + '/groups/'+groupId+'/delete/',
        token: token
    }, function(err, body) {
        if(!err && body.code == 200) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 编辑群组
 * @param token
 * @param groupid
 * @param data
 * @param cb
 */
exports.editGroup = function(token,groupid,data,cb) {
    console.log(data);
    request.putData({
        url: rootPath + '/group/'+groupid+'/update',
        params: data,
        token: token
    }, function(err, body) {
        if(!err) {
            cb(err,{success: true});
        }else{
            cb(err,{success: false});
        }
    });
}

/**
 * 上传群组头像
 * @param token
 * @param req
 * @param cb
 */
exports.uploadGroupAvatar = function(token, req, cb) {
    req.pipe(
        request.postData({
            url: rootPath + '/files/upload/avatar',
            token: token
        }, function(err, body) {
            console.log(body);
            if(!err && body.code == 201) {
                cb({success: true,data:body.data});
            } else {
                cb({success: false});
            }
        })
    );
};

/**
 * 获取树(群组分类，部门组织结构)
 * @param token
 * @param path
 * @param cb
 */
exports.getTreeModel = function(token,type,cb){
    //type groups:群组分类，organization:组织结构（部门）
    var url = {
        "groups":rootPath +"/groups/category",
        "organization":rootPath +"/organization"
    };
    request.getData({
        url: url[type],
        token: token
    }, function(err, body) {
        if(!err && body.code == 200) {
            cb(null,body.data[0].children);
        }else {
            cb(err,null);
        }
    });
}