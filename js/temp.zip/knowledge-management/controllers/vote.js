var request=require("../utils/request");
var async=require("async");
var config=require("../config"),
    rootPath=config.km.rootPath;
//rootPath = "http://172.16.8.10:8080/km";
/**
 * 获取投票列表（最热、最新）
 * @param token
 * @param cb
 */
exports.getVoteList = function(token,params,cb){
    async.parallel({
        /**
         * 获取群组分类树
         */
        tabsData:function(callback){
            request.getData({
                url:rootPath+"/groups/category",
                token:token
            },callback);
        },
        //最热投票
        hotVote:function(callback){
            request.getData({
                url:  rootPath+'/group/vote/hot',
                token: token,
                params: params
            }, callback);
        },
        //最新投票
        newVote:function(callback){
            request.getData({
                url:  rootPath+'/group/new-vote',
                token: token,
                params: params
            }, callback);
        }
    },cb);
}

/**
 * 投票列表根据type获取不同数据
 * @param token
 * @param groupid
 * @param type
 * @param params
 * @param cb
 */
exports.getVoteForType = function(token,groupid,type,params,cb){
    var url = {
        1:rootPath+'/group/vote/hot',
        2:rootPath+'/group/'+groupid+'/new-vote'
    };
    request.getData({
        url:url[type],
        token:token,
        params:params
    },cb);
}

/**
 * 添加投票
 * @param token
 * @param data
 * @param cb
 */
exports.addVote = function(token,data,cb){
//    console.log(data);
    request.postData({
        url: rootPath + '/group/vote',
        token: token,
        params: data
    }, function(err, body) {
        if(!err && body.code == 201) {
            cb(null,{success: true,voteId:body.data});
        }else {
            cb(err,{success: false});
        }
    });
}

/**
 * 用户进行投票
 * @param token
 * @param data
 * @param cb
 */
exports.castVote = function(token,data,cb){
    console.log(data);
    request.putData({
        url: rootPath + '/group/click-vote',
        token: token,
        params: data
    }, function(err, body) {
        if(!err && body.code == 201) {
            cb(null,{success: true,message:body.message,data:body.data});
        }else if(!err && body.code == 204) {
            cb(null,{isChecked: true});
        }else {
            cb(err,{success: false});
        }
    });
}