var request=require("../utils/request");
var async=require("async");
var config=require("../config"),
    rootPath=config.km.rootPath;
//rootPath = "http://10.10.12.70:8080/km";
/**
 * 获取专家首页数据（专家列表、专家分类）
 * @param token
 * @param cb
 */
exports.getExpertData = function(token,cb){
    async.parallel({
        //专家列表
        expertsList:function(callback){
            request.postData({
                url:rootPath+"/experts/ExpertsList",
                token:token,
                params: {limit:10,page:1}
            },callback);
        },
        //专家分类
        expertsCategroy:function(callback){
            request.getData({
                url:  rootPath+'/expertsCategroy/getCategroy',
                token: token,
                params: {limit:12,page:1}
            }, callback);
        },
        //乐于助人榜
        expertQuestion:function(callback){
            request.getData({
                url:  rootPath+'/experts/ExpertQuestion',
                token: token,
                params: {limit:6,page:1}
            }, callback);
        }
    },cb);
}