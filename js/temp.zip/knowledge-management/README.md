# 知识管理系统web前端项目

## 安装git

下载安装[git客户端](http://git-scm.com/)

## 配置git

用git命令行bash客户端执行

```
git config --global user.name "John Doe"
git config --global user.email "johndoe@example.com"

```
上面要配置的是你个人的用户名称和电子邮件地址。这两条配置很重要，每次 Git 提交时都会引用这两
条信息，说明是谁提交了更新，所以会随更新内容一起被永久纳入历史记录

## 用git bash自带的SSH-KEYGEN生成你的公钥和密钥

```
$ ssh-keygen
Generating public/private rsa key pair.
Enter file in which to save the key (/Users/schacon/.ssh/id_rsa):
Enter passphrase (empty for no passphrase):
Enter same passphrase again:
Your identification has been saved in /Users/schacon/.ssh/id_rsa.
Your public key has been saved in /Users/schacon/.ssh/id_rsa.pub.
The key fingerprint is:
43:c5:5b:5f:b1:f1:50:43:ad:20:a6:92:6a:1f:9a:3a schacon@agadorlaptop.local

```
它先要求你确认保存公钥的位置（~/.ssh/id_rsa），然后它会让你重复一个密码两次，如果不想在使用公钥的
时候输入密码，可以留空(**最好留空**)


公钥的样子大致如下

```
$ cat ~/.ssh/id_rsa.pub
ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAklOUpkDHrfHY17SbrmTIpNLTGK9Tjom/BWDSU
GPl+nafzlHDTYW7hdI4yZ5ew18JH4JW9jbhUFrviQzM7xlELEVf4h9lFX5QVkbPppSwg0cda3
Pbv7kOdJ/MTyBlWXFCR+HAo3FXRitBqxiX1nKhXpHAZsMciLq8V6RjsNAQwdsdMFvSlVK/7XA
t3FaoJoAsncM1Q9x5+3V0Ww68/eIFmb1zuUFljQJKprrX88XypNDvjYNby6vw/Pb0rwert/En
mZ+AW4OZPnTPI89ZPmVMLuayrD2cE86Z/il8b+gw3r3+1nKatmIkjn2so1d01QraTlMqVSsbx
NrRFi9wrf+M7Q== schacon@agadorlaptop.local

```
接着进入gitlab的profile settings,头部的tab选择ssh keys，点击add SSH key,把公钥粘贴到key中,title会默认显示你的邮箱

## 获取项目


客户端安装完后打开git bash,clone项目

`git clone ssh://git@10.10.3.98:16333/tech7road/knowledge-management.git`

获取代码后,在项目目录下执行`npm install`命令安装依赖

## 开发流程

1. git上有一个master主干分支,为稳定的发布版本
2. 一个名为develop的开发分支
	* 开发过程中根据功能特性从develop中创建一个feature-*分支,feature为前缀名,如果feature-group
	* 开发完成后,进行测试,完成后合并到develop中
	* 当完整的一个develop阶段完成，并发布后,在主干master上合并develop分支,保证master分支的稳定和完整性
3. 在某个分支里面如果出现bug,需要去修复的,创建一个叫fixbug-*的分支,修复完后并入主要的分支,如develop中发现bug,创建新的fixbug-a,修复完后并入develop并删除掉临时分支fixbug-a