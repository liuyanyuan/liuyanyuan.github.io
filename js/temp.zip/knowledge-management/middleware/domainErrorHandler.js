var logger=require("../utils/log");
var domain=require("domain");
module.exports=function(options){
    return function(req,res,next){
        var reqDomain=domain.create();
        reqDomain.add(req);
        reqDomain.add(res);
        reqDomain.on("error",function(err){
            try{
                next(err);
//                var killTimer=setTimeout(function(){
//                    process.exit(1);
//                },options.killTimeout);
//                if(typeof killTimer.unref==="function"){
//                    killTimer.unref();
//                }
//                options.server.close()

            }
            catch(e){
                logger.getLogger.error(e.stack);
                next(e);
            }
        })
        reqDomain.run(next);
    }
}

//处理未捕获的异常
process.on("uncaughtException",function(err){
    try{
        logger.getLogger.error(err.stack);
        var killTimer=setTimeout(function(){
            process.exit(1);
        },options.killTimeout);
        killTimer.unref();
        options.server.close();

    }
    catch(e){
        logger.getLogger.error(e.stack);
    }
});