var request=require("../utils/request");
var async=require("async");
module.exports=function(){
    return function(req,res,next){
        if(!req.session.token){

            res.setHeader("X-Powered-By","Express-7road");

            async.series([
                function(cb){
                    request.login(req,cb);
                    //cb(null,req);
                }
            ],function(err,values){
                if(err){
                    next(err);
                }else{
                    next();
                }

            })
        }else{
            next();
        }
    }
}