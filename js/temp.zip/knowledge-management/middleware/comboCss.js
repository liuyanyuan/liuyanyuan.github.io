var path=require("path");
var fs=require("fs");
var CleanCss=require("clean-css")
module.exports=function(){
    return function(req,res,next){
        var query=req.query;
        if(Object.keys(query).length>0){
            var cssText="";
            Object.keys(query).forEach(function(key){
                var filePath=path.join(process.cwd(),key);
                cssText+=fs.readFileSync(filePath);
            })

            res.set("Content-Type","text/css");
            res.send(new CleanCss().minify(cssText));
        }
        else{
            next();
        }
    }
}