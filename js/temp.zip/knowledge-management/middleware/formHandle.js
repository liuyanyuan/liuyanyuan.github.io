var multiparty = require("multiparty");
var config = require("../config"),
    fileMaxSize = config.km.fileMaxSize;
module.exports = function () {
    return function (req, res, next) {
        if(req.get("Content-Length") > fileMaxSize){
            res.set('Content-Type', 'text/html;charset=utf-8');
            res.send('{"message": "文件超过' + (fileMaxSize / 1024 /1024) +'M！"}');
        }
        else{
            next();
        }
    }
}