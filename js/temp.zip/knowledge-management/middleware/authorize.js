module.exports = function (req, res, next) {



    var referee = req.originalUrl || "";//根据用户从哪过来以便登陆后直接跳转过去

    var qs = require("querystring");
    if (req.session && req.session.token) {
        res.locals.session = req.session;//设置session给后面的会话变量
        next();

    }
    else {
        if (req.xhr) {
            res.send(401, "没有权限访问接口或者会话过期");
        }
        res.redirect('/login/?returnUrl=' + qs.escape(referee));
    }


}