var path = require("path");
var fs = require("fs");
var crypto = require("crypto");

function md5(text) {
    return  crypto.createHash('md5').update(text).digest("hex");
}

module.exports = function () {

    /*
     //by shayne
     return function (req, res, next) {
     //combo js ??作为起始，","作为分隔符
     var url = req.url;
     var start = url.indexOf("??");
     var querys;
     var jsText = ";";

     //var query = req.query;
     if (start > -1) {
     querys = url.substr(start + 2).split(",");
     querys.forEach(function (key) {
     var filePath = path.join(process.cwd(), "static/javascripts", req.path, key);
     //            console.log(req.path+","+key+","+JSON.stringify(req.query));
     jsText += fs.readFileSync(filePath) + ";";
     })
     res.set("Content-Type", "application/javascript");
     res.send(jsText);
     }
     else {
     next();
     }

     };

     */

    //by paper
    return function (req, res, next) {

        //combo js ??作为起始，","作为分隔符
        var url = req.url;
        var start = url.indexOf("??");
        var reqPath = req.path;
        var rootPath = process.cwd();
        var tempFilePath = require("../config").km.tempFilesPath;
        if (start > -1) {

            //js路径md5化（省去不少麻烦）
            var comboJSName = md5(url);

            res.set("Content-Type", "application/javascript");

            //根目录下 ，要有 temp目录
            var comboJSPath = path.join(rootPath, tempFilePath, comboJSName + ".js");

            //判断合并的js文件是否存在
            fs.exists(comboJSPath, function (exists) {

                //存在，就直接读取之前合并过的js文件
                if (exists) {
                    var comboJSReadStream = fs.createReadStream(comboJSPath);
                    comboJSReadStream.pipe(res);
                }
                //不存在，进行合并，而且生成合并的js文件放到temp目录下
                else {
                    var querys = url.substr(start + 2).split(",");
                    var i = 0;
                    var chunks = [];
                    var allJsExists = true;

                    //判断所有js是否存在
                    querys.forEach(function (value) {
                        if (!allJsExists) return;

                        var filePath = path.join(rootPath, "static/javascripts", reqPath, value);

                        if (!fs.existsSync(filePath)) {
                            allJsExists = false;
                        }
                    });


                    //递归读取各个js脚本流
                    function readStream(querys) {
                        if (i < querys.length) {

                            var filePath = path.join(rootPath, "static/javascripts", reqPath, querys[i]);
                            var rs = fs.createReadStream(filePath);

                            rs.setEncoding('utf8');
                            rs.push(";");
                            rs.on('data', function (chunk) {
                                chunks.push(chunk);
                                res.write(chunk);
                            });

                            rs.on('end', function () {
                                i++;
                                readStream(querys);
                            });

                            rs.on('error', function (err) {
                                res.end(err);
                            });
                        } else {
                            //存储当前js合并版本 到  根目录的temp目录下
                            var comboJS = fs.createWriteStream(comboJSPath);
                            comboJS.write(chunks.join(''));

                            res.end();
                        }
                    }

                    if (allJsExists) {
                        readStream(querys);
                    } else {
                        res.send(404, "not found");
                    }

                }
            });//end fs.exists

        } else {
            next();
        }

    };

};