var logger = require("../utils/log");
var utilsCommon = require('../utils/common');

module.exports = function () {
    return function (err, req, res, next) {
        try {
            logger.getLogger.error("url:%s method:%s\r\n %s \r\n message:%s\r\n stack:%s", req.url, req.method, JSON.stringify(err, ["params", "code"]), err.message, err.stack);
        }
        catch (e) {
            logger.getLogger.error(JSON.stringify(e, ["stack", "message"]));
            res.send(500, JSON.stringify(e, ["stack", "message"]));
        }


        if (req.xhr) {
            res.send(err.code || 500, {errorMessage: err.message})
        }
        else {
            switch (err.code) {
                case 401:
                    //res.send(401, "没有权限访问接口或者会话过期");
                    utilsCommon.renderErrorCom(res, "没有权限访问接口或者会话过期");
                    break;
                case 403:
                    utilsCommon.renderError403(res);
                    //utilsCommon.renderErrorCom(res, "Sorry! <br /> 当前您没有访问权限，请联系管理员");
                    break;
                case 404:
                    utilsCommon.renderError404(res);
                    break;
                case 500:
                    //res.send(500, err.stack);
                    utilsCommon.renderErrorCom(res, "F5刷新试一试~ <br /> 服务器可能生病了！<br />正在医院打点滴呢，没有什么危险的。 <br />错误代码：500(服务器内部错误)");
                    break;
                default :
                    //res.send(500, err.stack);
                    utilsCommon.renderErrorCom(res, "F5刷新试一试~ <br /> 服务器可能生病了！<br />正在医院打点滴呢，没有什么危险的。 <br />错误代码：500(服务器内部错误)");
                    break;
            }
        }


    }
}
