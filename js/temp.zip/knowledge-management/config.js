var config,
    env = process.env.NODE_ENV || "development";

config = {
    development: {
        port:3000,
        auth: {
            rootPath: "http://10.10.3.99:8081"
//            rootPath: "http://10.10.3.99:8081"
        },
        km: {
//            rootPath: "http://10.10.7.145:8080/km",
            rootPath :'http://10.10.3.99:8888/km',
            rtxPath :'http://10.10.4.50:8012',
            umeditorPath: "/km-manager/ueditor_mini/",//app中配置
            feedbackPath: "/group/1328",  //反馈地址
            //当前项目可查看组织结构ID
            organizationID: "1",
            fileMaxSize: 80 * 1024 * 1024,
            tempFilesPath: "static/temp"
        }

    },
    test:{
        port:80,
        auth: {
            rootPath: "http://10.10.3.99:8081"
        },
        km: {
            rootPath: "http://10.10.3.99:8888/km",
            rtxPath :'http://10.10.4.50:8012',
            umeditorPath: "/km-manager/ueditor_mini/",//app中配置
            feedbackPath: "/group/135",  //反馈地址
            //当前项目可查看组织结构ID
            organizationID: "1",
            fileMaxSize: 80 * 1024 * 1024,
            redisStore: {
                host: "10.10.3.99",
                port: 6379,
                pass: "love7road_km",
                db: 8 //索引为8
            },
            cookieMaxAge:3 * 24 * 60 * 60 * 1000,
            tempFilesPath: "static/temp"
        }
    },
    production: {
        port:80,
        auth: {
            rootPath: "http://192.168.1.43:8081"
        },
        km: {
            rootPath: "http://192.168.1.42:8080/km",
            rtxPath :'http://rtx.7road.com:8012',
            umeditorPath: "/km-manager/ueditor_mini/",//app中配置
            feedbackPath: "/group/20/addTopic?group=知识管理系统应用反馈群",  //反馈地址
            //当前项目可查看组织结构ID
            organizationID: "1",
            fileMaxSize: 80 * 1024 * 1024,
            redisStore: {
                host: "192.168.1.42",
                port: 6379,
                pass: "love7road_km",
                db: 8 //索引为8
            },
            cookieMaxAge:3 * 24 * 60 * 60 * 1000,
            tempFilesPath: "static/temp"
        }
    }
}

module.exports = config[env];