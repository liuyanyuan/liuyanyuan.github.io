/**
 * Created by peng.xie on 14-2-28.
 */
var authorize = require('../middleware/authorize');
var knowledgeCtrl = require('../controllers/knowledge');
var config = require("../config"),
    fileMaxSize = config.km.fileMaxSize;
var utilsCommon = require('../utils/common');

module.exports = function (app) {

    //知识库首页
    app.get("/knowledge", authorize, function (req, res, next) {
        knowledgeCtrl.getIndexData(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/index', {viewModel: results});
            }
        });
    });

    //最新知识树分页加载
    app.get("/knowledge/newKnowledgeList", authorize, function (req, res, next) {
        if (req.query.type == "tree_li") {
            knowledgeCtrl.getNewKnowledges(req.session.token, req.query, function (err, results) {
                if (err) next(err);
                else {
                    res.render('knowledge/template/KTreeList', {data: results.data, level: req.query.level});
                }
            });
        }
        else {
            knowledgeCtrl.getNewKnowledgesList(req.session.token, req.query, function (err, results) {
                if (err) next(err);
                else {
                    res.render('knowledge/template/knowledgeList', {type: 0, data: results.data});
                }
            });
        }
    });

    //最新知识树列表页面
    app.get("/knowledge/newsList/:level", authorize, function (req, res, next) {
        var data = {level: req.params.level, page: 1};
        knowledgeCtrl.getNewKnowledgesList(req.session.token, data, function (err, results) {
            if (err) next(err);
            else {
                results.level = req.params.level;
                res.render('knowledge/newestList', {viewModel: results});
            }
        });
    });

    //知识库分类跳转页面
    app.get("/knowledge/classifiedData", authorize, function (req, res, next) {
        knowledgeCtrl.classifiedData(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/classifiedData', {viewModel: results});
            }
        });
    });

    //获取分类知识库列表
    app.get("/knowledge/classifiedList", authorize, function (req, res, next) {
        knowledgeCtrl.classifiedList(req.session.token, req.query.id, req.query.page, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/template/knowledgeList', {type: 0, data: results.data}, function (err, html) {
                    if (err) next(err);
                    else {
                        res.json({html: html, paging: results.paging});
                    }
                });
            }
        });
    });

    //更多市场战略跳转页面
    app.get("/knowledge/marketStrategy", authorize, function (req, res, next) {
        knowledgeCtrl.marketStrategyList(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/marketStrategy', {viewModel: results});
            }
        });
    });

    //更多最佳实践跳转页面
    app.get("/knowledge/bestPractice", authorize, function (req, res, next) {
        knowledgeCtrl.bestPracticeList(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/bestPractice', {viewModel: results});
            }
        });
    });
    //最佳实践展现
    app.get("/knowledge/bestPractice/docDetail", authorize, function (req, res, next) {
        knowledgeCtrl.bestPracticeList(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/bestPractice/docDetail', {viewModel: results});
            }
        });
    });
    //游戏玩法库
    app.get("/knowledge/gameGuide", authorize, function (req, res, next) {

        //------** 使用本地数据渲染模板 **------
        //var gameGuide = require('../static/images/demo/gameGuide/guideCategory.json');
        //res.render('knowledge/gameGuide', {viewModel: gameGuide});
        //------** 使用本地数据渲染模板 **------
        req.query['page'] = 1;
        req.query['limit'] = 12;
        req.query['order'] = 'tkr.AVG';
        console.log(req.query);

        knowledgeCtrl.gameGuide(req.session.token, req.query, function (err, results) {
            if (err) next(err);
            else {
                console.log(results.guideCategory );
                res.render('knowledge/gameGuide', {viewModel: results});
            }
        });
    });
    //游戏玩法库上传页面
    app.get("/knowledge/gameGuide/upload", authorize, function (req, res, next) {
        res.render('knowledge/gameGuide/uploadGameGuide', {viewModel: {fileMaxSize: fileMaxSize}});
    });
    //设置知识库图片
    app.post('/knowledge/setImg', function(req, res, next) {
        res.set('Content-Type', 'text/html');
        knowledgeCtrl.setKnowledgeImg(req.session.token, req, function(result) {
            res.json(result);
        });
    });
    //获取玩法库分类
    app.get('/knowledge/gameGuide/category', authorize, function (req, res, next) {

        knowledgeCtrl.getCategory(req.session.token, function (err, result) {
            if (err) {

                next(err);
            } else {
                console.log('asdasdasda');
                console.log(result);
                res.render('common/k-category', {viewModel: result.data}, function (err, html) {

                    res.send(html);
                })
            }

        });
    });

    //游戏玩法库新增文档
    app.post('/knowledge/gameGuide/add/:sceneType', authorize, require('../middleware/formHandle')(), function (req, res, next) {
        res.set('Content-Type', 'text/html;charset=UTF-8');
        knowledgeCtrl.uploadFiles(req.session.token, req, function (err, result) {
            if (err) {
                next(err);
            } else {
                res.render('common/knowledge-form', {doc: result.upload.data, sceneType: req.params.sceneType, knowType: 1, knowledge: {},category: result.add.data }, function (err, html) {
                    res.send(html);
                });
            }
        });

    });
    //玩法库文档详情页面
    app.get("/knowledge/gameGuide/doc/:id", authorize, function (req, res, next) {
        if (+req.params.id != req.params.id) {
            utilsCommon.renderError404(res);
        }
        else {
            knowledgeCtrl.getKnowledgeByID(req.session.token, req.params.id, function (err, results) {
                if (err) next(err);
                else {
                    if (results.knowledge.data) {
                        results.knowledge.data.isMine = (results.knowledge.data.userId == req.session.userId);
                        res.render('knowledge/knowledgePage', {viewModel: results});
                    }
                    else {
                        utilsCommon.renderError404(res);
                    }
                }
            });
        }
    });
    //玩法库文档列表分页
    app.get("/knowledge/gameGuide/docList",function(req,res,next){

        var isSearch =  typeof req.query['search'] != 'undefined' ? true: false;

        if( isSearch ){
            delete req.query['search'];
        }
        delete req.query['_'];
        console.log('isSearch = ' + isSearch);
        console.log(req.query);
        knowledgeCtrl.getGuideDocList( req.session.token,req.query,function(err,result){
            if(err){
                next(err);
            }else{
                console.log('result count = ' + result.count);
                result.isSearch =  isSearch;
                res.render("knowledge/gameGuide/docList",{ docs:result }, function(err, html) {
                    console.log(err);
                    res.send(html);
                });
            }
        });
    });
    //更新玩法库页面
    app.get("/knowledge/gameGuide/update/:type/:docType/:id", authorize, function (req, res, next) {

        knowledgeCtrl.getGameGuideDoc(req.session.token, req.params.id, function (err, results) {
            if (err) {
                next(err);
            } else {
                res.render('knowledge/gameGuide/updateKnowledge', {knowledge: results.docInfo.data, category:results.category.data,sceneType: 3, knowType: req.params.type});
            }
        });
    });

    //更多热点知识跳转页面
    app.get("/knowledge/hotKnowledge", authorize, function (req, res, next) {
        knowledgeCtrl.hotKnowledgeList(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/hotKnowledge', {viewModel: results});
            }
        });
    });

    //分页获取知识列表//type,0:最佳实践;1:市场战略;2:热点知识;
    app.get("/knowledge/knowledgeByPage", authorize, function (req, res, next) {
        knowledgeCtrl.knowledgeByPage(req.session.token, req.query.page, req.query.type, function (err, results) {
            if (err) next(err);
            else {
                switch (parseInt(req.query.type)) {
                    case 0:
                        res.render('knowledge/template/knowledgeList', {type: 0, data: results.data});
                        break;
                    case 1:
                        res.render('knowledge/template/knowledgeList', {type: 1, data: results.data});
                        break;
                    case 2:
                        res.render('knowledge/template/knowledgeList', {type: 0, data: results.data});
                        break;
                }
            }
        });
    });

    //知识详情跳转页面
    app.get("/knowledge/knowledgePage/:id", authorize, function (req, res, next) {
        if (+req.params.id != req.params.id) {
            utilsCommon.renderError404(res);
        }
        else {
            knowledgeCtrl.getKnowledgeByID(req.session.token, req.params.id, function (err, results) {
                if (err) next(err);
                else {
                    if (results.knowledge.data) {
                        results.knowledge.data.isMine = (results.knowledge.data.userId == req.session.userId);
                        res.render('knowledge/knowledgePage', {viewModel: results});
                    }
                    else {
                        utilsCommon.renderError404(res);
                    }
                }
            });
        }
    });

    //知识详情页获取更多回复
    app.get("/knowledge/getMoreReply", authorize, function (req, res, next) {
        knowledgeCtrl.getMoreReply(req.session.token, req.query.id, req.query.page, req.query.limit, function (err, results) {
            if (err) next(err);
            else {
                res.render('knowledge/template/replyBox', {
                    hasHead: false,
                    hasMore: false,
                    hasBox: false,
                    replyList: results.data,
                    ID: req.query.id
                });
            }
        });
    });

    //转发文档显示器请求
    app.get("/knowledge/knowledgeId/:knowledgeId/file/:fileId", authorize, function (req, res, next) {
        knowledgeCtrl.getSWF(req.session.token, res, req.params);
    });

    //提交知识点评价或评论
    app.post("/knowledge/reply", authorize, function (req, res, next) {
        //req.body.type,0:赞评价;1:分数评价;2:添加印象;3:文字评论
        req.body.userId = req.session.userId;
        req.body.userName = req.session.userName;

        switch (parseInt(req.body.type)) {
            case 0:
                knowledgeCtrl.favourEffect(req.session.token, req.body, function (err, results) {
                    if (err) next(err);
                    else {
                        res.json(results);
                    }
                });
                break;
            case 1:
                knowledgeCtrl.setScore(req.session.token, req.body, function (err, results) {
                    if (err) next(err);
                    else {
                        res.json(results);
                    }
                });
                break;
            case 2:
                knowledgeCtrl.setEffect(req.session.token, req.body, function (err, results) {
                    if (err) next(err);
                    else {
                        res.json(results);
                    }
                });
                break;
            case 3:
                knowledgeCtrl.setReply(req.session.token, req.body, function (err, results) {
                    if (err) next(err);
                    else {
                        res.render('knowledge/template/replyBox', {
                            hasHead: false,
                            hasMore: false,
                            hasBox: false,
                            ID: req.body.knowledgeId,
                            replyList: [results.data]
                        });
                    }
                });
                break;
        }
    });

    //知识上传页面
    app.get("/knowledge/upload", authorize, function (req, res, next) {
        res.render('knowledge/uploadKnowledge', {viewModel: {fileMaxSize: fileMaxSize}});
    });

    //创建文档页面
    app.get("/knowledge/new", authorize, function (req, res, next) {
        res.render('knowledge/newKnowledge', {referer: req.get("Referer")});
    });

    //更新文档页面
    app.get("/knowledge/update/:type/:id", authorize, function (req, res, next) {

        knowledgeCtrl.getDocKnowledge(req.session.token, req.params.id, function (err, results) {
            if (err) {
                next(err);
            } else {
                res.render('knowledge/updateKnowledge', {knowledge: results, sceneType: 2, knowType: req.params.type});
            }
        });
    });

    //知识系统 - 搜索页
    app.get("/knowledge/search", authorize, function (req, res, next) {
        if (!req.query.keyword || req.query.keyword == '') {
            res.redirect("/knowledge");
        }
        else {
            var data = {keyword: req.query.keyword}
            knowledgeCtrl.searchByKeywords(req.session.token, data, function (err, results) {
                if (err) next(err);
                else {
                    if (req.query.type == "paging") {
                        res.render('knowledge/template/knowledgeList', {type: 0, data: results.data});
                    }
                    else {
                        results.keyword = req.query.keyword;
                        res.render('knowledge/search', {viewModel: results});
                    }
                }
            });
        }
    });

}