/**
 * Created by peng.xie on 14-1-2.
 */
var authorize = require('../middleware/authorize');
var questionCtrl = require('../controllers/question');

module.exports = function (app) {
    /**
     * 问答首页
     */
    app.get("/question", authorize, function (req, res, next) {
        questionCtrl.getIndexData(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('question/index', {viewModel: results});
            }
        });
    });
    /**
     * 问答首页分页列表
     */
    app.get("/question/getQuestionList", authorize, function (req, res, next) {
        questionCtrl.getQuestionList(req.session.token, req.query, function (err, results) {
            if (err) next(err);
            else {
                res.render('question/template/index-questionList', {data: results.data}, function (err, html) {
                    if (err) next(err);
                    else {
                        res.json({html: html, paging: results.paging});
                    }
                });
            }
        });
    });
    /**
     * 问题详情
     */
    app.get("/question/detailedQuestion/:questionid", authorize, function (req, res, next) {
        var questionid = req.params.questionid;
        questionCtrl.getdetailedQuestion(req.session.token, questionid, function (err, results) {
            if (err) next(err);
            else {
                if (results.detailedQuestion.data.userId == req.session.userId) {
                    results.detailedQuestion.data.isMyQuestion = true;
                }
                else {
                    results.detailedQuestion.data.isMyQuestion = false;
                }

                if (req.query.fromType || req.query.fromType == "index") {
                    res.render('question/template/index-answerList', {viewModel: results, type:1});
                } else {
                    res.render('question/detailedQuestion', {viewModel: results});
                }
            }
        });
    });
    /**
     * 发起问题
     */
    app.get("/question/toAsk", authorize, function (req, res, next) {
        res.render('question/toAsk');
    });
    /**
     * 获取问题分类树
     */
    app.get("/question/getQuestionSort", function (req, res, next) {
        questionCtrl.getQuestionSort(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('common/k-category', {viewModel: results.tabsData.data[0]}, function (err, html) {
                    res.send(html);
                })
            }
        });
    });
    /**
     * 问题详情，分页获取更多答案
     */
    app.get("/question/getMoreAnswers", function (req, res, next) {
        var data = req.query;
        questionCtrl.getMoreAnswers(req.session.token, data, function (err, result) {

            result.isMyQuestion=req.query.userId==req.session.userId;

            res.render('question/template/answers', {answers: result}, function (err, html) {
                if (err) next(err);
                else {
                    res.json(html);
                }
            })
        });
    });
    /**
     * 设置为采纳答案
     */
    app.post("/question/best-answer", function (req, res, next) {
        questionCtrl.adoptedAnswer(req.session.token, req.body, function (err, result) {
            if (err) next(err);
            else {
                res.json(result);
            }
        });
    });
    /**
     * 查询自己的答案
     */
    app.get("/question/searchMyAnswer", function (req, res, next) {
        questionCtrl.searchMyAnswer(req.session.token, req.query, function (err, result) {
            if (err) next(err);
            else {
                if (result.data) {
                    res.json(result.data);
                }
                else {
                    res.json(null);
                }
            }
        });
    });
    /**
     * 发起问题
     */
    app.post("/question/toAsk/setQuestion", function (req, res, next) {
        questionCtrl.setQuestion(req.session.token, req.body, req.session.userId, req, function (err, result) {
            if (err) next(err);
            else {
                res.json(result);
            }
        });
    });
    /**
     * 修改问题
     */
    app.post("/question/toAsk/updateQuestion", function (req, res, next) {
        questionCtrl.updateQuestion(req.session.token, req.body, function (err, result) {
            if (err) next(err);
            else {
                res.json(result);
            }
        });
    });
    /**
     * 问答分类跳转页面
     */
    app.get("/question/classifiedData", authorize, function (req, res, next) {
        questionCtrl.getQuestionSort(req.session.token, function (err, results) {
            if (err) next(err);
            else {
                res.render('question/classifiedData', {viewModel: results});
            }
        });
    });
    /**
     * 获取分类知识库列表
     */
    app.get("/question/classifiedList", authorize, function (req, res, next) {
        questionCtrl.classifiedList(req.session.token, req.query, function (err, results) {
            if (err) next(err);
            else {
                res.render('question/template/questionList', {data: results.data}, function (err, html) {
                    if (err) next(err);
                    else {
                        res.json({html: html, paging: results.paging});
                    }
                });
            }
        });
    });
    /**
     * 问答搜索列表--通过关键字查询问题
     */
    app.get("/question/search", authorize, function (req, res, next) {
        if (!req.query.keyword || req.query.keyword == '') {
            res.redirect("/question");
        }
        else {
            var data = {question: req.query.keyword}
            questionCtrl.searchByKeywords(req.session.token, data, function (err, results) {
                if (err) next(err);
                else {
                    if (req.query.type == "paging") {
                        res.render('question/template/questionList', {data: results.data});
                    } else {
                        results.keyword = req.query.keyword;
                        res.render('question/search', {viewModel: results});
                    }
                }
            });
        }
    });


    //以下路由为选择邀请人或群组控件使用
    /**
     * 获取选择用户/群组模板
     */
    app.get("/question/selectBox", function (req, res, next) {
        var data = req.query;//可不传参//oldData：已存在的数据;type：例如["person","group"];

        questionCtrl.getOrganization(req.session.token, data, function (err, result) {
            if (err) next(err);
            else {
                res.render('common/tabBox', {data: result, oldData: data.oldData, type: data.type || ["person"]})
            }
        });
    });
    /**
     * 通过组织结构ID获取用户
     */
    app.get("/question/getUsersByGroup", function (req, res, next) {
        var data = req.query;
        questionCtrl.getUsersByGroup(req.session.token, data, function (err, result) {
            if (err) next(err);
            else {
                res.render('common/userCB-li', {data: result.data.members})
            }
        });
    });
    /**
     * 模糊搜索组织结构用户
     */
    app.get("/question/getUserByName", function (req, res, next) {
        var data = req.query;
        questionCtrl.getUsersByName(req.session.token, data, function (err, result) {
            if (err) next(err);
            else {
                res.render('common/userCB-li', {data: result.data})
            }
        });
    });
}
