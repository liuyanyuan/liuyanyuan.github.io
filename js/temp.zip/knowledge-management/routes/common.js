/**
 * Created by peng.xie on 14-1-20.
 */
var authorize = require('../middleware/authorize');
var commonCtrl = require('../controllers/common');
var crypto = require("crypto");
var utilsCommon = require('../utils/common');

function md5(string) {
    return crypto.createHash("md5").update(string).digest("hex")
}

module.exports = function (app) {

    //403处理
    app.get("/error/403", authorize, function (req, res, next) {
        //res.render('error/403');
        utilsCommon.renderError403(res);
    });

    //公共的错误处理
    app.get("/error/com", authorize, function (req, res, next) {
        utilsCommon.renderErrorCom(res);
    });

    /**
     * demo  by paper
     */
    app.get("/demo", authorize, function (req, res, next) {
        res.render('demo/km-demo');
    });

    /**
     * 获取翻页
     */
    app.get("/ajax/paging", authorize, function (req, res, next) {
        res.render('common/paging',{paging:{ total:req.param("total"), limit:req.param("limit") }});
    });

    /**
     * 获取头像
     * id userId
     */
    app.get('/personal/:id/avatar', authorize, function (req, res, next) {

        res.set("Cache-Control", "max-age=300000");

        commonCtrl.getAvatar(req.session.token, req.params.id, res);


    });

    /**
     * 获取图片（不包含头像）
     * id  fileId
     */
    app.get('/files/show/:id', authorize, function (req, res, next) {

        var fileId = req.params.id;
        if (fileId == null || fileId == "null") {
            fileId = 1;
        }
        res.set("Cache-Control", "max-age=300000");
        res.set("ETag", md5(req.path));

        if (req.fresh) {
            res.send(304);
        }
        else {
            commonCtrl.showFile(req.session.token, fileId, res);
        }

    })

    /**
     * 分享弹窗
     */
    app.get('/km/share', authorize, function (req, res, next) {
        res.render('common/share', function (err, html) {
            console.log(err);
            res.send(html);
        })
    });

    /**
     * 分享
     * flag 1:知识点
     * id  知识点id
     */
    app.post('/km/share/:flag/:id', authorize, function (req, res, next) {
        commonCtrl.share(req.session.token, req.params, req.body, function (result) {
            res.json(result);
        });
    });

    /**
     * 上传文件
     */
    app.post('/files/upload', authorize, require('../middleware/formHandle')(), function (req, res, next) {
        commonCtrl.uploadFiles(req.session.token, req, function (err, result) {
            console.debug(err, result)
            if (err) {
                next(err);
            } else {
                res.send(result.data);
            }

        });
    });

    /**
     * 下载文件
     * fileId 文件id
     * knowledgeId 知识点id
     */
    app.get('/files/download/:fileId/:knowledgeId', authorize, function (req, res, next) {
        commonCtrl.downloadFile(req.session.token, req.params.fileId, req.params.knowledgeId, req, res, function(err) {
            next(err);
        });
    });
    /**
     * 删除文件
     * id 文件id
     */
    app.post('/files/delete/:id', authorize, function (req, res, next) {
        commonCtrl.deleteFiles(req.session.token, req.params.id, function (result) {
            res.json(result);
        });
    });
    /**
     * 任务弹窗
     * tasktype 0 新增 1 转为 2 编辑
     */
    app.get('/km/taskbox/:tasktype', authorize, function (req, res, next) {
        res.render('common/task-box', {tasktype: req.params.tasktype, sourceType: req.query.sourceType}, function (err, html) {
            res.send(html);
        });
    });


    /**
     * 上传图片
     */
    app.post('/editor/image', authorize, function (req, res, next) {
        var config = require("../config"),
            fileMaxSize = config.km.fileMaxSize;

//        console.debug(req.get("payload"));
        if (req.get("Content-Length") > fileMaxSize) {
            var str = "{'size': '" + req.get("Content-Length") + "','state':'文件超出" + fileMaxSize / 1024 / 1024 + "M限制'}";
            res.send(str);
        } else {
            var fs = require("fs");
            var multiparty = require("multiparty");
            var form = new multiparty.Form();
            form.parse(req);
            form.on("file", function (name, file) {
                var originalFilename = file.originalFilename;
                var output;
                if (originalFilename && /.(jpg|png|gif|jpeg)$/im.test(originalFilename)) {
                    commonCtrl.uploadImage(req.session.token, file.fieldName, fs.createReadStream(file.path), {filename: originalFilename}, function (err, result) {
                        fs.existsSync(file.path) && fs.unlink(file.path);//删除临时文件
                        if (err) next(err);
                        else {
                            if (result.data) {
                                output = "{'url': '/files/show/" + result.data.id + "','state':'SUCCESS'}";
                                res.send(output);
                            } else {
                                output = "{'state':'" + result.message + "'}";
                                res.send(output);
                            }
                        }
                    });
                }
                else {
                    output = "{'state':'上传格式不符合要求,请上传jpg或png或gif的图片'}";
                    res.send(output)
                }
            })


        }
    });

    /**
     * RTX弹出页面
     * 仅供RTX门口使用，局限get请求，受+号被过滤影响
     */
    var url = require('url');
    var loginCtrl = require('../controllers/login');
    app.get('/rss', function (req, res, next) {
        var ip = req.ip;
        var params = url.parse(req.url).query.split('&');

        console.log("useraccount:" + params[0].substring(8));
        console.log("sign:" + params[1].substring(5).replace(/\+/g, '%2B'));

        var useraccount = params[0].substring(8);
        var sign = params[1].substring(5).replace(/\+/g, '%2B');

        loginCtrl.loginByRTX(req, useraccount, sign, ip, function (err, result) {
            if (err) next(err);
            else {
                commonCtrl.getRSSIndex(req.session.token, req.session.userId, function (err, result2) {
                    if (err) next(err);
                    else {
                        result2.userName = req.session.userName;
                        res.render('rss/index.ejs', {viewModel: result2});
                    }
                })
            }
        })
    });

    /**
     * RTX快速登录KM
     */
    app.post('/rtxLogin', function (req, res, next) {
        var ip = req.ip;
        var username = req.body.username;
        var sign = req.body.sign;

        loginCtrl.loginByRTX(req, username, sign, ip, function (err, result) {
            if (err) {
                res.render('login/index');
            } else {
                res.locals.session = req.session;
                res.redirect("/");
            }
        })
    });

    //获取分页脚本
    app.get("/common/paging", authorize, function (req, res, next) {
        res.render('common/paging', {paging: req.query.paging});
    });
}