/**
 * Created by yanyuan.liu
 */
var voteCtrl=require("../controllers/vote");
var helper=require("../utils/helper");
var authorize = require("../middleware/authorize");

module.exports=function(app){
    //添加投票页
    app.post('/vote/addVotePage', function(req, res, next) {
        res.render('vote/addVote',function(err,html){
            if(err){
                next(err);
            }else{
                var result = {html:html};
                res.send(result);
            }
        });
    });

    //添加投票
    app.post('/vote/addVote', function(req, res, next) {
        voteCtrl.addVote(req.session.token, req.body, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //投票列表页
    app.get('/vote/voteList', authorize, function(req, res, next) {
        var params = {limit:10,page:1};
        voteCtrl.getVoteList(req.session.token,params,function(err,result){
            if(err){
                next(err);
            }else{
                console.log(result.hotVote);
                result.hotVote.paging = {
                    total: Math.ceil(result.hotVote.count / params.limit),
                    limit: 8
                };
                result.newVote.paging = {
                    total: Math.ceil(result.newVote.count / params.limit),
                    limit: 8
                };
                require("util").inspect(result);
                res.render('vote/vote',{viewModel:result});
            }
        });
    });

    //引入投票、添加投票页
    app.get('/vote/select-add-vote', function(req, res, next) {
        var params = {limit:6,page:1};
        var type = 2; //1:最热投票，2:最新投票
        var groupid = req.query.groupid;
        voteCtrl.getVoteForType(req.session.token,groupid,type,params,function(err,result){
            if(err){
                next(err);
            }else{
                result.paging = {
                    total: Math.ceil(result.count / params.limit),
                    limit: 8
                };
                res.render('vote/selectAddVote',{viewModel:result},function(err,html){
                    if(err){
                        next(err);
                    }else{
                        var rst = {html:html};
                        res.send(rst);
                    }
                });
            }
        });
    });

    //投票列表（热门、最新）分页模板路由
    app.get("/vote/voteList/:type",function(req,res,next){
        var type = req.params.type;     //1：热门，2：最新
        voteCtrl.getVoteForType( req.session.token,type,req.query,function(err,result){
            if(err){
                next(err);
            }else{
                res.render('vote/voteList',{data:result.data},function(err, html) {
                    res.send(html);
                });
            }
        });
    });

    //获取单个投票详情html
    app.get("/vote/voteDetail",function(req,res,next){
        res.render("vote/voteDetail",{vote:req.body.vote},function(err,html){
            console.log(html);
            res.send(html);
        });
    });

    //进行投票
    app.post("/vote/cast-vote",function(req,res,next){
        voteCtrl.castVote(req.session.token,req.body,function(err,result){
            if(err){
                next(err);
            }else{
                if(result.success){
                    res.render('vote/voteDetail',{vote:result.data.vote},function(err,html){
                        result.html = html;
//                        console.log(result);
                        res.json(result);
                    })
                }
                if(result.isChecked || !result.success){
                    res.json(result);
                }
            }
        })
    })
}

