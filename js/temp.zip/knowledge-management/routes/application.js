/**
 * Created by peng.xie on 16-2-28.
 */
var authorize = require('../middleware/authorize');
var applicationCtrl = require('../controllers/application');
module.exports = function (app) {
    /**
     * 应用中心首页
     */
    app.get("/application", authorize, function (req, res, next) {
        res.render('application/index');
    });
    /**
     * 游戏页面
     */
    app.get("/application/play/:name", authorize, function (req, res, next) {
        res.render('application/playing', {viewModel: {name: req.params.name}});
    });

    app.post("/application/flappy_bird/addScore", authorize, function (req, res, next) {
        applicationCtrl.FB_addScore(req.session.token, req.body, function (err, result) {
            if (err) next(err);
            else {
                res.send(result);
            }
        });
    });

    app.post("/application/flappy_bird/queryTop", authorize, function (req, res, next) {
        applicationCtrl.FB_queryTop(req.session.token, function (err, result) {
            if (err) next(err);
            else {
                res.send(result);
            }
        });
    });

    app.post("/application/flappy_bird/queryTopList", authorize, function (req, res, next) {
        applicationCtrl.FB_queryTopList(req.session.token, function (err, result) {
            if (err) next(err);
            else {
                res.send(result);
            }
        });
    });
}