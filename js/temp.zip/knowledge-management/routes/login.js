var loginCtrl = require('../controllers/login');

//console.log("loginCtrl" + loginCtrl);
module.exports = function (app) {

    //login 首页
    app.get("/login", function (req, res, next) {
        if (req.session && req.session.token) {
            loginCtrl.checklogin(req, function (err) {
                if (err) {
                    res.render('login/index');
                } else {
                    res.locals.session = req.session;
                    res.redirect("/");
                }
            });

        }
        else {
            res.render('login/index');
        }

    });

    //判断用户是否登录
    app.get('/checklogin', function (req, res, next) {

        //console.log('loginCtrl-checklogin');
        loginCtrl.checklogin(req, function (err) {
            console.log(err);

            if (err) {
                //next(err);
                res.json({
                    code: 1,
                    msg: '用户没有登录'
                });
            } else {
                res.json({
                    code: 0,
                    msg: '用户已经登录'
                });
            }
        });
    });

    app.post('/loginaction', function (req, res, next) {

        //console.log('loginCtrl-checkLogin');
        loginCtrl.loginaction(req, function (err) {
            console.log(err);

            if (err) {
                //next(err);
                res.json({
                    code: 1,
                    msg: '用户名或密码错误'
                });
            } else {
                res.json({
                    code: 0,
                    msg: '登录成功'
                });
            }
        });


    });

    app.get("/logout", function (req, res, next) {
        req.session.destroy();
        res.redirect("/login");
    })

}