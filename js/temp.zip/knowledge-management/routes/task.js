var taskCtrl = require('../controllers/task');
var authorize = require('../middleware/authorize');
var fs = require('fs');
var path = require('path');
var url = require('url');

module.exports = function (app) {


    //------小模块 开始------
    //ajax请求，得到整个html，再插入到页面中
    app.get('/ajax/task/count', authorize, function (req, res, next) {
        taskCtrl.getTaskCount(req.session.token, req.session.userId, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.json(result);
            }
        })
    });
    //------小模块 结束-------

    //个人任务首页
    app.get('/task/personal/home', authorize, function(req, res, next) {
        var sourceType = 1,
            sourceId = req.session.userId,
            params = {page: 1};

        taskCtrl.getPersonalTask(req.session.token, req.session.userId, 1, params, function (err, result) {

            if (err) {
                next(err);
            } else {
                result.paging = {
                    total: Math.ceil(result.count / params.limit),
                    limit: 8
                };
                res.render('personal/task/personal-task', {
                    task: result,
                    type: 1,
                    pageType: sourceType,
                    sourceId: sourceId
                })
            }
        });


    })


    //个人各状态任务

    app.get('/task/personal/status/:status', authorize, function(req, res, next) {
        var sourceType = 1,
            sourceId = req.session.userId,
            params = {};

        params.page = req.query.page || 1;

        taskCtrl.getPersonalTask(req.session.token, req.session.userId, req.params.status, params, function(err, result) {

            if(err) {
                next(err);
            } else {
                if(req.query.page) {
                    res.render('personal/task/task-piece', {items: result.data, type: req.params.status, pageType: sourceType, sourceId: sourceId})
                } else {
                    result.paging = {
                        total: Math.ceil(result.count / params.limit),
                        limit: 8
                    };
                    res.render('personal/task/task-list', {
                        task: result,
                        type: req.params.status,
                        pageType: sourceType,
                        sourceId: sourceId})
                }
            }
        })


    })

    //群组任务首页
    app.get('/task/group/:groupId/home', authorize, function(req, res, next){
        var sourceType = 2,
            sourceId = req.params.groupId,
            sourceName = req.query.groupName;
            params = {page: 1};

        taskCtrl.getUndoneGroupTask(req.session.token, sourceId, params, function(err, result) {
            if(err) {
                next(err);
            } else {
                result.paging = {
                    total: Math.ceil(result.count / params.limit),
                    limit: 8
                };
                res.render('personal/task/group-task', {
                    task: result,
                    type: 1,
                    pageType: sourceType,
                    sourceId: sourceId,
                    sourceName: sourceName,
                    powerType: req.query.powerType
                })
            }
        })


    })

    app.get('/task/group/:groupId/status/:status', authorize, function(req, res, next) {
        var sourceType = 2,
            sourceId = req.params.groupId,
            status = req.params.status,
            params = {};

        params.page = req.query.page || 1;

        taskCtrl.getGroupTask(req.session.token, sourceId, status, params, function(err, result) {
            if(err) {
                next(err);
            } else {
                if(req.query.page) {
                    res.render('personal/task/task-piece', {
                        items: result.data,
                        type: status,
                        pageType: sourceType,
                        sourceId: sourceId,
                        powerType: req.query.powerType
                    })
                } else {
                    result.paging = {
                        total: Math.ceil(result.count / params.limit),
                        limit: 8
                    };
                    res.render('personal/task/task-list', {
                        task: result,
                        type: status,
                        pageType: sourceType,
                        sourceId: sourceId,
                        powerType: req.query.powerType
                    })
                }
            }
        })
    })



    //新增任务
    app.post('/task/add', authorize, function (req, res, next) {

        //sourceType 和 sourceId 没传参时默认为个人
        req.body.sourceType = req.body.sourceType || 1;
        req.body.sourceId = req.body.sourceId || req.session.userId;
        req.body.sourceName = req.body.sourceName || req.session.userName;


        taskCtrl.addTask(req.session.token, req.body, req, function (err,result) {
            if (err) {
                next(err);
            } else {
                res.json(result);
            }
        })
    });






    //认领任务
    app.post('/task/:taskId/claim', authorize, function(req, res, next) {
        taskCtrl.claimTask(req.session.token, req.params.taskId, function(err, result) {
            if(err) {
                next(err)
            } else {
                res.json({success: true});
            }
        })
//        res.json({success: true});
    })
   //开启任务
    app.post('/task/:taskId/start', authorize, function(req, res, next) {
        taskCtrl.startTask(req.session.token, req.params.taskId, function(err, result) {

            if(err) {
                next(err)
            } else {
                res.json({success: true});
            }
        })
    })
    //完成任务
    app.post('/task/:taskId/finish', authorize, function(req, res, next) {
        taskCtrl.finishTask(req.session.token, req.params.taskId, req.body, req, function(err, result) {
            if(err) {
                next(err)
            } else {
                res.json({success: true});
            }
        })
    })

    //重启任务
    app.post('/task/:taskId/restart', authorize, function(req, res, next) {
        taskCtrl.restartTask(req.session.token, req.params.taskId, function(err, result) {
            if(err) {
                next(err)
            } else {
                res.json({success: true});
            }
        })
    });

    //审核任务
    app.post('/task/:taskId/check/:check', authorize, function(req, res, next) {
        taskCtrl.checkTask(req.session.token, req.params.taskId, req.params.check, function(err, result) {
            if(err) {
                next(err)
            } else {
                res.json({success: true});
            }
        })
    })

    //优先级设置
    app.post('/task/:taskId/priority/:priority', function(req, res, next) {
        taskCtrl.setTaskPriority(req.session.token, req.params.taskId, req.params.priority, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.json({success: true});
            }
        })
    })






    //任务的回复列表
    app.get('/task/replys/:id', authorize, function (req, res, next) {




        taskCtrl.getTaskReplys(req.session.token, req.params.id, req.query, function (err, result) {

            if (err) {
                next(err);
            } else {

                res.render('personal/task/taskReply', {items: result.data});
            }

        });


    });

    //提交回复任务
    app.post('/task/reply', authorize, function (req, res, next) {
        var data = req.body;
        data.userName = req.session.userName;
        data.userId = req.session.userId;
        taskCtrl.postTaskReply(req.session.token, data, function (err, result) {
            if (err) {
                next(err);
            } else {
                res.render('personal/task/taskReply', {items: [result]});
            }

        });
    });
    //删除我发起任务
    app.post('/task/:taskId/delete', authorize, function (req, res, next) {
        taskCtrl.deleteTask(req.session.token, req.params.taskId, function (err, result) {
            if(err) {
                next(err);
            } else {
                res.json({success: true});
            }

        });
//        res.json({success: true});
    });

    //编辑任务
    app.post('/task/modify/:sourceType', authorize, function (req, res, next) {

        taskCtrl.modifyTask(req.session.token, req.body, req, function (err, result) {
            if(err) {
                next(err);
            } else {
                res.json({success: true});
            }
        })
//        res.json({success: true});

    });
    //搜索任务
    app.get('/task/search', authorize, function (req, res, next) {
        taskCtrl.searchTask(req.session.token, req.query, function (err, result) {

            if (err) {
                next(err);
            } else {

                res.render('personal/task/task-piece', {items: result.data, type: req.query.status, pageType: 1, sourceId: req.session.userId});
            }

        });
    });


    app.get('/group/:groupId/members/selectBox', authorize, function(req, res, next) {
        var data = req.query;
        taskCtrl.getGroupMembers(req.session.token, req.params.groupId, function(err, result) {
            if(err) {

                next(err);
            } else {

                res.render('common/tabBox', {data: result.data, oldData: data.oldData, type: ["groupMembers"]})
            }
        })
    })


    app.get('/task/allot', authorize, function(req, res, next) {
        res.render('personal/task/task-allot');
    });

    app.post('/task/:taskId/allot', authorize, function(req, res, next) {
        taskCtrl.allotTask(req.session.token, req.params.taskId, req.body, req, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.json({success: true});
            }
        })
    })

}