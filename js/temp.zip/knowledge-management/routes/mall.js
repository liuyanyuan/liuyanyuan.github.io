var authorize = require("../middleware/authorize");
var mallCtrl = require("../controllers/mall");

module.exports = function (app) {

    //积分商城 首页
    app.get("/mall",authorize, function (req, res, next) {
        res.render('mall/index');
    });

    //积分商城 详情页
    app.get("/mall/exchange/detail/:id",authorize, function (req, res, next) {
        var id = req.params.id;

        mallCtrl.getExchangeItemDetail( req.session.token, id, function(err,result){
            if(err){
                next(err);
            }else{
                //console.log("-------------getExchangeItemDetail=------------------------");
                //console.log(result);

                res.render('mall/jifen-exchange-item-detail', {result:result});
            }
        });
    });

    //积分竞拍历史 详情页
    app.get("/mall/auction/detail/:id",authorize, function (req, res, next) {
        var id = req.params.id;

        res.render('mall/jifen-auction-item-detail', {result:id});
    });

    //积分竞拍历史 解析 jifen-auction.ejs - ajax
    app.get("/ajax/mall/auction/detail/:id",authorize, function (req, res, next) {
        var id = req.params.id;

        console.log(id)
        mallCtrl.getAuctionItemDetail( req.session.token, id, function(err,result){
            if(err){
                next(err);
            }else{
                //console.log("积分竞拍历史 解析 jifen-auction.ejs - ajax积分竞拍历史 解析 jifen-auction.ejs - ajax")
                //console.log(result)
                res.render('mall/jifen-auction', {result:result});
            }
        });
    });

    //积分兑换列表 - ajax
    app.get("/ajax/mall/exchange/list/",authorize, function (req, res, next) {
        var params = {
            page : req.param("page"),
            limit : req.param("limit"),
            order : req.param("order")
        };

        mallCtrl.getExchangeList( req.session.token, req.session.userId, params, function(err,result){
            if(err){
                next(err);
            }else{
                //console.log("-------------getExchangeList=------------------------");
                //console.log(result);

                res.render('mall/jifen-exchange', {
                    result:{
                        exchangeList : result.exchangeList,
                        scoreAndExp : result.scoreAndExp
                    }
                });
            }
        });
    });

    //竞拍历史 - ajax
    app.get("/ajax/mall/auction/history/",authorize, function (req, res, next) {
        mallCtrl.getAuctionHistory( req.session.token,function(err,result){
            if(err){
                next(err);
            }else{
                //console.log("-------------getAuctionHistory=------------------------");
                //console.log(result);

                if( result.data.length == 0 ){
                    res.end("暂无数据");
                }else{
                    res.render('mall/jifen-auction-history', {result:result});
                }
            }
        });
    });

    //积分兑换 - 热门兑换 - ajax
    app.get("/ajax/mall/exchange/recommend/",authorize, function (req, res, next) {
        mallCtrl.getExchangeHot( req.session.token,function(err,result){
            if(err){
                next(err);
            }else{
                if( result.data.length == 0 ){
                    res.end("暂无数据");
                }else{
                    res.render('mall/jifen-exchange-recommend', {result:result});
                }
            }
        });
    });

    ////获取 正在 积分竞拍 的id - ajax
    app.get("/ajax/mall/auction/now/",authorize, function (req, res, next) {
        mallCtrl.getNowAuctionItemId( req.session.token,function(err,result){
            if(err){
                next(err);
            }else{
                res.send(result);
            }
        });
    });

    //积分兑换 兑换按钮 - ajax
    app.get("/ajax/mall/exchange/buy/:id",authorize, function (req, res, next) {
        var id = req.params.id;
        var params = {
            num : req.param("num") || 1
        };

        mallCtrl.exchangeItemBuy( req.session.token, id, params, function(err,result){
            if(err){
                next(err);
            }else{
                res.send(result);
            }
        });
    });

    //积分竞拍 竞拍按钮 - ajax
    app.get("/ajax/mall/auction/buy/:id",authorize, function (req, res, next) {
        var id = req.params.id;
        var params = {
            score : req.param("score"),
            shipmentId : req.param("shipmentId")
        };

        mallCtrl.auctionItemBuy( req.session.token, id, params, function(err,result){
            if(err){
                next(err);
            }else{
                res.send(result);
            }
        });
    });

    /*---------- by ruojun -----------*/

    //积分历史首页
    app.get('/mall/user/score', authorize, function(req, res, next) {
        mallCtrl.getUserScore(req.session.token, req.session.userId, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.render('mall/my-score', {viewModel: result});
            }
        })
    });

    //积分历史分页
    app.get('/score/history', authorize, function(req, res, next) {
        mallCtrl.getScoreHistory(req.session.token, req.session.userId, req.query, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.render('mall/score-list', {scoreData: result.data});
            }
        })
    });

    //积分历史搜索
    app.get('/score/history/search', authorize, function(req, res, next) {
        mallCtrl.searchScore(req.session.token, req.session.userId, req.query, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.render('mall/score-list', {scoreData: result.data}, function(err, html) {
                    res.json({html: html, count: result.count})
                });
            }
        })
    })

};