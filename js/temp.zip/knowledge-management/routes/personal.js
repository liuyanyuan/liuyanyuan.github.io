var personalCtrl = require('../controllers/personal');
var authorize = require('../middleware/authorize');

module.exports = function (app) {

    //------小模块 开始------
    //ajax请求，得到整个html，再插入到页面中

    app.get('/ajax/personal/avatar', authorize, function (req, res, next) {
        var userId = req.query.userId || req.session.userId;
        personalCtrl.getUserInfo(req.session.token, userId, function (err, results) {
            if (err) {
                next(err);
            } else {
                res.render('home/avatar',{
                    userInfo: results.userInfo.data,
                    scoreAndExp: results.scoreAndExp.data || {}
                });
            }
        });
    });

    //------小模块 结束-------

    //------小模块 开始------

    app.get('/ajax/personal/exchange/list', authorize, function (req, res, next) {
        personalCtrl.getEcList(req.session.token, req.query, function (err, result) {
            if (err) {
                next(err);
            } else {
                if(!result.data.length) {
                    res.end('暂无数据');
                } else {
                    res.render('home/exchange',{
                        exchange: result.data
                    });
                }

            }
        });
    });

    //------小模块 结束-------




    //首页
    app.get('/', authorize, function (req, res, next) {
        res.render('home/index', {
            userInfo: {id: req.session.userId, name: req.session.userName}
        });
    });

    //获取全部动态
    app.get('/personal/trend', authorize, function(req, res, next) {
        personalCtrl.getMoreMsg(req.session.token, req.session.userId, 0, req.query, function (err, result) {

            if (err) {
                next(err);
            } else {
                console.log(result)
                res.render('home/trend/trend-box', {
                    trends: {type: 0, data: result.trends.data},
                    unreadMsg: result.unreadMsg
                }, function (err, html) {
                    res.json({html: html, max: result.trends.max});
                });
            }

        });
    });
    //获取个人动态
    app.get('/users/:userId/trends', authorize, function(req, res, next) {

        personalCtrl.getUserTrends(req.session.token, req.params.userId, req.query, function(err, result) {

            if(err) {
                next(err);
            } else {
                res.render('home/trend/trend-box', {trends: {type: 2, data: result.data}}, function(err, html){
                    res.json({html: html, max: result.max});
                })
            }
        })
    })

    //滚动加载动态
    app.get('/personal/:userId/message/:type', authorize, function (req, res, next) {
        personalCtrl.getMoreMsg(req.session.token, req.params.userId, req.params.type, req.query, function (err, result) {

            if (err) {
                next(err);
            } else {
                res.render('home/trend/trend-list-2', {trends: {type: req.params.type, data: result.trends.data}}, function (err, html) {
                    res.json({html: html, max: result.trends.max});
                });
            }

        });
    });

    //个人动态搜索
    app.get('/personal/search', authorize, function (req, res, next) {

        var data = req.query;
        personalCtrl.getSearchTrend(req.session.token, req.query, function (err, result) {
            if (err) {
                next(err);
            } else {
                res.render('home/trend/trend-list', {trends: {type: data.type, data: result.data}}, function (err, html) {
                    res.json({html: html, max: result.max});
                });
            }

        });
    });

    app.post('/personal/trend/applaud', authorize, function(req, res, next) {

        personalCtrl.applaudTrend(req.session.token, req.body, function(err, result) {
            if(err) {
                next(err);
            } else {
                res.json(result);
            }
        });
    });

    //回答动态

    app.post('/personal/trend/answers', authorize, function(req, res, next) {

        if(req.body.type == 1) {
            req.body.params.userId = req.session.userId;
            req.body.params.userName = req.session.userName;
        }
        personalCtrl.answerTrend(req.session.token, req.session.userId, req.body, function(err, result) {

            if(err) {
                next(err);
            } else {

                res.render('home/trend/answer', {answers: {data: [result.data]}, type: req.body.type});
            }
        })
    })


    /**
     * todo 有问题
     * 顶或踩回答
     */
    app.post('/personal/voteAnswer', authorize, function (req, res, next) {
        personalCtrl.voteAnswer(req.session.token, req.body, function (result) {
            res.json(result);
        });
    });


    /**
     * 发表评论
     */
    app.post('/personal/msg/reply', authorize, function (req, res, next) {
        var data = req.body.data || req.body;
        var replyType = req.body.replyType || null;

        personalCtrl.addMsgReply(req.session.token, req.session.userId, data, function (err, result) {
            if (err) {
                next(err);
            } else {

                result.data.userName = req.session.userName;
                result.data.sonListTotal = 0;
                if (!!data.info.parentId) {
                    result.data.parentUserName = req.body.parentUserName;
                    result.data.parentUserId = req.body.parentUserId;
                    res.render('common/reply', {sonlist: [result.data]});
                }else if(replyType == "topic"){
                    res.render('group/replyList', {data: [result.data]});
                } else {

                    if (data.pageStr == 'detailedQuestion') {
                        res.render('question/template/answers', {answers: {'isMyQuestion': req.body.parentUserId==req.session.userId, data: [result.data]}});
                    }else if(data.pageStr == 'questionIndex'){
                        res.render('question/template/index-answer', {answers:{data: [result.data]}});
                    } else {
                        res.render('home/answer', {answers: {data: [result.data]}, type: data.type});
                    }

                }
            }

        });

    });

    //获取评论列表
    app.get('/personal/qaMsg/answers', authorize, function (req, res, next) {

        personalCtrl.getMsgReply(req.session.token, req.query, function (err, result) {
            if (err) {
                next(err);
            } else {
                res.render('home/trend/answer', {answers: { data: result.data}, type: req.query.type});
            }

        });

    });


    //个人模块首页
    app.get('/personal', authorize, authorize, function (req, res, next) {

        personalCtrl.getPersonal(req.session.token, req.session.userId, function (err, result) {

            if (err) {
                next(err);
            } else {


                res.render('personal/index', {
                    userInfo: result.userInfo.data,
                    userId: req.session.userId,
                    knowledgeLevelCount: result.knowledgeLevelCount.data,
                    user: {visitorRight: 1, id: req.session.userId}
                });

            }

        });
    });

    //访问别人的首页
    app.get('/user/:userId/home', authorize, function(req, res, next) {
        if(req.params.userId == req.session.userId) {
            res.redirect('/personal');
        } else {
            personalCtrl.getPersonal(req.session.token, req.params.userId, function(err, result) {
                if(err) {
                    next(err);
                } else {
                    res.render('personal/index', {
                        userInfo: result.userInfo.data,
                        userId: req.session.userId,
                        basicInfo: result.basicInfo,
                        knowledgeLevelCount: result.knowledgeLevelCount.data,
                        user: {visitorRight: 2, id: req.params.userId}
                    });

                }
            })
        }

    })

    //获取我的资料
    app.get('/users/:userId/info', authorize, function (req, res, next) {

        personalCtrl.getUsersInfo(req.session.token, req.params.userId, function (err, results) {
            if (err) {
                next(err);
            } else {
                var visitorRight = 1;
                if(req.params.userId != req.session.userId) {
                    visitorRight = 2;
                }

                res.render('personal/data/mydata', {
                    restInfo: results.restInfo.data,
                    basicInfo: results.basicInfo,
                    visitorRight: visitorRight}
                );
            }

        });
    });

    //修改我的资料
    app.post('/users/info', authorize, function (req, res, next) {

        personalCtrl.updateUsersInfo(req.session.token, req.session.userId, req.body, function (result) {
            res.json(result);
        });
    });

    //上传头像
    app.post('/upload/avatar', authorize, function (req, res, next) {
        res.set('Content-Type', 'text/html');
        personalCtrl.uploadAvatar(req.session.token, req.session.userId, req, function (result) {

            res.json(result);
        });
    });

    //修改用户密码
    app.post('/update/password', authorize, function (req, res, next) {
        personalCtrl.updatePassword(req.session.token, req.session.userId, req.body, function (result) {
            res.json(result);
        });
    });





    //我的问答
    app.get('/users/qa', authorize, function (req, res, next) {
        var params = {limit: 1, page: 1};
        personalCtrl.getQuestions(req.session.token, req.session.userId, params, function (err, result) {
            if (err) {
                next(err);
            } else {
                result.publishQa.paging = {total: Math.ceil(result.publishQa.count / params.limit), limit: 8};
                result.favouriteQa.paging = {total: Math.ceil(result.favouriteQa.count / params.limit), limit: 8};
                result.replyQa.paging = {total: Math.ceil(result.replyQa.count / params.limit), limit: 8};
                res.render('personal/question/myqa', {
                    publishQa: result.publishQa,
                    favouriteQa: result.favouriteQa,
                    replyQa: result.replyQa
                });
            }

        });

    });

    app.get('/users/questions/:type', authorize, function (req, res, next) {

        personalCtrl.getMoreQuestions(req.session.token, req.session.userId, req.params.type, req.query, function (err, resutl) {
            if (err) {
                next(err);
            } else {
                res.render('personal/question/qatbody', {items: resutl.data, type: req.params.type}, function (err, html) {
                    res.json(html);
                })
            }

        });
    });

    app.post('/delete/question', authorize, function (req, res, next) {
        personalCtrl.deleteQuestion(req.session.token, req.session.userId, req.body, function (result) {
            res.json(result);
        });
    });


    //我的知识库
    app.get('/users/:userId/knowledge', authorize, authorize, function (req, res, next) {

        req.query.attachedId = req.params.userId;
        personalCtrl.getPersonalKnowledge(req.session.token, req.query, function (err, result) {
            if (err) {
                next(err);
            } else {
                result.attachedType = req.query.attachedType;
                result.attachedId = req.query.attachedId;
                var powerType = 0;
                if(req.params.userId == req.session.userId) {
                    powerType = 1;
                }
                res.render('personal/knowledge/knowledges', {
                    knowledge: result,
                    powerType: powerType,
                    authType: '',
                    userId: req.session.userId
                })
            }

        })
    });

    app.get('/knowledge/list', authorize, function (req, res, next) {
        personalCtrl.getPersonalKnowledge(req.session.token, req.query, function (err, result) {
            if (err) {
                next(err);
            } else {
                res.render('personal/knowledge/knowledge-list', {
                    knowledge: result.data,
                    authType: req.query.authType,
                    powerType: req.query.powerType,
                    userId: req.session.userId
                })
            }
        })
    })
    //上传文件到知识库
    app.post('/personal/knowledge/upload/:sceneType', authorize, require('../middleware/formHandle')(), function (req, res, next) {

        res.set('Content-Type', 'text/html;charset=UTF-8');
        personalCtrl.uploadFiles(req.session.token, req, function (err, result) {

            if (err) {
                next(err);
            } else {
                res.render('common/knowledge-form', {
                    doc: result.data,
                    sceneType: req.params.sceneType,
                    knowType: 1,
                    knowledge: {}
                });
            }
        });


    });

    app.get('/knowledge/personal/create', authorize, function (req, res, next) {

        res.render('common/knowledge-form', {
            sceneType: 1,
            knowType: 2,
            doc: {},
            knowledge: {}
        });
    });

    //新增知识点
    app.post('/add/knowledge', authorize, function (req, res, next) {
        var type = req.body.knowledge.type + '';
        if (type == '1' || type == '13'|| type == '30') {
            req.body.knowledge.attachedId = req.session.userId;
        }

        personalCtrl.addKnowledge(req.session.token, req.body, function (err, result) {


            if (err) {
                next(err);
            } else if(result.getFile.message) {
                res.json({success: false, html: result.getFile.message});
            } else {

                if(req.body.entrance != 1) {        //公共知识库的入口  弹出框tip
                    res.render('knowledge/template/knowledge-tip', {knowledge: result.getFile.data}, function(err, html) {
                        res.json({success: true, html: html});
                    })
                } else if(req.body.entrance == 1) {   //非公共知识库的入口
                    res.render('personal/knowledge/knowledge-list', {
                        knowledge: [result.getFile.data],
                        powerType: req.body.powerType,
                        authType: req.body.authType,
                        userId: req.session.userId
                    }, function (err, html) {
                        res.json({success: true, html: html});
                    })
                }

            }

        });
    })

    //更新知识点
    app.post('/update/knowledge/:knowledgeId', authorize, function (req, res, next) {
        if (req.body.knowledge.type !== '2' && req.body.knowledge.type !== '23') {
            req.body.knowledge.attachedId = req.session.userId;
        }

        personalCtrl.updateKnowledge(req.session.token, req.body, req.params.knowledgeId, function (err, result) {

            if(err) {
                next(err);
            } else {
                res.json(result)
            }

        })
    });
    //新建目录
    app.post('/knowledge/personal/catalog/add', authorize, function (req, res, next) {

        personalCtrl.addCatalog(req.session.token, req.body, function (err, result) {
            if (err) {
                next(err);
            } else {
                if(result.success) {

                    result.data.flag = 1;
                    res.render('personal/knowledge/knowledge-list', {
                        knowledge: [result.data],
                        powerType: 0,
                        authType: 0,
                        userId: req.session.userId
                    }, function (err, html) {

                        result.html = html;
                        res.json(result);
                    })
                } else {
                    res.json(result);
                }

            }

        })
    });
    //编辑目录
    app.post('/catalog/edit', authorize, function (req, res, next) {
        if(req.body.attachedType == 1) {
            req.body.attachedId = req.session.userId;
        }
        personalCtrl.editCatalog(req.session.token, req.body, function (err, result) {

            if(err) {
                next(err);
            } else {
                res.json(result);
            }

        });
    });
    //删除目录
    app.post('/catalog/delete', authorize, function (req, res, next) {
        personalCtrl.deleteCatalog(req.session.token, req.body, function (err, result) {
            if(err) {
                next(err);
            } else {
                res.json(result);
            }

        })
    })
    //获取知识点
    app.get('/knowledge/doc', authorize, function (req, res, next) {

        personalCtrl.getDocKnowledge(req.session.token, req.query.id, function (err, result) {
            if (err) {
                next(err);
            } else {

                if (result) {

                    res.render('common/knowledge-form', {
                        doc: {},
                        sceneType: 1,
                        knowType: result.knowledgeType,
                        knowledge: result
                    });
                }
            }
        });
    })
    //获取目录树
    app.get('/knowledge/catalog', authorize, function (req, res, next) {

        personalCtrl.getCatalogTree(req.session.token, req.query, function (err, result) {

            if (err) {
                next(err);
            } else {
                var tree = {"id": 0, "name": "全部文件"};
                tree.children = result.data;
                res.render('personal/catalog-tree', {viewModel: tree})
            }

            //todo
        });
    })


    app.get('/knowledge/delete/tip', authorize, function(req, res, next) {
       res.render('personal/delete-knowledge-tip', {viewModel: req.query})
    });

    //获取知识库分类
    app.get('/knowledge/category', authorize, function (req, res, next) {

        personalCtrl.getCategory(req.session.token, function (err, result) {
            if (err) {

                next(err);
            } else {

                res.render('common/k-category', {viewModel: result.data[0]})
            }

        });
    });


    //我关注的人
    app.get('/users/:userId/following', authorize, function (req, res, next) {
        var params = {page: 1};
        personalCtrl.getFollowing(req.session.token, req.params.userId, params, function (err, result) {

            if (err) {
                next(err);
            } else {
                result.paging = {
                    total: Math.ceil(result.count / params.limit),
                    limit: 8
                };
                var visitorRight = 1;
                if(req.params.userId != req.session.userId) {
                    visitorRight = 2;
                }
                res.render('personal/follow/following', {
                    following: result,
                    visitorRight: visitorRight
                })
            }

        });
    });

    app.get('/users/:userId/following/page', authorize, function(req, res, next) {
        personalCtrl.getFollowing(req.session.token, req.params.userId,  req.query, function(err, result) {
            if(err) {
                next(err);
            } else {
                var visitorRight = 1;
                if(req.params.userId != req.session.userId) {
                    visitorRight = 2;
                }
                res.render('personal/follow/follow-list', {
                    items: result.data,
                    visitorRight: visitorRight
                })
            }
        })
    })

    //加关注
    app.post('/users/follow', authorize, function (req, res, next) {
        personalCtrl.addFollow(req.session.token, req.session.userId, req.body, function (err, result) {


            if (err) {
                res.json({success: false});
            } else {
                res.json({success: true});
            }
        })
    });

    //取消关注
    app.post('/users/follow/:id', authorize, function (req, res, next) {
        personalCtrl.cancelFollow(req.session.token, req.params.id, function (err, result) {

            if (err) {
                res.json({success: false});
            } else {
                res.json({success: true});
            }
        });
    })

    //我的群组
    app.get('/users/:userId/groups', authorize, function (req, res, next) {
        var params = {limit: 10, page: 1};
        personalCtrl.getMyGroup(req.session.token, req.params.userId, params, function (err, result) {
            if (err) {
                next(err);
            } else {
                result.paging = {
                    total: Math.ceil((result.count||0) / params.limit),
                    limit: 8
                };
                var visitorRight = 1;
                if(req.params.userId != req.session.userId) {
                    visitorRight = 2;
                }
                res.render('personal/group/myGroups', {
                    data:result.data,
                    paging:result.paging,
                    type:1,
                    visitorRight: visitorRight
                })
            }
        });
    })

    //我的群组分页路由
    app.get('/users/:userId/group-paging', authorize, function (req, res, next) {
        personalCtrl.getMyGroup(req.session.token, req.params.userId, req.query, function (err, result) {
            if (err) {
                next(err);
            } else {
                res.render('group/groupItem', {
                    data:result.data,
                    type:1
                })
            }
        });
    })

    //我的申请
    app.get('/users/apply', authorize, function (req, res, next) {
        var result = {
            code: '200',
            data: [
                {
                    id: '1',
                    type: '年度创新个人',
                    category: '运营专家',
                    userName: '琳达',
                    createTime: 1393832739056,
                    explain: '年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人2014-01-24',
                    doc: [
                        {id: 1, name: '琳达的申请说明.doc'},
                        {id: 2, name: '琳达的申请说明.doc'}
                    ]
                },
                {
                    id: '2',
                    type: '优秀技术官',
                    category: '技术专家',
                    userName: '琳达',
                    createTime: 1393832739056,
                    explain: '年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人年度创新个人2014-01-24',
                    doc: [
                        {id: 1, name: '琳达的申请说明.doc'},
                        {id: 2, name: '琳达的申请说明.doc'}
                    ]
                }
            ],
            count: 2
        }
        res.render('personal/application/apply', {applyList: result.data})
    });

    app.post('/users/apply', authorize, function (req, res, next) {

        personalCtrl.addApply(req.session.token, req.body, function (err, result) {
            if (err) {

            } else {
                res.render('personal/application/apply-list', result)
            }
        })
    });

    app.get('/knowledge/review/:id', authorize, function(req, res, next) {
        personalCtrl.previewKnowledge(req.session.token, req.params.id, function (err, result) {

            if (err) {
                next(err);
            } else {
                if (result) {

                    res.render('knowledge/template/knowledgeInfo', {data: result.data});
                }
            }
        });
    });
}


























