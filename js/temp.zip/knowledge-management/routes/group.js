/**
 * Created by shayne.gui on 13-12-28.
 */
var groupCtrl=require("../controllers/group");
var questionCtrl = require('../controllers/question');
var helper=require("../utils/helper");
var authorize = require("../middleware/authorize");

module.exports=function(app){
    //群组首页
    app.get("/group",authorize,function(req,res,next){
        console.log(req.session);
        var userId = req.session.userId;
        groupCtrl.getIndexData(req.session.token,function(err,results){
            if(err){
                next(err);
            }else{
                require("util").inspect(results);
                res.render('group/index',{viewModel:results,userId:userId});
            }
        })
    });

    app.get("/group/test",function(req,res,next){
        res.send(req.session.token+"\n"+req.session.userId);
    })

    //群组详细信息
    //authtype 0：不允许任何人，1：允许任何人，2：需要身份验证
    //powertype 0：普通成员，1：管理员，2：群创建者，3：游客
    app.get("/group/:groupId",authorize,function(req,res,next){
        var groupId = req.params.groupId;
        var userId = req.session.userId;
        var params = {
            topic:{limit: 20, page: 1},
            member:{limit: 10, page: 1},
            personnel:{limit:20, page: 1}
        };
        groupCtrl.getDetailData( req.session.token,groupId,params,function(err,result){
            if(err){
                next(err);
            }else{
                result.topics.paging = {
                    total: Math.ceil(result.topics.count / params.topic.limit),
                    limit: 8
                };
                result.members.paging = {
                    total: Math.ceil(result.members.count / params.member.limit),
                    limit: 8
                };
                result.personnel.paging = {
                    total: Math.ceil(result.personnel.count / params.personnel.limit),
                    limit: 8
                };
                require("util").inspect(result);
                var infoData = result.groupInfo.data || [];
                var powertype;
                var authtype;
                if(infoData.length > 0){
                    powertype = infoData[0].powerType;
                    authtype = infoData[0].authType;
                }
                if(result.groupInfo.code == 403){
                    res.render("error/403");
                }else if(authtype == 1 || powertype < 3){
                    res.render('group/groupDetail',{viewModel:result,group_id:groupId,userId:userId});
                }else{
                    res.render("error/error-com",{msg:result.groupInfo.message,title:"出错啦！"});
                }
            }
        });
    });

    //群组文档（知识库）
    app.get("/group/doc/list", authorize, function (req, res, next) {
        var powerType = req.query.powerType;
        var authType = req.query.authType;
        console.log(req.query);
        groupCtrl.getGroupDocs(req.session.token, req.query, function (err, result) {
            console.log(result.data);
            if (err) {
                next(err);
            } else {
                result.attachedType = 2;
                result.attachedId = req.query.attachedId;
                res.render('personal/knowledge/knowledges', {knowledge: result, powerType:powerType, authType:authType, userId: req.session.userId}, function (err, html) {
                    console.log(err);
                    res.send(html);
                })
            }

        })
    });

    //群组列表（搜索）
    app.get("/group-list/search",authorize,function(req,res,next){
        var keyword = req.query.keyword;
        var type = "search";
        var params = {limit: 10, page: 1};
        groupCtrl.getGroups(req.session.token,type,0,keyword,params,function(err,result){
            if(err){
                next(err);
            }else{
                result.groups.paging = {
                    total: Math.ceil((result.groups.count || 0) / params.limit),
                    limit: 8
                };
                require("util").inspect(result);
                res.render("group/groupList",{viewModel:result,keyword:keyword,type:type,categoryId:null});
            }
        });
    });

    //群组列表（群组分类）
    app.get("/group/category/list",authorize,function(req,res,next){
        var categoryId = req.query.categoryid;
        var keyword = req.query.keyword;
        var type = "category";
        var params = {limit: 10, page: 1};
        groupCtrl.getGroups(req.session.token,type,categoryId,null,params,function(err,result){
            if(err){
                next(err);
            }else{
                result.groups.paging = {
                    total: Math.ceil(result.groups.count / params.limit),
                    limit: 8
                };
                require("util").inspect(result);
                res.render("group/groupList",{viewModel:result,keyword:keyword,type:type,categoryId:categoryId});
            }
        });
    });

    //群组列表（搜索、群组分类分页路由)
    app.get("/group/category/list-paging/:type",authorize,function(req,res,next){
        var categoryId = req.query.categoryid;
        var keyword = req.query.keyword;
        var type = req.params.type;     //1：搜索，2：群组分类
        groupCtrl.getGroups_paging( req.session.token,type,categoryId,keyword,req.query,function(err,result){
            if(err){
                next(err);
            }else{
                res.render("group/groupItem",{data:result.data,type:2},function(err, html) {    //type 1:我的群组列表，2：群组首页、搜索页、群组分类列表
                    if(err){
                        console.log(err);
                    }else{
                        res.send(html);
                    }
                });
            }
        });
    });

    //群话题、成员分页路由
    app.get("/group/:groupId/groupInfos/:type",authorize,function(req,res,next){
        var groupId = req.params.groupId;
        var type = req.params.type;     //1：话题，2：成员，3：任务人员
        var powerType = req.query.powerType;
        var userId = req.session.userId;
        groupCtrl.getGroupInfos( req.session.token,groupId,type,req.query,function(err,result){
            if(err){
                next(err);
            }else{
                var url = {
                    1:"group/topicList",
                    2:"group/memberList",
                    3:"group/group-agileDev"
                }
                console.log(url[type]);
                res.render(url[type],{data:result.data,powerType:powerType,group_id:groupId,userId:userId},function(err, html) {
                    if(err){
                        console.log(err);
                    }else{
                        res.send(html);
                    }
                });
            }
        });
    });

    //添加成员成功后获取添加成功成员
    app.post("/group/memberInfo",authorize,function(req,res,next){
        var data = req.body.data;
        var powerType = req.body.powerType;
        var groupId = req.body.groupId;
        res.render("group/memberList",{data:data,powerType:powerType,group_id:groupId},function(err, html) {
            if(err){
                console.log(err);
            }else{
                res.send(html);
            }
        });
    });

    //话题详细信息（话题回复列表）
    app.get("/group/:groupId/topic/:topicId",authorize,function(req,res,next){
        var groupId = req.params.groupId;
        var topicId = req.params.topicId;
        var parmas = {limit:10,page:1};
        groupCtrl.getTopicDetailData(req.session.token,groupId,topicId,parmas,function(err,result){
            if(err){
                next(err);
                res.send("页面发生错误，请返回重试！");
            }else{
//                result.replys.paging = {
//                    total: Math.ceil(result.replys.count / parmas.limit),
//                    limit: 8
//                };
                require("util").inspect(result);
                var infoData = result.groupInfo.data || [];
                var powertype;
                var authtype;
                if(infoData.length > 0){
                    powertype = infoData[0].powerType;
                    authtype = infoData[0].authType;
                }
                if(result.groupInfo.code == 403){
                    res.render("error/403");
                }else if(authtype == 1 || powertype < 3){
                    res.render("group/topicDetail",{viewModel:result,group_id:groupId,topic_id:topicId});
                }else{
                    res.render("error/error-com",{msg:result.groupInfo.message,title:"出错啦！"});
                }
            }
        });
    });

    //话题回复分页路由
    app.get("/topics/:topicId/replys",authorize,function(req,res,next){
        var topicId = req.params.topicId;
        groupCtrl.getTopicReplys( req.session.token,topicId,req.query,function(err,result){
            if(err){
                next(err);
            }else{
                res.render("group/replyList",{data:result.data,count:result.count,limit:req.query.limit,page:req.query.page},function(err, html) {
//                    res.send(html);
                    res.json({html:html,page:req.query.page,count:result.count});
                });
            }
        });
    });

    //话题-发表评论
    app.post('/group/topic/reply',authorize, function (req, res, next) {
        var data = req.body.data || req.body;
        var replyType = req.body.replyType || null;
        console.log(data);
        groupCtrl.addTopicReply(req.session.token, req.session.userId, data, function (err, result) {
            if (err) {
                next(err);
            } else {
                //console.log(result);
                result.data.userName = req.session.userName;
                result.data.sonListTotal = 0;
                if (!!data.info.parentId) {
                    result.data.parentUserName = req.body.parentUserName;
                    result.data.parentUserId = req.body.parentUserId;
                    console.log('common');
                    res.render('group/reply', {sonlist: [result.data]}, function (err, html) {
                        res.send(html);
                    });
                }else if(replyType == "topic"){
                    console.log('group');
                    res.render('group/replyList', {data: [result.data],count:result.data.count,limit:0,page:0}, function (err, html) {
                        if(err){
                            console.error(err);
                        }
                        res.send(html);
                    });
                }
            }
        });
    });

    //添加群成员
    app.post('/group/addMember',authorize, function(req, res, next) {
        var data = req.body.data;
        if(data.length == 1 && data[0].userId == 0){
            data[0].userId = req.session.userId;
        }
        groupCtrl.addMember(req.session.token, req.body.groupid, data, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //申请加入群验证(同意或拒绝)
    app.post('/group/askforjoin',authorize, function(req, res, next) {
        var userId = req.body.userId;
        if(!userId){
            userId = req.session.userId;
        }
        console.log("userId-- "+userId);
        groupCtrl.askForJoin(req.session.token, userId, req.body.groupId, req.body.joinType, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //是否已申请加入群
    app.post('/group/join/isapply',authorize, function(req, res, next) {
        groupCtrl.isApplyJoinGroup(req.session.token, req.session.userId, req.body.groupId, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //踢出/群成员退出
    app.post('/group/delMember',authorize, function(req, res, next) {
        var userId = req.body.userId;
        var type = "del";
        if(userId == 0){ //userId = 0为用户自己退出群
            userId = req.session.userId;
            type = "exit";
        }
        groupCtrl.delMember(req.session.token, req.body.groupId, userId,type, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //取消或授权管理员（设置群员角色）
    app.post('/group/set-user-role',authorize, function(req, res, next) {
        console.log(req.body);
        groupCtrl.setUserRole(req.session.token, req.body.groupId, req.body.userId,req.body.role,function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //添加群话题页
    app.get("/group/:groupId/addTopic",authorize,function(req,res,next){
        var groupId = req.params.groupId;
        groupCtrl.getAddTopicData(req.session.token,groupId,function(err,result){
            if(err){
                next(err);
            }else{
                require("util").inspect(result);
                var infoData = result.groupInfo.data || [];
                var powertype;
                var authtype;
                if(infoData.length > 0){
                    powertype = infoData[0].powerType;
                    authtype = infoData[0].authType;
                }
                if(result.groupInfo.code == 403){
                    res.render("error/403");
                }else if(authtype == 1 || powertype < 3){
                    res.render("group/addTopic",{viewModel:{tabsData:result.tabsData},groupId:groupId,groupName:infoData[0].groupName,type:"add"});
                }else{
                    res.render("error/error-com",{msg:result.groupInfo.message,title:"出错啦！"});
                }
            }
        });
    });

    //编辑群话题页
    app.get("/group/:groupId/editTopic/:topicId",authorize,function(req,res,next){
        var groupId = req.params.groupId;
        var topicId = req.params.topicId;
        groupCtrl.getEditTopicData(req.session.token,groupId,topicId,function(err,result){
            if(err){
                next(err);
            }else{
                var topic_userId = result.topicInfo.data[0].userId;
                var current_userId = req.session.userId;
                require("util").inspect(result);
                var infoData = result.groupInfo.data || [];
                var powertype;
                if(infoData.length > 0){
                    powertype = infoData[0].powerType;
                }
                if(powertype != 1 && powertype != 2 && topic_userId != current_userId){
                    res.render("error/403");
                }else if( powertype > 0 && powertype < 3 || topic_userId == current_userId){
                    res.render("group/addTopic",{viewModel:{tabsData:result.tabsData,topicInfo:result.topicInfo},topicId:topicId,groupId:groupId,groupName:infoData[0].groupName,type:"edit"});
                }else{
                    res.render("error/error-com",{msg:result.groupInfo.message,title:"出错啦！"});
                }
            }
        });
    });

    //添加群话题
    app.post('/group/addTopic',authorize, function(req, res, next) {
        groupCtrl.addTopic(req.session.token, req.body.groupid, req.body.topic, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //编辑群话题
    app.post('/group/editTopic',authorize, function(req, res, next) {
        groupCtrl.editTopic(req.session.token, req.body, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //删除群话题
    app.post('/group/delTopic',authorize, function(req, res, next) {
        groupCtrl.delTopic(req.session.token, req.body.topicid, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //添加群组页
    app.get("/group/add/addGroup",authorize,function(req,res,next){
        questionCtrl.getOrganization(req.session.token, {}, function(err, result) {
            var userId = req.session.userId;
            if(err){
                next(err);
            }else{
                groupCtrl.getTabsData(req.session.token,function(err,rs){
                    if(err){
                        next(err);
                    }else{
                        res.render("group/addGroup",{viewModel:{tabsData:rs},data: result,userId:userId});
                    }
                });

            }
        });
    });

    //添加群组
    app.post('/group/addGroup',authorize, function(req, res, next) {
        groupCtrl.addGroup(req.session.token, req.body, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //解散群、删除群
    app.post('/group/delGroup',authorize, function(req, res, next) {
        groupCtrl.delGroup(req.session.token, req.body.groupId,function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //编辑群组
    app.post('/group/editGroup',authorize, function(req, res, next) {
        groupCtrl.editGroup(req.session.token, req.body.groupid,req.body.data, function(err,result) {
            if(err){
                next(err);
            }else{
                res.json(result);
            }
        });
    });

    //获取上传头像组件
    app.post('/group/uploadAvatar',authorize, function(req, res, next) {
        res.render('personal/data/uploadAvatar',req.body,function(err,html){
            if(err){
                next(err);
            }else{
                res.send(html);
            }
        });
    });

    //上传群组头像
    app.post('/group/setAvatar',authorize, function(req, res, next) {
        res.set('Content-Type', 'text/html');
        groupCtrl.uploadGroupAvatar(req.session.token, req, function(result) {
            res.json(result);
        });
    });

    //获取群组分类树
    app.get('/treeModel',authorize, function(req, res, next) {
        groupCtrl.getTreeModel(req.session.token,req.query.type,function(error,result) {
            res.render('personal/catalog-tree', {viewModel: result}, function(err, html) {
                if(err){
                    console.log(err);
                    res.send("获取群组分类失败！");
                }else{
                    res.send(html);
                }
            });
        });
    });

}

