/**
 * Created by yanyuan.liu.
 */
var expertCtrl = require("../controllers/expert");
var helper = require("../utils/helper");
var authorize = require("../middleware/authorize");

module.exports=function(app){
    //专家首页
    app.get("/expert",authorize, function(req, res, next){
        console.log(req.session);
        expertCtrl.getExpertData(req.session.token,function(err, result){
            if(err){
                next(err);
            }else{
                res.render("expert/index",{viewModel:result});
            }
        })
    });

    //提问
    app.get("/expert/addQuestion", authorize, function (req, res, next) {
        var type = parseInt(req.query.type);
        var userId = req.query.userid;
        var userName = req.query.username;
        type = type ? type : 1;
        res.render('question/template/addQuestion',{type:type,userId:userId,userName:userName},function(err,html){
            if(err){
                next(err);
            }else{
                res.send(html);
            }
        });
    });
}