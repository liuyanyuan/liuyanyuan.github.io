/**
 * Module dependencies.
 */

var express = require('express');
var http = require('http');
var path = require('path');
var fs = require("fs");
var partials = require('express-partials');
var router = require("./routes/router");
var request = require("./utils/request");
var logger = require("./utils/log");
var ejsfilter = require("./utils/ejsfilter");
var config = require("./config");
var app = express();
var server = http.createServer(app);

app.set("rootPath", config.km.rootPath);
app.set("avatarPath", config.km.avatarPath);
app.set("umeditorPath", config.km.umeditorPath);
app.set("feedbackPath", config.km.feedbackPath);
// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.favicon());
//app.use(express.logger('dev'));
app.use(logger.connectLogger());

app.use(express.json({limit: '100mb'}));
app.use(express.urlencoded({limit: '100mb'}));
app.use(express.compress());
app.use(express.methodOverride());
app.use(express.cookieParser('km'));

app.locals({
    comboCss: require("./utils/helper").comboCss[app.get('env')],
    common: require("./utils/common"),
    constant: require("./utils/constant")
})

app.use(partials());

// development only
if ('development' == app.get('env')) {
    //app.use(express.errorHandler());
    app.use(express.session());
}
//production or test config
else {
    //combo js
    app.use("/static/javascripts/", require("./middleware/comboJs")());

}
//combo css
//app.use("/static/stylesheets/comboCss", require("./middleware/comboCss")());
app.use("/static", express.static(path.join(__dirname, 'static')))
app.use("/km-manager/ueditor_mini", express.static(path.join(__dirname, 'static', 'plugins', 'ueditor_mini')))

//引入domain模块处理异常
app.use(require("./middleware/domainErrorHandler")({server: server, killTimeout: 30000}));
//正式环境引入redis来做session的支持,放到domain处理异常后面,保证捕获
if (/(production|test)/igm.test(app.get('env'))) {
    var RedisStore = require("connect-redis")(express);
    app.use(express.session(
        {
            store: new RedisStore(config.km.redisStore),
            cookie: {maxAge: config.km.cookieMaxAge}
        }))

    require("./utils/init");//初始化一些设置
}
//fake登陆用户
//app.use(require("./middleware/fakerUser")());
//注册路由
router.load(app);


//404处理
app.use(function (req, res, next) {
    res.render('error/404', {title: '404'})
//    res.send(404, "not found");
})

//异常处理
app.use(require("./middleware/errorHandler")());


server.listen(config.port, function () {
    console.log('Express server listening on port ' + config.port);
});
