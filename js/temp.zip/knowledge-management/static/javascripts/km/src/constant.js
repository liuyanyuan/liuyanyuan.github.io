define(function(require, exports, module) {
    exports.ROOT_PATH = '/';
    exports.AVATAR_PATH = 'http://172.16.1.222:8888/km/files/show/';
    exports.FILE_TYPES = '.doc;.docx;.ppt;.pptx;.xls;.xlsx;.pdf;';
    exports.FILE_SIZE_LIMIT = 80;   //单位MB
    exports.FILE_UPLOAD_LIMIT = 1;
    exports.IMAGE_TYPES = '.jpg;.png;';
    exports.IMAGE_SIZE_LIMIT = '5MB';
});