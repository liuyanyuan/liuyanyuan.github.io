define(function(require, exports, module) {
    var $ = require("$");
    var Spinner=require("spin");
    /**
     * 选人弹窗事件绑定
     */
    exports.userBoxBing = function(){
        //左侧组织架构栏点击事件绑定
        $(".userBox-left-group > ul").on("click","li.node-item",function(event){
            var self=$(this);
            event.stopPropagation();

            //判断节点是否被展开，无子节点的节点此处操作效果不变
            if(!self.hasClass("node-opened")){
                self.find("span.node-item-icon:first").html("&#9660;");
                self.addClass("node-opened").removeClass("node-closed");

                self.children("ul:first").show();
            }
            else
            {
                self.find("span.node-item-icon:first").html("&#9654; ");
                self.addClass("node-closed").removeClass("node-opened");

                self.children("ul:first").hide();
            }

            //判断节点是否被多次点击
            if(!self.children(".node-item-name").hasClass("liSelected")){
                var groupID = self.data("groupid");
                $.get('/question/getUsersByGroup', {groupID: groupID}, function(result) {
                    if(result){
                        $("#userBox-usersWaiting").html(result);
                    }
                });
           }


            $(".userBox-left-group .node-item-name").removeClass("liSelected");
            self.children(".node-item-name").addClass("liSelected");
        });
        //待添加用户点击事件绑定
        $("#userBox-usersWaiting").on("click","li.userBox-li",function(event){
            //去除已添加用户的选中状态
            $("#userBox-usersSelected .liSelected").removeClass("liSelected");
            var thisLi = $(this);
            if(thisLi.hasClass("liSelected")){
                thisLi.removeClass("liSelected");
            }
            else{
                thisLi.addClass("liSelected");
            }
        });
        //已添加用户点击事件绑定
        $("#userBox-usersSelected").on("click","li.userBox-li",function(event){
            //去除待添加用户的选中状态
            $("#userBox-usersWaiting .liSelected").removeClass("liSelected");
            var thisLi = $(this);
            if(thisLi.hasClass("liSelected")){
                thisLi.removeClass("liSelected");
            }
            else{
                thisLi.addClass("liSelected");
            }
        });
        //添加按钮点击事件绑定
        $("#userBox-usersAdd").on("click",function(event){
            event.preventDefault();
            var selectIDs = $("#userBox-usersSelected").data("selectids");
            $("#userBox-usersWaiting .liSelected").each(function(i,obj){
                if(selectIDs.indexOf("," + $(obj).data("id") + ",") < 0){
                    $("#userBox-usersSelected").append($(obj).clone());
                    selectIDs += $(obj).data("id") + ",";
                }
            });
            $("#userBox-usersSelected").data("selectids", selectIDs);
            //去除用户的选中状态
            $("#userBox-usersWaiting .liSelected").removeClass("liSelected");
            $("#userBox-usersSelected .liSelected").removeClass("liSelected");
        });
        //删除按钮点击事件绑定
        $("#userBox-usersDel").on("click",function(event){
            event.preventDefault();
            var selectIDs = ",";
            $("#userBox-usersSelected .liSelected").remove();
            $("#userBox-usersSelected li").each(function(i,obj){
                selectIDs += $(obj).data("id") + ",";
            });
            $("#userBox-usersSelected").data("selectids", selectIDs);
            //去除用户的选中状态
            $("#userBox-usersWaiting .liSelected").removeClass("liSelected");
            $("#userBox-usersSelected .liSelected").removeClass("liSelected");
        });
        //待添加用户双击事件绑定
        $("#userBox-usersWaiting").on("dblclick","li.userBox-li",function(event){
            var thisLi = $(this);
            thisLi.removeClass("liSelected");

            var selectIDs = $("#userBox-usersSelected").data("selectids");
            if(selectIDs.indexOf("," + thisLi.data("id") + ",") < 0){
                $("#userBox-usersSelected").append(thisLi.clone());
                selectIDs += thisLi.data("id") + ",";
            }
            $("#userBox-usersSelected").data("selectids", selectIDs);
        });
        //一键添加按钮点击事件绑定
        $("#userBox-usersAddAll").on("click",function(event){
            event.preventDefault();
            var selectIDs = $("#userBox-usersSelected").data("selectids");
            $("#userBox-usersWaiting li").each(function(i,obj){
                if(selectIDs.indexOf("," + $(obj).data("id") + ",") < 0){
                    $("#userBox-usersSelected").append($(obj).clone());
                    selectIDs += $(obj).data("id") + ",";
                }
            });
            $("#userBox-usersSelected").data("selectids", selectIDs);
            //去除用户的选中状态
            $("#userBox-usersWaiting .liSelected").removeClass("liSelected");
            $("#userBox-usersSelected .liSelected").removeClass("liSelected");
        });
        //一键删除按钮点击事件绑定
        $("#userBox-usersDelAll").on("click",function(event){
            event.preventDefault();
            var selectIDs = ",";
            $("#userBox-usersSelected li").remove();
            $("#userBox-usersSelected").data("selectids", selectIDs);
            //去除用户的选中状态
            $("#userBox-usersWaiting .liSelected").removeClass("liSelected");
            $("#userBox-usersSelected .liSelected").removeClass("liSelected");
        });
        //搜索按钮点击事件绑定
        $("#userBox-search button").on("click",function(event){
            event.preventDefault();
            var value = $("#userBox-search input").val();
            if(value && value != ""){
                searchUser(value);
            }
        });
        //搜索框回车事件
        $("#userBox-search input").on("keydown",function(){
            if(event.keyCode == 13){
                var value = $("#userBox-search input").val();
                if(value && value != ""){
                    searchUser(value);
                    return false;
                }
            }
        });
    };
    /**
     * 选组弹窗事件绑定
     */
    exports.groupBoxBing = function(){
        //li点击事件绑定
        $("#groupBox-div > ul").on("click","li",function(event){
            var self=$(this);
            if(self.hasClass("liSelected")){
                self.find("i").addClass("fn-hide");
                self.removeClass("liSelected");
                var id = self.data("id");
                $("#groupBox-selected-list ul " + "#li-" + id).remove();
            }
            else{
                var s2 = self.clone();
                s2.removeClass("liSelected").find("i:last").removeClass("fn-hide");
                $("#groupBox-selected-list ul").append(s2);
                self.find("i:first").removeClass("fn-hide");
                self.addClass("liSelected");
            }
        });
        //选中名单删除事件
        $("#groupBox-selected-list").on("click","i",function(event){
            var id = $(this).parent().data("id");
            $("#groupBox-div ul " + "#li-" + id).removeClass("liSelected").find("i:first").addClass("fn-hide");
            $(this).parent().remove();
        });
        $("#groupBox-selected-list").on("dblclick","li",function(event){
            var id = $(this).data("id");
            $("#groupBox-div ul " + "#li-" + id).removeClass("liSelected").find("i:first").addClass("fn-hide");
            $(this).remove();
        });
        //搜索按钮点击事件绑定
        $("#groupBox-search button:first").on("click",function(event){
            event.preventDefault();
            var value = $("#groupBox-search input").val();
            if(value && value != ""){
                searchGroup(value);
            }
            else{
                $("#groupBox-div li").removeClass("fn-hide");
            }
        });
        //还原按钮点击事件绑定
        $("#groupBox-search button:last").on("click",function(event){
            event.preventDefault();
            $("#groupBox-div li").removeClass("fn-hide");
        });
        //搜索框回车事件
        $("#groupBox-search input").on("keydown",function(){
            if(event.keyCode == 13){
                var value = $("#groupBox-search input").val();
                if(value && value != ""){
                    searchGroup(value);
                    return false;
                }
                else{
                    $("#groupBox-div li").removeClass("fn-hide");
                }
            }
        });
    };
    //搜索用户方法
    function searchUser(value){
        $(".userBox-left-group .node-item-name").removeClass("liSelected");
        $("#userBox-usersWaiting").html("");
        var spinner=new Spinner().spin(document.getElementById("userBox-left-users"));
        $.get('/question/getUserByName', {name: value}, function(result) {
            spinner.stop();
            $("#userBox-usersWaiting").html(result);
        });
    }
    //搜索群组方法
    function searchGroup(value){
        $("#groupBox-div li").each(function(i,obj){
            if($(obj).data("name").toString().indexOf(value) < 0)
                $(obj).addClass("fn-hide");
            else
                $(obj).removeClass("fn-hide");
        })
    }
})