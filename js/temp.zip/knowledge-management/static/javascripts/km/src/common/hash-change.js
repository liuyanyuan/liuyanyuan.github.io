define(function(require, exports, module) {
    var $ = require('$');


    exports.init = function(callback) {
        var isIE = (function(){
            var v = 3,
                div = document.createElement('div'),
                all = div.getElementsByTagName('i');

            while (
                div.innerHTML = '<!--[if gt IE ' + (++v) + ']><i></i><![endif]-->',
                    all[0]
                );

            return v > 4 ? v : undefined;
        }());

        if(isIE < 8) {
            var location = window.location,
                oldURL = location.href,
                oldHash = location.hash;

            // 每隔100ms检测一下location.hash是否发生变化
            setInterval(function() {
                var newURL = location.href,
                    newHash = location.hash;

                // 如果hash发生了变化,且绑定了处理函数...
                if ( newHash != oldHash) {
                    callback();
                    oldURL = newURL;
                    oldHash = newHash;
                }
            }, 100);
        } else {
            $(window).on('hashchange', callback);
        }
    }

})