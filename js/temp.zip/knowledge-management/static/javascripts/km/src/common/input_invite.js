define(function (require, exports, module) {
    var $ = require("$");

    require("select2");
    require("select2.css");
    require('dialog.css');
    var confirmbox = require('confirmbox');
    var Spinner = require("spin");
    var Tabs = require('tabs');
    var selectUOG = require('../common/selectUsersOrGroups');

    var defaults = { type: ["person"], title: "选择邀请对象", width: 500, width_box: 600, hasMask: true};
    var confirm;
    exports.config = defaults;
    /**
     * 邀请控件初始化(for select2控件)
     * @param element 绑定主键的id，如"input-invite"
     * @param width 控件的宽度
     * @param opts.type 显示的tab类型，可选["person","group"];opts.title 弹窗的title;
     */
    exports.initSelect2 = function (element, width, opts) {
        var options = initData(opts, width);

        $('#' + element).select2({
            width: options.width,
            tags: [],
            separator: ',',
            dropdownCss: {display: 'none'}
        });
        $("#s2id_" + element).off("click");
        $("#s2id_" + element + " input").off("input").off("keydown").off("keyup").off("keyup-change").on('keydown',function () {
            return false;
        }).attr("disabled", true);
        var spinner;
        $("#s2id_" + element).on('click',function () {
            if (spinner && spinner.el) return;//如果存在菊花则不执行返回
            spinner = new Spinner().spin(document.getElementById("s2id_" + element));
            //获取输入框中旧的数据
            var oldData = $("#" + element).select2("data");

            //获取旧数据的类型和在tab中的索引
            var oldType, oldIndex;
            if (oldData.length > 0) {
                oldType = oldData[0].type;
            }
            $(options.type).each(function (i, item) {
                if (oldType == item) {
                    oldIndex = i;
                }
            });

            var cache = true;  //使用缓存
            var rq_url = '/question/selectBox';
            if(options.url) {
                rq_url = options.url;
                cache = false;   //非组织架构不用缓存
            }

            $.ajax({
                type: 'GET',
                url: rq_url,
                data:  {oldData: oldData, type: options.type},
                cache: cache
            }).done(function (result) {
                var boxHtml = result;

                confirm = new confirmbox({
                    title: options.title,
                    message: boxHtml,
                    zIndex:1999,
                    closeTpl: 'X',
                    width: options.width_box,
                    hasMask: options.hasMask,
                    onConfirm: function () {
                        var data = getData(options);
                        $("#" + element).select2("data", data);
                        $("#" + element).focusin();
                        confirm.destroy();
                    }
                }).show().after("hide", function () {
                        confirm.destroy();
                    });

                if (options.typeStr.indexOf(",person,") >= 0) {
                    selectUOG.userBoxBing();
                }
                if (options.typeStr.indexOf(",group,") >= 0) {
                    selectUOG.groupBoxBing();
                }

                if (options.type.length > 1) {
                    initTab(oldIndex);
                }
            }).always(function() {
                spinner.stop();
            });

        }).on('keydown', function () {
            var self = $(this);
            self.click();
            return;
        });
    };

    function initTab(index) {
        new Tabs({
            classPrefix: 'tabBox-main',
            element: '#tabBox-main',
            triggers: '.tab-confirmbox-ul li',
            panels: '#tab-body .hidden',
            triggerType: 'click',
            activeIndex: index || 0,
            effect: 'fade',
            activeTriggerClass: 'tabBox-li-active'
        });
    };

    /**
     * 邀请控件初始化(for button)
     * @param element 绑定主键的id，如"input-invite"
     * @param opts.type 显示的tab类型，可选["person","group"];opts.title 弹窗的title;
     */
    exports.initButton = function (element, opts, callback,beforeHideCallBack) {
        if (arguments.length == 2) {
            callback = opts;
            opts = null;
        }
        var options = initData(opts);

        var spinner;
        $("#" + element).on('click', function (event) {
            event.preventDefault();
            if (spinner && spinner.el) return;//如果存在菊花则不执行返回
            spinner = new Spinner().spin(document.getElementById(element));

            $.get('/question/selectBox', {oldData: null, type: options.type}, function (result) {
                spinner.stop();
                var boxHtml = result;

                confirm = new confirmbox({
                    title: options.title,
                    message: boxHtml,
                    zIndex:1999,
                    closeTpl: 'X',
                    width: options.width_box,
                    onConfirm: function () {
                        var data = getData(options);
                        callback(data);
                        this.hide();
                    }
                }).show().after("hide", function () {
                        this.destroy();
                    }).before("hide",beforeHideCallBack);

                if (options.typeStr.indexOf(",person,") >= 0) {
                    selectUOG.userBoxBing();
                }
                if (options.typeStr.indexOf(",group,") >= 0) {
                    selectUOG.groupBoxBing();
                }

                if (options.type.length > 1) {
                    initTab(0);
                }
            });
        });
    };

    /**
     * @returns 初始化数据
     */
    function initData(opts, width) {
        var options = $.extend({}, defaults);
        options.width = width || options.width;
        var type;
        if (opts) {
            if (opts.hasMask == false) {
                options.hasMask = opts.hasMask;
            } else {
                options.hasMask = options.hasMask
            }
            options.width = opts.width || options.width;
            options.title = opts.title || options.title;
            options.url = opts.url;
            type = opts.type;
        }
        var typeStr = ",";
        if (type && $.isArray(type)) {
            options.type = [];
            $(type).each(function (i, item) {
                if (typeStr.indexOf("," + item + ",") < 0) {
                    options.type.push(item);
                    typeStr += item + ",";
                }
            });
        }
        else {
            typeStr = ",person,";
        }
        options.typeStr = typeStr;
        return options;
    }

    /**
     * @returns 获取选中数据
     */
    function getData(options) {
        var type = $(".tabBox-li-active").data("type");
        if (!type) {
            type = options.type[0];
        }
        var data = [];
        if (type == "person") {
            $("#userBox-usersSelected li").each(function (i, obj) {
                data.push({id: $(obj).data("id"), text: $(obj).data("name"), name: $(obj).data("name"), userName:$(obj).data("user-name"), type: type});
            });
        }
        else if (type == "group") {
            $("#groupBox-div li.liSelected").each(function (i, obj) {
                data.push({id: $(obj).data("id"), text: $(obj).data("name"), name: $(obj).data("name"), type: type});
            });
        }
        return data;
    }

    /**
     * @returns 获取选中数据
     */
    exports.destroy = function () {
        if (confirm)
            confirm.destroy();
    }
})