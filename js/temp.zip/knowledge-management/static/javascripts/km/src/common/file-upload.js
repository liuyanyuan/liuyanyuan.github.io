/**
 * by ruojun.zhang
 * 上传文件
 */
define(function (require, exports, module) {
    var $ = require('$');
    var Swfupload = require('swfupload');
    var CONSTANT = require('../constant');
    var Spinner = require('spin');
    var spinner;
    var Confirmbox = require('confirmbox');
    var Uploader = require('upload');


    function FileUpload(options) {
        this.settings = {
            button_id: '',  //触发器id
            file_post_name: 'upfile',   //文件表单名
            upload_url: '',   //上传接口
            post_params: ''   //上传附加数据
        }
        if(window.File && window.FileReader && window.FileList && window.Blob) {
            this.supportFile = true;    //是否支持File API
        } else {
            this.supportFile = false;
        }
        $.extend(this.settings, options);
        this.init();

    }

    FileUpload.prototype.init = function() {
//        if(this.supportFile) {
//            this.uploader();
//        } else {
            this.swfUpload();
//        }
    }

    //flash
    FileUpload.prototype.swfUpload = function() {
        var that = this;
        new Swfupload({
            upload_url: that.settings.upload_url,
            file_post_name: that.settings.file_post_name,
            post_params: that.settings.post_params,
//            file_types: CONSTANT.FILE_TYPES,
            file_queue_limit: CONSTANT.FILE_UPLOAD_LIMIT,
            file_size_limit: CONSTANT.FILE_SIZE_LIMIT + 'MB',
            button_placeholder_id: that.settings.button_id,
            button_cursor: Swfupload.CURSOR.HAND,
            button_window_mode: SWFUpload.WINDOW_MODE.TRANSPARENT,
            button_image_url: '/static/images/pixel.png',
            button_width: $('#' + that.settings.button_id).parent().outerWidth(),
            button_height: $('#' + that.settings.button_id).parent().outerWidth(),
            prevent_swf_caching: false,
            file_dialog_complete_handler: function (numFilesSelected, numFilesQueued, numFilesInQueue) {
                if (numFilesInQueue != 0) {
                    spinner = new Spinner().spin(document.body);

                    if(that.settings.beforeUpload) {
                        if(that.settings.beforeUpload()) {
                            this.startUpload();     //选中完文件后自动上传
                        } else {
                            spinner.stop();
                            return;
                        }
                    } else {
                        this.startUpload();     //选中完文件后自动上传
                    }

                }

            },
            upload_start_handler: function(result) {
                var flag = true;
                if(that.settings.beforeUpload) {
                    flag = that.settings.beforeUpload(result.name);
                }
                if(!flag) return false;
                if(CONSTANT.FILE_TYPES.indexOf(result.type) == -1) {
                    Confirmbox.show('上传文件失败。文件类型不允许，请上传' + CONSTANT.FILE_TYPES + '格式的文件');
                    return false;
                }
            },
            file_queued_handler: function (file) {
                this.customSettings.queue = this.customSettings.queue || new Array();
                this.customSettings.queue.push(file.id);
            },
            file_queue_error_handler: function (file, errorCode, message) {
                if(this.customSettings.queue) {
                    while (this.customSettings.queue.length > 0) {
                        this.cancelUpload(this.customSettings.queue.pop(), false);
                    }
                }

                switch (errorCode) {
                    case Swfupload.QUEUE_ERROR.FILE_EXCEEDS_SIZE_LIMIT:
                        Confirmbox.show('上传文件失败。文件大小超过了' + CONSTANT.FILE_SIZE_LIMIT + 'MB');
                        break;
                    case Swfupload.QUEUE_ERROR.INVALID_FILETYPE:
                        Confirmbox.show('上传文件失败。文件类型不允许，请上传' + CONSTANT.FILE_TYPES + '格式的文件');
                        break;
                    case Swfupload.QUEUE_ERROR.QUEUE_LIMIT_EXCEEDED:
                        Confirmbox.show('上传文件失败。一次只能选择' + CONSTANT.FILE_UPLOAD_LIMIT + '个文件');
                        break;
                    default:
                        Confirmbox.show('上传文件失败');
                        break;
                }
            },
            upload_success_handler: function (file, serverData, responseReceived) {
                spinner.stop();

                try {
                    if (!JSON.parse(serverData).message) {
                        that.settings.callback(serverData);
                    } else {
                        Confirmbox.show(JSON.parse(serverData).message);
                    }
                } catch (e) {
                    that.settings.callback(serverData);
                }

            },
            upload_error_handler: function (file, errorCode, message) {
                spinner.stop();
                while (this.customSettings.queue.length > 0) {
                    this.cancelUpload(this.customSettings.queue.pop(), false);
                }
            }
        });
    }

    //file api
    FileUpload.prototype.uploader = function() {
        var that = this;
        var uploader = new Uploader({
            trigger: '#' + that.settings.button_id,
            action: that.settings.upload_url,
            name: that.settings.file_post_name,
            data: that.settings.post_params,
            accept: '*/*',
            multiple: false
        }).change(function(files) {
                var fileType = files[0].name.substr(files[0].name.lastIndexOf('.') + 1);
                if(files[0].size > CONSTANT.FILE_SIZE_LIMIT * 1024 * 1024) {
                    Confirmbox.show('上传文件失败。文件大小超过了' + CONSTANT.FILE_SIZE_LIMIT + 'MB');
                    this.refreshInput();
                    return;
                } else if(CONSTANT.FILE_TYPES.indexOf(fileType) == -1) {
                    Confirmbox.show('上传文件失败。文件类型不允许，请上传' + CONSTANT.FILE_TYPES + '格式的文件');
                    this.refreshInput();
                    return;
                } else {

                    spinner = new Spinner().spin(document.body);
                    if(that.settings.beforeUpload) {
                        if(that.settings.beforeUpload(files[0].name)) {
                            this.submit();     //选中完文件后自动上传
                        } else {
                            spinner.stop();
                            return;
                        }
                    } else {
                        this.submit();    //选中完文件后自动上传
                    }


                }


            }).success(function(result) {
                spinner.stop();
                try {
                    if (!JSON.parse(result).message) {
                        that.settings.callback(result);
                    } else {
                        Confirmbox.show(JSON.parse(result).message);
                    }
                } catch (e) {
                    that.settings.callback(result);
                }

            });


        uploader._uploaders[0].form.appendTo($( '#' + that.settings.button_id));

    }
    module.exports = FileUpload;

});
