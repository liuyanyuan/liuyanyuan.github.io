define(function(require, exports, module){
    var $=require("$");
    var Spinner=require("spin");
    var Widget = require("widget");

    var Paging = Widget.extend({
        attrs: {
            triggers: {
                value: 'a',
                getter: function(val) {
                    return this.$(val);
                }
            },
            targetId: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            pagingItems: {
              value: '.ui-paging-item',
              getter: function(val) {
                  return this.$(val);
              }
            },
            next: {
                value: '.ui-paging-next',
                getter: function(val) {
                    return this.$(val);
                }
            },
            nextMore: {
                value: '.ui-paging-more-next',
                getter: function(val) {
                    return this.$(val);
                }
            },
            prev: {
                value: '.ui-paging-prev',
                getter: function(val) {
                    return this.$(val);
                }
            },
            prevMore: {
                value: '.ui-paging-more-prev',
                getter: function(val) {
                    return this.$(val);
                }
            },
            spinner: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            url: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            params: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            cb: {
                value: '',
                getter: function(val) {
                    return val;
                }
            }

        },

        events:{
            "click a":"_pagingEventHandler"
        },
        toPage: function(page, loadData) {

            var that = this;
            var pagingItems = that.get('pagingItems');
            var nextMore = that.get('nextMore');
            var prevMore = that.get('prevMore');
            var next = that.get("next");
            var prev = that.get("prev");
            var total = this.element.data('pagingTotal');
            var limit = this.element.data('pagingLimit');
            var differ = total - page;
            var start = 1;

            if(page < 0 || page > total) {
                page = 1;
            }

            if(page > limit) {
                if(differ >= limit) {
                    start = page;
                } else {
                    start = page - limit + 1;
                }
                prevMore.show();
                prev.show();
            }
            if(page == total) {
                next.hide();
                nextMore.hide();
            }

            pagingItems.each(function(index, obj){
                $(obj).text(start);
                $(obj).removeClass("ui-paging-current");
                if(start == page) {
                    $(obj).addClass("ui-paging-current");
                }
                start += 1;
            });
            if(loadData)
                that._getPage(page);



        },
        _getPage: function(page, callback) {
            var that = this;
            var spinner = new Spinner().spin(document.getElementById(that.get('targetId')));
            $.ajax({
                type: 'GET',
                url: that.get('url'),
                data: $.extend(that.get('params'),{page: page}),
                cache: false
            }).done(function(result) {
                that.get('cb')(result, page);
                if(callback) {
                    callback();
                }

                spinner.stop();
            });
        },
        _pagingEventHandler: function(event){
            event.preventDefault();
            var that = this;

            var next = that.get("next");
            var prev = that.get("prev");
            var pagingItems = that.get('pagingItems');
            var self = $(event.target);
            var current = that.element.find(".ui-paging-current"),
                now = +current.text(),
                page = +self.text();

            if(self.hasClass("ui-paging-more-next")){//当前点击向后更多,传入当前视图最大数字的分页值
                page = +pagingItems.last().text() + 1;

            } else if(self.hasClass("ui-paging-more-prev")){//当前点击向前更多,传入当前视图最小数字的分页值
                page = +pagingItems.first().text() - 1;
            } else  if(self.hasClass("ui-paging-next")){//当前点击的是下一页
                page = now + 1;
            } else if(self.hasClass("ui-paging-prev")){//当前点击的是上一页
                page = now - 1;
            }


            that._getPage(page, function() {
                current.removeClass("ui-paging-current");
                if(self.hasClass("ui-paging-next")){//当前点击的是下一页

                    //当前页是条目的最后一项,点击下一页会重新显示条目的数字
                    if(!current.next(".ui-paging-item").length){
                        that._moreNext(now);

                    }else{
                        current.next(".ui-paging-item").addClass("ui-paging-current")
                    }

                }
                else if(self.hasClass("ui-paging-prev")){//当前点击的是上一页
                    if(!current.prev(".ui-paging-item").length){
                        that._morePrev(now);

                    }
                    else{
                        current.prev(".ui-paging-item").addClass("ui-paging-current")
                    }
                }
                else if(self.hasClass("ui-paging-more-next")){//当前点击向后更多,传入当前视图最大数字的分页值
                    that._moreNext(+pagingItems.last().text());
                }
                else if(self.hasClass("ui-paging-more-prev")){//当前点击向前更多,传入当前视图最小数字的分页值
                    that._morePrev(+pagingItems.first().text());
                }
                else{
                    self.addClass("ui-paging-current");
                }

                if(page == that.element.data('pagingTotal')) {
                    next.hide();
                } else{
                    next.show();
                }
                if(page == 1) {
                    prev.hide();
                } else{
                    prev.show();
                }
            })

        },

        _moreNext: function(now) {
            var that = this;
            var pagingItems = that.get('pagingItems');
            var nextMore = that.get('nextMore');
            var prevMore = that.get('prevMore');
            var total = this.element.data('pagingTotal');
            var limit = this.element.data('pagingLimit');
            var differ = total-now;
            that.get('prev').show();
            if(differ <= limit){//如果是最后几页的情况下,更多页按钮隐藏,否则显示
                nextMore.hide();
            } else{
                nextMore.show();
            }
            if((now - limit) >= 0){//如果是初始几页的情况下,向前更多页和上一页按钮隐藏,否则显示
                prevMore.show();
            }else{
                prevMore.hide();
            }
            pagingItems.each(function(index, obj){
                $(obj).text(+$(obj).text()+(differ < limit ? differ : limit));//点击更多的时候后面不足limit，前面补充进来显示
                if(+$(obj).text() == (now + 1)) {
                    $(obj).addClass("ui-paging-current");//当前数字的下一个数字选中
                }
            });
        },
        _morePrev: function(now){
            var that = this;
            var pagingItems = that.get('pagingItems');
            var nextMore = that.get('nextMore');
            var prevMore = that.get('prevMore');
            var total = that.element.data('pagingTotal');
            var limit = that.element.data('pagingLimit');
            var differ = now - limit - 1;
            that.get('next').show();
            if((total- now + 1) < limit){//如果是最后几页的情况下,更多页按钮隐藏,否则显示
                nextMore.hide();
            } else{
                nextMore.show();
            }
            if(differ > 0){//如果是初始几页的情况下,向前更多页和上一页按钮隐藏,否则显示
                prevMore.show();
            }else{
                prevMore.hide();
            }
            pagingItems.each(function(index, obj){
                $(obj).text(+$(obj).text()-(differ > 0 ? limit : now-1));//点击更多的时候后面不足limit，前面补充进来显示
                if(+$(obj).text() == (now - 1)) {
                    $(obj).addClass("ui-paging-current");//当前数字的上一个数字选中
                }
            });
        }
    });


    module.exports = Paging;


});