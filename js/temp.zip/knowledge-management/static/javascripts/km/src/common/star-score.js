/**
 * Created by paper on 14-3-21.
 *
 * 星星通过鼠标移动得分模块
 */
define(function (require, exports, module) {
    var $ = require("$");

    /*
     <div id="km-star-score-demo">
     <div class="km-star-score-wrap">
     <span class="km-star km-star-big"></span>
     </div>
     </div>
     */

    function getHtml() {
        return '<div class="km-star-score-wrap">' +
            '<span class="km-star km-star-big"></span>' +
            '</div>';
    }

    function Star() {
        //是否可以交互
        this.G_actionKey = true;

        //容器id
        this.G_wrapId = '';
    }

    Star.prototype.init = function (wrapId, callback) {
        var that = this;
        this.G_wrapId = wrapId;

        var clickCallback = null;
        var mousemoveCallback = null;
        var mouseoutCallback = null;

        if (typeof callback == "function") {
            clickCallback = callback;
        } else {
            callback = callback || {};

            clickCallback = callback.click;
            mousemoveCallback = callback.mousemove;
            mouseoutCallback = callback.mouseout;
        }

        var $wrap = $("#" + wrapId);
        if ($wrap.length == 0) return;
        $wrap.html(getHtml());

        var $star_wrap = $wrap.find('.km-star-score-wrap');
        var $star_span = $wrap.find('.km-star');

        var star_wrap_left = $star_wrap.offset().left;

        var starClass = '';

        //值
        var v = 0;
        //星星宽度
        var starWidth = 16;

        $star_wrap.mousemove(function (event) {
            if (!that.G_actionKey) return;

            var L = event.pageX - star_wrap_left;

            v = parseInt(L / starWidth, 10) + 1;
            v = v > 5 ? 5 : v;

            $star_span.removeClass(starClass);
            starClass = 'km-star-' + v;
            $star_span.addClass(starClass);

            if (typeof mousemoveCallback == "function") {
                mousemoveCallback(v);
            }
        });

        $star_wrap.mouseout(function () {
            if (!that.G_actionKey) return;

            $star_span.removeClass(starClass);
            v = 0;

            if (typeof mouseoutCallback == "function") {
                mouseoutCallback(v);
            }
        });

        $star_wrap.click(function () {
            if (!that.G_actionKey) return;

            that.G_actionKey = false;

            $star_wrap.addClass('km-star-score-wrap-active');

            if (typeof clickCallback == "function") {
                clickCallback(v);
            }
        });
    }

    Star.prototype.reset = function (callback) {
        if (this.G_wrapId == '') {
            try {
                console.error("请先调用 init 函数，才能调用 reset 函数。");
            } catch (e) {
            }

            return;
        }

        var $wrap = $("#" + this.G_wrapId);
        var $star_wrap = $wrap.find('.km-star-score-wrap');
        var $star_span = $wrap.find('.km-star');
        $star_wrap.removeClass('km-star-score-wrap-active');
        $star_span.removeClass().addClass('km-star km-star-big');

        this.G_actionKey = true;

        if (typeof callback == "function") {
            callback();
        }
    }

    module.exports = Star;
});