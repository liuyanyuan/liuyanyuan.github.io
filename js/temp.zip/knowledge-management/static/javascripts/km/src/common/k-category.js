define(function (require, exports, module) {
    var $ = require("$");
    var Widget = require("widget");
    var Confirmbox = require('confirmbox');
    var Tabs = require('tabs');
    var Spinner = require('spin');
    var spinner;
    require('select2');
    require('select2.css');


    var kcategory = Widget.extend({
        attrs: {
            url: {
                value: '',
                getter: function (val) {
                    return val;
                }
            },
            width: {
                value: '',
                getter: function (val) {
                    return val;
                }
            },
            limit: {
                value: 3,
                getter: function (val) {
                    if (val > 0)
                        return val;
                    else
                        return 1;
                }
            },
            parent: {
                value: '',
                getter: function (val) {
                    return $(val);
                }
            },
            cb: {
                value: '',
                getter: function (val) {
                    return val;
                }
            }
        },
        setup: function () {
            this._initElement();
            this._bindTriggers();
            this.render();
        },
        _initElement: function () {
            var that = this;
//            console.log(that.element.data('old'))

            that.element.select2({
                width: '100%',
                tags: [],
                separator: ',',
                dropdownCss: {display: 'none'}
            });
            if(that.element.data('old')){
                that.element.select2("data", that.element.data('old').categories);
            }
            that.get('parent').find('.select2-container').on('keydown', function () {
                return false;
            });
            that.get('parent').find('.select2-container').off('click').off('input').off('keydown').off('keyup').on('keydown', function () {
                return false;
            });
            that.get('parent').find('.select2-container').find('input').attr("disabled", true);


        },
        _initTree: function (oldData) {
            var that = this;
            klist = $('.kcategory').find('.kcategory-picked-list');
            $.each(oldData, function (i, data) {
                var html = '<li class="kcategory-picked-item" data-name="' + data.text + '"  data-id="' + data.id + '">' + data.text + '<a href="#" title="删除" class="kcategory-picked-delete">×</a></li>';
                klist.append(html);
                $('#kcategory-leaf-' + data.id).prop('checked', true);
            })
            that._itemOn($('.kcategory-main').find('ul').first().find('li').first());

            $('.kcategory-main').on('click', '.kcategory-item', function (event) {
                event.stopPropagation();
                var self = $(this),
                    id = self.data('id'),
                    target = $(event.target);
                if (self.hasClass('kcategory-node')) {
                    self.parent().nextAll().hide();
                    that._itemOn(self);
                }
                if (self.hasClass('kcategory-leaf') && target.attr('type') == 'checkbox') {
                    var pickedItem = $('.kcategory-picked-item'),
                        checkbox = self.find('input[type="checkbox"]'),
                        path = self.data('path'),
                        html = '<li class="kcategory-picked-item" data-name="' + path + '"  data-id="' + id + '">' + path + '<a href="#" title="删除" class="kcategory-picked-delete">×</a></li>';
                    if (checkbox.prop('checked')) {
                        if (that.get('limit') == 1) {
                            //若为单选，选中一个节点后会清除历史记录。
                            $('.kcategory-picked-list').html('');
                            $('.kcategory-main').find('input[type="checkbox"]').prop('checked', false);
                            checkbox.prop('checked', true);
                            $('.kcategory-picked-list').append(html);
                        }
                        else {
                            if (pickedItem.length < that.get('limit')) {
                                $('.kcategory-picked-list').append(html);
                            } else {
                                checkbox.prop('checked', false);
                            }
                        }
                    } else {
                        $('.kcategory-picked-list').find('[data-id="' + id + '"]').remove();
                    }
                }

            });
            $('.kcategory-picked-list').on('click', '.kcategory-picked-delete', function (event) {
                event.preventDefault();
                var self = $(this),
                    item = self.closest('.kcategory-picked-item'),
                    id = item.data('id');
                item.remove();
//                console.log('delete: ' + id);
                $('#kcategory-leaf-' + id).prop('checked', false);
            })
        },
        _itemOn: function (item) {
            var that = this,
                id = item.data('id');

            var son = $('.kcategory-main').find('[data-parent="' + id + '"]');
            if (son.length == 1) {
                item.addClass('kcategory-item-on').siblings().removeClass('kcategory-item-on');
                $('.kcategory-main').find('[data-parent="' + id + '"]').show();
                that._itemOn(son.find('li').first());
            }

        },
        _bindTriggers: function () {
            var that = this;
            that.get('parent').find('.select2-container').on('click', function (event) {
                if (spinner && spinner.el) return;//如果存在菊花则不执行返回
                spinner = new Spinner().spin(document.body);

                var oldData = that.element.select2("data");
                $.get(that.get('url'), function (boxHtml) {
                    spinner.stop();
                    Confirmbox.confirm(boxHtml, null, function () {
                        var data = [];
                        $('.kcategory-picked-item').each(function (i, obj) {
//                            console.log($(obj).data("id"));
                            data.push({id: $(obj).data("id"), text: $(obj).data("name")});
                        });
                        that.element.select2("data", data);
                        that.element.focusin();
                    },{
                        zIndex:1999,
                        closeTpl: '×',
                        width: that.get('width'),
                        title: ''
                    });
                    setTimeout(function () {
                        that._initTree(oldData);
                        //单选或多项的判断
                        var limit = that.get('limit');
                        if (limit == 1) {
                            $('.kcategory-title #multiple').remove();
                        } else {
                            $('.kcategory-title #radio').remove();
                            $('.kcategory-title #multiple span').html(limit);
                        }
                    }, 0);


                }).always(function () {
                    spinner.stop();
                });


            }).on('keydown', function () {
                var self = $(this);
                self.click();
            });
        }
    });
    module.exports = kcategory;
})