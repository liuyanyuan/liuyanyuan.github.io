define(function(require, exports, module){
    var $=require("$");
    var Confirmbox = require('confirmbox');
    var constant= require('../constant');
    var Tabs = require('tabs');
    var Tip = require('./tip');
    var input_invite = require('./input_invite');
    var Validator = require('validator');
    var Spinner=require("spin");
    var spinner;
    require('select2');

    exports.share = function(params) {
        if(spinner && spinner.el) return;//如果存在菊花则不执行返回
        spinner=new Spinner().spin(document.body);


        $.get(constant.ROOT_PATH + 'km/share', function(result) {
            if(result) {
                var comfirmbox = new Confirmbox({
                    title: '',
                    message: result,
                    width: 600,
                    cancelTpl: '',
                    confirmTpl: '',
                    closeTpl: 'X'
                }).show().after("hide", function () {
                        input_invite.destroy();
                        comfirmbox.destroy();
                    });

                setTimeout(function() {
                    //被分享的内容
                    var kmShareContent = $('#km-share-content');
                    kmShareContent.html(params.title);
                    $('.km-share-form-group [name="topic"]').val(params.title);



                    //表单校验
                    var validatorPerson = new Validator({
                        element: '.km-share-form-person',
                        failSilently: true
                    });


                    validatorPerson.addItem({
                        element: '.km-share-form-person [name="message"]',
                        required: true,
                        errormessageRequired: '分享内容不能为空'
                    }).addItem({
                            element: '.km-share-form-person .share-select2',
                            required: true,
                            errormessageRequired: '被分享人不能为空'
                        });
                    var validatorGroup = new Validator({
                        element: '.km-share-form-group',
                        failSilently: true
                    });
                    validatorGroup.addItem({
                            element: '.km-share-form-group .share-select2',
                            required: true,
                            errormessageRequired: '被分享群组不能为空'
                        }).addItem({
                            element: '.km-share-form-group [name="topic"]',
                            required: true,
                            errormessageRequired: '话题不能为空'
                        })
                    $('.km-share-commit').on('click', function(event) {
                        event.preventDefault();
                        var self = $(this),
                            form = self.closest('form'),
                            data = form.serializeObject();
                        data.share = data.share.split(',');

                        if(form.hasClass('km-share-form-person')) {
                            validatorPerson.execute(function(err, results, element) {
                                if(!err) {
                                    data.type = params.type;
                                    $.post(constant.ROOT_PATH + 'km/share/1/' + params.id, data, function(result) {
                                        if(result.success) {
                                            input_invite.destroy();
                                            comfirmbox.destroy();
                                            if(params.cb) {
                                                params.cb(result);
                                            } else {
                                                Tip.open('已成功分享', 1000);
                                            }

                                        }
                                    })

                                }
                            });
                        } else if(form.hasClass('km-share-form-group')) {
                            validatorGroup.execute(function(err, results, element) {
                                if(!err) {
                                    data.type = params.type;
                                    data.message = '<a href="/knowledge/knowledgePage/' + params.id + '">' + params.title + '</a>'
                                    $.post(constant.ROOT_PATH + 'km/share/2/' + params.id, data, function(result) {
                                        if(result.success) {
                                            input_invite.destroy();
                                            comfirmbox.destroy();
                                            if(params.cb) {
                                                params.cb(result);
                                            } else {
                                                Tip.open('已成功分享', 1000);
                                            }
                                        }
                                    })
                                }
                            });
                        }

                    });

                    $('.km-share-box').on('keydown', 'textarea', function(event) {
                        var self = $(this);
                        var form = self.closest('form');
                        var extraCount = 140 - self.val().length;
                        form.find('.world-count').html(extraCount);
                        if(extraCount < 0) {
                            self.val(self.val().slice(0, 140));
                            form.find('.world-count').html(0);
                            return false;
                        }
                    }).on('keyup', 'textarea', function(event) {
                            var self = $(this);
                            var form = self.closest('form');
                            var extraCount = 140 - self.val().length;
                            form.find('.world-count').html(extraCount);
                            if(extraCount < 0) {
                                self.val(self.val().slice(0, 140));
                                form.find('.world-count').html(0);
                                return false;
                            }
                        })

                    new Tabs({
                        element: '#tab-share',
                        triggers:'#tab-share .km-tab-v2-nav li',
                        panels: '#tab-share .km-tab-v2-switch',
                        activeTriggerClass : 'cur'
                    });
                    input_invite.initSelect2('sharePersonSelect2', '100%', {hasMask: false});
                    input_invite.initSelect2('shareGroupSelect2', '100%', {type: ['group'], hasMask: false});

                    $('#shareGroupSelect2').on('select2-focus', function() {
                        console.log('focus')
                        var self = $(this);
                        self.closest('.km-form-content').find('.ui-form-explain').html('');
                    });
                    $('#sharePersonSelect2').on('select2-focus', function() {
                        console.log('change')
                        var self = $(this);
                        self.blur();
                        self.closest('.km-form-content').find('.ui-form-explain').html('');
                    });

                }, 0);
            }

        }).always(function(data, status, err) {
                spinner.stop();
            });

    }
})