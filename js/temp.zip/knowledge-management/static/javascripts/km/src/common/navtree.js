define(function(require, exports, module) {

    var $=require("$");
    var widget=require("widget");
//    widget.autoRenderAll();
//    var tabs=new Tabs({
//        classPrefix:"tabs",
//        element:".fixed-nav-content",
//        triggers:".tabs-nav li",
//        panels:".tabs-content > ul",
//        activeIndex:0
//
//    })

    //头部事件
    $(".navtree-inner").on("click",".category-tabs-nav",function(event){
        var self=$(this);
        event.stopPropagation();
//        if(!self.hasClass("noSee")){
//            self.find("i").html("&#x35a1;");
//            self.addClass("noSee");
//            self.next().hide();
//        }
//        else{
//            self.find("i").html("&#x35a0;");
//            self.removeClass("noSee");
//            self.next().fadeIn();
//        }
        if(self.hasClass("noSee")){
            $(".navtree-inner > ul").addClass("noSee");
            $(".navtree-inner > div").hide();
            $(".navtree-inner > ul > i").html("&#x35a1;");
            self.find("i").html("&#x35a0;");
            self.removeClass("noSee");
            self.next().fadeIn();
        }
    })
    //导航
    $(".category-tabs-content > ul").on("click","li.node-item",function(event){
        var self=$(this);
        event.stopPropagation();
        if(!self.hasClass("node-opened")){
            self.find(".node-item-icon:first").html("&#9660;");
            self.addClass("node-opened").removeClass("node-closed");

            self.children("ul:first").show()
        }
        else
        {
            self.find(".node-item-icon:first").html("&#9654;");
            self.addClass("node-closed").removeClass("node-opened");

            self.children("ul:first").hide();
        }

        if(self.hasClass("node-leaf")){
            $(".category-tabs-content .liSelected").removeClass("liSelected");
            self.addClass("liSelected");
        }else{
            $(".category-tabs-content > ul > li").each(function(i,obj){
                if($(obj).find(self.children("ul:first")).length == 0){
                    $(obj).find(".node-item-icon:first").html("&#9654;");
                    $(obj).addClass("node-closed").removeClass("node-opened");
                    $(obj).children("ul:first").hide();
                }
            })
        }
    })

    //展开按钮
    $(".fixed-nav-button").on("click",function(event){
        var self=$(this),iconfont=self.find("i"),fixedNav= $(".fixed-nav-content");
        if(!self.hasClass("expanded")){
            iconfont.html("&#x359f;");
            fixedNav.show();
        }
        else{
            iconfont.html("&#x359e;");
            fixedNav.hide();
        }
        self.toggleClass("expanded");

    })

    //自动显示已选中节点
    var hash = window.location.hash;
    if(hash.indexOf("navtreeid")>=0){
        var hashArr = hash.split("/");
        $(hashArr).each(function(i,obj){
            if(obj.indexOf("navtreeid")>=0){
                var index = obj.indexOf("navtreeid");
                var selectid = obj.substring(index+10);

                openSelected(selectid);
            }
        });
    }
    function openSelected(selectid){
        var selectLi = $(".category-tabs-content #node-"+selectid);
        selectLi.addClass("liSelected");
        selectLi.parents("li").click();
        selectLi.closest("category-tabs-content").prev().click();
    }

    //暴露可选中节点的点击事件
    exports.clickHandle = function(callback){
        $(".category-tabs-content > ul").on("click","li.node-leaf",function(event){
            event.stopPropagation();
            callback($(this).data("id"),$(this).data("name"));
        });
    }
})