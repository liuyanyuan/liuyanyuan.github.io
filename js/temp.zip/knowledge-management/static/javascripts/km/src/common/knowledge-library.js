/**
 * 更新知识点
 */
define(function (require, exports, module) {
    var $ = require('$');
    var CONSTANT = require('../constant');
    require('select2');
    var Tip = require('./tip');
    var Validator = require('validator');
//    var Swfupload = require('swfupload');
//    var Spinner = require('spin');
    var Confirmbox = require('confirmbox');
    var FileUpload = require('./file-upload');
//
    var validator;
//    var spinner;
    var editor;
    var isGameGuide = window.location.pathname.indexOf('knowledge/gameGuide') > 0  ? true : false; //判断是否玩法库



    exports.initUpload = initUploader;

    /**
     * @param options.trigger:触发器
     * @param options.name:"upfile"，文件表单字段，固定
     * @param options.params:接口参数
     * @param options.url:文件提交路径，可选
     * @param options.callback:文件提交成功，执行回调函数
     */
    function initUploader(options) {
        var settings = {
            trigger: 'uploadKnowledge',
            name: 'upfile'
        }
        if (options) {
            $.extend(settings, options);
        }
        console.log(options)

       if($('#' + settings.trigger).length > 0) {
            new FileUpload({
               button_id: settings.trigger,  //触发器id
               file_post_name: settings.name,   //文件表单名
               upload_url: CONSTANT.ROOT_PATH + (settings.params.upload_url || 'personal/knowledge/upload/') + settings.params.type   ,   //上传接口
                post_params: {"type": "1"},   //上传附加数据
               beforeUpload: settings.beforeUpload,
               callback: settings.callback
           });
       }





    }



    //初始化表单各种绑定事件
    exports.initUpdate = function () {

        //如果有编辑器
        if ($('#knowledgeEditor').length > 0) {
            editor = UM.getEditor('knowledgeEditor');
        }

        if ($('.knowledge-attachment-trigger').length > 0) {
            initAttachment();
        }


        //表单验证

        Validator.addRule('notEmpty', function(options) {
            var val = options.element[0].value;
            return val.replace(/' '|\s|\n|\r|&nbsp;/ig, '').length > 0;
        }, '{{display}}不能为空');

        validator = new Validator({
            element: '#uploadKnowledgeForm',
            failSilently: true

        });





        validator.addItem({
            element: '.upload-knowledge-form [name="title"]',
            required: true,
            errormessageRequired: '标题不能为空',
            rule: 'notEmpty, maxlength{"max": 50}',
            display: '标题'
        }).addItem({
                element: '.upload-knowledge-form [name="description"]',
                required: true,
                errormessageRequired: '摘要不能为空',
                rule: 'notEmpty, maxlength{"max": 200}',
                display: '摘要'
            }).addItem({
                element: '.upload-knowledge-form [name="keyword"]',
                required: true,
                errormessageRequired: '关键字不能为空'
            }).addItem({
                element: '.upload-knowledge-form [name="catagoryId"]',
                required: true,
                errormessageRequired: '分类不能为空'
            }).addItem({
                element: '.upload-knowledge-form [name="source"]',
                rule: 'maxlength{"max": 50}',
                display: '来源'
            }).addItem({
                element: '.upload-knowledge-form [name="author"]',
                rule: 'maxlength{"max": 20}',
                display: '作者'
            }).addItem({
                element: '.upload-knowledge-form [name="gameName"]',
                rule: 'maxlength{"max": 50}',
                display: '游戏名称'
            });

        //如果有文本编辑器
        if (editor) {
            validator.addItem({
                element: '#knowledgeEditor',
                required: true,
                rule: 'notEmpty',
                errormessageRequired: '内容不能为空'
            });
            editor.addListener('focus', function() {
                var self = $('#knowledgeEditor');
                self.closest('.km-form-content').find('.ui-form-explain').html('');
            })
        }


        initCategoriesSelect2($('#categoriesSelect2')); //选知识库分类
        $('#categoriesSelect2').on('select2-focus', function() {
            var self = $(this);
            self.closest('.km-form-content').find('.ui-form-explain').html('');
        });

        $('#keywordSelect2').select2({  //输入关键字
            width: '100%',
            tags: [],
            separator: ',',
            tokenSeparators: [',', ';', '，', '；'],
            selectOnBlur: true,
            dropdownCss: {display: 'none'}
        });
        $('#keywordSelect2').on('change', function() {
            var self = $(this);
            self.closest('.km-form-content').find('.ui-form-explain').html('');
        })


        //如果有文档类型的公开到知识库的
        if ($('.show-detail-box').length >= 1) {
            if ($('.show-detail-box').prop('checked')) {
                $('.more-detail-box').show();
            } else {
                $('.more-detail-box').hide();
                validator.removeItem('.upload-knowledge-form [name="description"]')
                    .removeItem('.upload-knowledge-form [name="keyword"]')
                    .removeItem('.upload-knowledge-form [name="catagoryId"]');
            }
        }
        $('.show-detail-box').on('click', function () {
            console.log('click');
            var self = $(this);
            if (self.prop('checked')) {
                $('.more-detail-box').show();
                validator.addItem({
                    element: '.upload-knowledge-form [name="description"]',
                    required: true,
                    rule: 'notEmpty, maxlength{"max": 200}',
                    errormessageRequired: '摘要不能为空',
                    display: '摘要'

                }).addItem({
                        element: '.upload-knowledge-form [name="keyword"]',
                        required: true,
                        errormessageRequired: '关键字不能为空'
                    }).addItem({
                        element: '.upload-knowledge-form [name="catagoryId"]',
                        required: true,
                        errormessageRequired: '知识库分类不能为空'
                    });
            } else {
                $('.more-detail-box').hide();

                validator.removeItem('.upload-knowledge-form [name="description"]')
                    .removeItem('.upload-knowledge-form [name="keyword"]')
                    .removeItem('.upload-knowledge-form [name="catagoryId"]');
            }
        });

        if ($('.show-visible-checkbox').length > 0) {
            if ($('.show-visible-checkbox').prop('checked')) {
                $('#isVisible').closest('.km-form-group').show();
            } else {
                $('#isVisible').closest('.km-form-group').hide();
            }
        }
        $('.show-visible-checkbox').on('click', function () {
            var self = $(this);
            if (self.prop('checked')) {
                $('#isVisible').closest('.km-form-group').show();
            } else {
                $('#isVisible').closest('.km-form-group').hide();
            }
        })


    }


    //获取表单数据
    function getCommitData(options) {
        var form = $('#uploadKnowledgeForm'),
            data = form.serializeObject();


        data.catagoryName = [];

        $.each($('#categoriesSelect2').select2("data"), function () {
            data.catagoryName.push(this.text);
        });
        data.catagoryName = data.catagoryName.toString();


        if ($('#isVisible').length > 0) {
            data.visibleScope = $('#isVisible').prop("checked") ? 1 : 0;
        }

        //如果有公开的公共知识库的checkbox
        if ($('#toCommunal').length > 0) {
            options.type = $('#toCommunal').prop("checked") ? (options.type + '3') : options.type;
        }


        //如果有附件
        if ($("#knowledge-attachment-list").length > 0) {
            var ids = [];
            $("#knowledge-attachment-list li").each(function () {
                ids.push($(this).data('id'));
            })
            data.docId = ids.join(',');
        }
        //玩法库图片Id
        if( $('#gameGuideImg').length > 0 ){
            data.imageId = $('#gameGuideImg').attr('src') != '/static/images/gameGuideImg.png'?$('#gameGuideImg').attr('src').substr(12):-1;
        }

        //玩法库类型数据
        $('.ul-game-category').each(function(){
            var curUl = $(this);
            var selcetedLi = '';
            curUl.find('li').each(function(){
                if( $(this).find('a').hasClass('selected') ){
                    selcetedLi =  selcetedLi + ','+ $(this).attr('id');
                }
            });
            data[curUl.attr('id')] =  selcetedLi.substr(1);
        });


        //附加数据
        if (options) {
            $.extend(data, options);
        }


        return data;


    }

    /**
     * 新增知识点提交表单
     * @param options   附加的传递参数
     * @param docValue  文档的信息
     * @param callback  提交后的回调
     */
    exports.addKnowledge = function (options, callback) {
        var entrance = 1;   //提交表单的入口，1：个人或群组知识库 2：公共知识库
        if(options.type == 13 || options.type == 30) {     //公共知识库会传入type 13
            entrance = 2;
        }
        var powerType = $('[name="powerType"]').val();
        var authType = $('[name="authType"]').val();

        var data = getCommitData(options);
        if (data) {
            validator.execute(function (err, results, element) {

                if (!err) {
                    console.log(data);

                    $.post(CONSTANT.ROOT_PATH + 'add/knowledge', {knowledge: data, entrance: entrance, powerType: powerType, authType: authType}, function (result) {
                        callback(result);
                    })
                }
            });
        }

    }


    /**
     * 更新文档知识点提交表单
     * @param options   附加的传递参数
     * @param docValue  文档的信息
     * @param callback  提交后的回调
     */
    exports.updateKnowledge = function (options, id, callback) {
        var data = getCommitData(options);
        if (data) {
            validator.execute(function (err, results, element) {
                if (!err) {
                    $.post(CONSTANT.ROOT_PATH + 'update/knowledge/' + id, {knowledge: data}, function (result) {
                        data.id = id;
                        callback(result, data);
                    });
                }
            });
        }


    }


    //初始化选择分类组件
    function initCategoriesSelect2(element) {
        var Kcategory = require('./k-category');
        new Kcategory({
            element: element,
            parent: '.categories-box',
            width: 550,
            url: isGameGuide ? CONSTANT.ROOT_PATH + 'knowledge/gameGuide/category' : CONSTANT.ROOT_PATH + 'knowledge/category'
        });

    }

    /**
     * 上传附件按钮事件绑定
     */
    exports.initAttachment = initAttachment;
    function initAttachment() {
        initUploader({
            upload_url: CONSTANT.ROOT_PATH + "files/upload",
            trigger: "knowledge-attachment-trigger",
            beforeUpload: function(result) {    //上传文件前的判断
                var attachmentList = $('#knowledge-attachment-list');
                var flag = true;
                attachmentList.find('li').each(function () {
                    if (result == $(this).find('.knowledge-attachment-name').html()) {
                        Confirmbox.show('附件' + result + '已经存在，不能重复添加');
                        flag = false;
                    }
                    if(!flag) {
                        return;
                    }
                });

                if(!flag){
                    return false;
                } else {

                    if(attachmentList.find('li').length >= 5) {
                        Confirmbox.show('一次最多只能上传5个附件');
                        return false;
                    } else  {
                        return true;
                    }
                }

            },
            callback: function (result) {
                try{
                    result = JSON.parse(result);
                }catch(e) {
                    result = result;
                }

                var li = $('<li class="fn-clearfix" data-id="' + result.id + '"><p><span class="km-ico km-ico-mini-51"></span><span class="knowledge-attachment-name">' + result.file_name + '</span></p><a href="" title="删除" class="knowledge-attachment-delete"><i class="iconfont ">&#x34e4;</i></a></li>');

                var attachmentList = $('#knowledge-attachment-list');

//                attachmentList.find('li').each(function () {
//                    if (result.file_name == $(this).find('.knowledge-attachment-name').html()) {
//                        Confirmbox.show('附件' + result.file_name + '已经存在，如不需要，请删除');
//                        return;
//                    }
//                });
                attachmentList.append(li);


            }
        });
        $("#knowledge-attachment-list").on("click", ".knowledge-attachment-delete", function (event) {
            event.preventDefault();
            var self = $(this),
                li = self.closest('li'),
                id = li.data('id');
            $.post(CONSTANT.ROOT_PATH + 'files/delete/' + id, function(result) {
                if(result.success) {
                    li.remove();
                } else {
                    Tip.open('删除失败，请重试', 700);
                }
            })
        });


    }


});