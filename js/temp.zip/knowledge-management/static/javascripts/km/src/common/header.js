define(function(require, exports, module) {
    var $ = require("$");
    /**
     * 返回顶部按钮
     */
    $("#backToTop").click(function(){
        $('html,body').animate({scrollTop:0}, 500);
        return false;
    });
    /**
     * 关键字搜索事件绑定
     */
    exports.keywordsBing = function(){
        $("#search-button").on("click",function(){
            toSearch();
        });
        $("#search-input").on("keydown",function(event){
            if(event.keyCode == 13){
                toSearch();
                return false;
            }
        });
    }
    function toSearch(){
        var type = $('input[type=radio][name=search_app]:checked').val();
        var keywords = $("#search-input").val();

        if(!keywords || keywords == ""){
            $("#search-input").focus();
        }
        else{
            switch(parseInt(type)){
                case 0:
                    break;
                case 1:
                    window.location.href = "/group-list/search?keyword="+keywords;
                    break;
                case 2:
                    break;
                case 3:
                    window.location.href = "/question/questionSearch?keyword="+keywords;
                    break;
                case 4:
                    window.location.href = "/knowledge/search?keyword="+keywords;
                    break;
            }
        }
    }
    exports.handleSearch = function() {
        $('#search-switch').click(function () {
            if($('.search-btn').hasClass('show-search-icon')){
                if ($(window).width()>767) {
                    $('.search-box').fadeOut(300);
                } else {
                    $('.search-box').fadeOut(0);
                }
                $('.search-btn').removeClass('show-search-icon');
            } else {
                if ($(window).width()>767) {
                    $('.search-box').fadeIn(300);
                } else {
                    $('.search-box').fadeIn(0);
                }
                $('.search-btn').addClass('show-search-icon');
            }
        });
        //选择搜索区域
        $('#search_options').click(function(){
            $('#search_options_menucontent').fadeToggle();
        });
        //点击其他地方时，隐藏搜索区域
        $(document).bind('click',function(ev){
            var ev=ev||window.event;
            var elem=ev.target||ev.srcElement;
            if( elem.id != "search_options" && $("#search_options_menucontent").find(elem).length == 0 ){
                $("#search_options_menucontent").css("display","none");
            }
        });
        //显示修改的搜索区域
        $('input[type=radio][name=search_app]').click(function(){
            $('#search_options').text($('input[type=radio][name=search_app]:checked').parent().text());
        });

    }
});