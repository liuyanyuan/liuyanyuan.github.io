define(function(require, exports, module){
    var $=require("$");
    var Widget = require("widget");
    var Spinner=require("spin");
    var spinner;

    var Crumbs = Widget.extend({
        attrs: {
            trigger: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            extraTrigger: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            extraParent: {
                value: '',
                getter: function(val) {
                    return $(val);
                }
            },
            rootname: {
                value: '全部文件',
                getter: function(val) {
                    return val;
                }
            },
            parent: {
              value: '',
                getter: function(val) {
                    return $(val);
                }
            },
            url: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            params: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            width: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            cb: {
                value: '',
                getter: function(val) {
                    return val;
                }
            }
        },
        setup: function() {
            this._initCrumbs();
            this._bindTriggers();
            this.render();
        },
        _initCrumbs: function() {

            var that = this;
            var catalogArr = [];
            catalogArr.push({id:0 ,name: that.get('rootname')});
            that.element.data('catalog', catalogArr);
            that.element.on('click', 'a', function(event) {
                event.preventDefault();
                var self = $(this),
                    id = self.data('id'),
                    catalogStr = that.element.data('catalog'),
                    catalogArr = catalogStr,
                    newCatalogArr = [];
                $.each(catalogArr, function(i, item) {
                    newCatalogArr.push(item);
                    if(item.id == id) {
                        that._createCrumbs(newCatalogArr);
                        that._getData(id);
                        return false;
                    }
                });

            })
        },
        _updateCrumbs: function(newItem) {
            var that = this;
            var catalogArr = [];
            catalogArr.push({id:0 ,name: that.get('rootname')});
            that.element.data('catalog', catalogArr);
            if(newItem.id != 0) {
                catalogArr.push(newItem);
            }

            that._createCrumbs(catalogArr);
            that._getData(newItem.id);
        },
        _bindTriggers: function() {
            var that = this;
            that.get('parent').on('click', that.get('trigger'), function(event){
                event.preventDefault();
                var self = $(this),
                    id = self.data('id');
                that._getData(id);
                that._addCrumbs({id: self.data('id'), name: self.data('name')});
            });
            if(that.get('extraTrigger')) {
                that.get('extraParent').on('click', that.get('extraTrigger'), function(event) {
                    event.preventDefault();
                    var self = $(this),
                        id = self.data('id'),
                        name = self.data('name');
                    that._updateCrumbs({id: id, name: name});
                })
            }

        },
        //增加面包屑
        _addCrumbs: function(newCatalog) {
            var that = this,
                catalogArr = that.element.data('catalog');
            catalogArr.push(newCatalog);
            that._createCrumbs(catalogArr);
        },
        _createCrumbs: function(catalogArr) {
            var that = this;
            var catalog = '';
            console.log('_createCrumbs');
            $.each(catalogArr, function(i, item) {
                var html;
                var flag = '&gt;';
                if(i == 0) {
                    flag = '';
                }
                if(i == catalogArr.length - 1) {
                    html = flag + '<span>' + item.name + '</span>'
                } else {
                    html = flag + '<a href="#" data-id="' + item.id +'">' + item.name + '</a>';
                }
                catalog += html;
            });

            that.element.html(catalog);
            that.element.data('catalog', catalogArr);
        },
        _getData: function(id) {
            var that = this;
            var params = that.get('params');
            params.catalog = id;
            if(spinner) {
                spinner.stop();
            }
            spinner = new Spinner().spin(document.body);
//            $.get(that.get('url'),that.get('params'), function(result) {
//                that.get('parent').empty().append(result);
//                that.get('cb')(id);
//                spinner.stop();
//            });
            $.ajax({
                type: 'GET',
                url: that.get('url'),
                data: that.get('params'),
                cache: false
            }).done(function(result) {
                    that.get('parent').empty().append(result);
                    that.get('cb')(id);
                }).always(function(data, status, err) {
                    spinner.stop();
                });
//            $.get(that.get('url'),that.get('params')).done(function(result) {
//                that.get('parent').empty().append(result);
//                that.get('cb')(id);
//            }).always(function(data, status, err) {
//                    spinner.stop();
//                });
        }
    });
    module.exports = Crumbs;
})