/**
 * Created by yanyuan.liu on 14-5-23.
 */
define(function(require, exports, module) {
    var $ = require('$');

    //查看大图（原图)
    exports.imgFullSizeView = function(selector,width){
        $(selector).on("mouseenter","img",function(e){
            var _this = $(this);
            width = width ? width : $(_this).parent().width();
            var imgSrc = _this.attr("src");
            var img_y = _this.offset().top;
            var parent_y = _this.parent().offset().top;
            var btn_y = img_y - parent_y + _this.height() - 25; //25为viewFullSize按钮的宽度
            //图片宽度大于等于一个width时并且图片不是在编辑器容器中并且当前图片的相邻元素不存在viewFullSize时（图片宽度小于width时本身图片就是原图不需要查看大图）
            if(_this.width() >= width && !_this.parents(".edui-container").html() && !_this.siblings("a.viewFullSize").html()){
                _this.parent().css("position","relative").append("<a href='"+ imgSrc +"' target='_blank' title='点击查看大图' class='viewFullSize' style='right:0; top:"+ btn_y +"px;'><i class='iconfont'>&#x3475;</i>&nbsp;&nbsp;查看大图</a>");
            }
        });
    }
});
