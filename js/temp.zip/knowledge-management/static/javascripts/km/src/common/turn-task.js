/**
 * 转为任务
 */
define(function (require, exports, module) {
    var $ = require("$");
    var Confirmbox = require('confirmbox');
    var constant = require('../constant');
    var Calendar = require('calendar');
    var input_invite = require('./input_invite');
    var Validator = require('validator');
    require('select2');

    exports.turnTask = function (options) {
        $.get(constant.ROOT_PATH + 'km/taskbox/' + options.tasktype, {sourceType: options.sourceType || 1}, function (result) {
            if (result) {
                //弹窗
                var comfirmbox = new Confirmbox({
                    title: '',
                    message: result,
                    width: 660,
                    cancelTpl: '',
                    confirmTpl: '',
                    closeTpl: 'X'
                }).show().after("hide", function () {
                        input_invite.destroy();
                        comfirmbox.destroy();
                    });


                setTimeout(function() {

                    var kmTaskContent = $('#turn-task-content');
                    kmTaskContent.html(options.title);

                    //选人组件
                    if(options.sourceType == 2) {
                        input_invite.initSelect2('taskPersonSelect2', '100%', {hasMask: false, url: '/group/' + options.sourceId + '/members/selectBox'});
                        input_invite.initSelect2('followersSelect2', '100%', {hasMask: false, url: '/group/' + options.sourceId + '/members/selectBox'});
                        input_invite.initSelect2('judgersSelect2', '100%', {hasMask: false, url: '/group/' + options.sourceId + '/members/selectBox'});
                    } else {
                        input_invite.initSelect2('taskPersonSelect2', '100%', {hasMask: false});
                        input_invite.initSelect2('followersSelect2', '100%', {hasMask: false});
                        input_invite.initSelect2('judgersSelect2', '100%', {hasMask: false});
                    }

                    $('#taskPersonSelect2').on('select2-focus', function() {
                        var self = $(this);
                        self.closest('.km-form-content').find('.ui-form-explain').html('');
                    });



                    //日历控件
                    Date.now = Date.now || function() { return +new Date; };
                    var date_now = new Date(Date.now());
                    var time_now = date_now.getFullYear() + '-' + (date_now.getMonth() + 1) + '-' + date_now.getDate();
                    var calendar = new Calendar({
                        trigger: '.task-date-choose',
                        range: [time_now, null]
                    });
                    $('.task-date-choose').on('keydown', function(event) {
                        if(event.keyCode !== 8) {
                            calendar.show();
                            return false;
                        }

                    });

                    //表单数据初始化
                    if (options.taskdata && options.tasktype != 3) {
                        $('.turn-task-box [name="title"]').val(options.taskdata.title);
                        UM.getEditor('messageEditor').ready(function() {
                            //this是当前创建的编辑器实例
                            this.setContent(options.taskdata.message)
                        })

                        //执行人
                        var performers = [];
                        $.each(options.taskdata.performers, function(i, performer) {
                            var userName = performer.userName.split('|')[0],
                                englishName = performer.userName.split('|')[1];
                            performers.push({id: performer.userId, text: userName, name: userName, userName: englishName, type: 'person'});
                        });

                        $('.turn-task-box [name="performers"]').select2('data', performers);
                        //关注人
                        var followers = [];
                        $.each(options.taskdata.followers, function(i, follower) {
                            var userName = follower.userName.split('|')[0],
                                englishName = follower.userName.split('|')[1];
                            followers.push({id: follower.userId, text: userName, name: userName, userName: englishName, type: 'person'});
                        });

                        $('.turn-task-box [name="followers"]').select2('data', followers);

                        //审核人
                        if(options.taskdata.judgers.length) {
                            $('.task-judge').prop('checked', true);
                            $('.judgers-box').css('display', 'block');
                            var judgers = [];
                            $.each(options.taskdata.judgers, function(i, judger) {
                                var userName = judger.userName.split('|')[0],
                                    englishName = judger.userName.split('|')[1];
                                judgers.push({id: judger.userId, text: userName, name: userName, userName: englishName, type: 'person'});
                            })

                            $('.turn-task-box [name="judgers"]').select2('data', judgers);
                        }

                        var date = new Date(options.taskdata.deadline);
                        $('.turn-task-box [name="deadline"]').val(date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate());
                    } else if(options.tasktype == 3) {
                        $('#task-performer').html(options.taskdata.performers.userName);
                    }




                    //表单验证
                    var validator = new Validator({
                        element: '.turn-task-box form',
                        failSilently: true
                    });
                    validator.addItem({
                        element: '.turn-task-box [name="message"]',
                        required: true,
                        errormessageRequired: '任务内容不能为空'
                    }).addItem({
                        element: '.turn-task-box [name="title"]',
                        required: true,
                        errormessageRequired: '任务标题不能为空'
                    }).addItem({
                        element: '.turn-task-box [name="deadline"]',
                        required: true,
                        errormessageRequired: '截止时间不能为空'

                    });
                    if(options.sourceType != 2) {
                        validator.addItem({
                            element: '.turn-task-box [name="performers"]',
                            required: true,
                            errormessageRequired: '任务执行人不能为空'
                        });
                    }

                    //审核人的事件绑定
                    $('.task-judge').on('click', function() {
                        var $self = $(this);
                        var $box = $('.judgers-box');
                        if($self.prop('checked')) {
                            $box.show();
                            validator.addItem({
                                element: '.turn-task-box [name="judgers"]',
                                required: true,
                                errormessageRequired: '任务审核人不能为空'
                            });
                        } else {
                            $box.hide();
                            validator.removeItem('.turn-task-box [name="judgers"]');
                        }
                    })

                    //提交
                    $('.km-task-commit').on('click', function (event) {
                        event.preventDefault();
                        var self = $(this),
                            form = self.closest('form'),
                            data = form.serializeObject();
                        var taskType = options.tasktype;
                        validator.execute(function (err, results, element) {   //表单验证成功才提交数据
                            if (!err) {

                                //任务执行人的处理
                                var performers = [];
                                if(options.tasktype == 3) {
                                    performers.push(options.taskdata.performers);
                                } else {
                                    $.each($('.turn-task-box [name="performers"]').select2('data'), function(i, item) {
                                        performers.push({userId: item.id, userName: item.name + '|' + item.userName});
                                    })

                                }
                                data.performers = performers;

                                //任务关注人的处理
                                var followers = [];
                                $.each($('.turn-task-box [name="followers"]').select2('data'), function(i, item) {
                                    followers.push({userId: item.id, userName: item.name + '|' + item.userName});

                                })

                                data.followers = followers;

                                //任务审核人的处理
                                if($('.task-judge').prop('checked')) {
                                    var judgers = [];
                                    $.each($('.turn-task-box [name="judgers"]').select2('data'), function(i, item) {
                                        judgers.push({userId: item.id, userName: item.name + '|' + item.userName});
                                    })

                                    data.judgers = judgers;
                                } else {
                                    data.judgers = [];
                                }


                                data.sourceType = options.sourceType;
                                data.sourceId = options.sourceId;
                                data.sourceName = options.sourceName;


                                if(options.refId) {
                                    data.refId = options.refId;
                                }

                                if(taskType != 2) {   //编辑任务时不能改type
                                    data.refType = options.refType || 0;
                                    data.type == options.type || 0;
                                }


                                if (taskType == 2) {
                                    data.id = options.taskdata.id;
                                    $.post(constant.ROOT_PATH + 'task/modify/' + options.sourceType, data, function (result) {
                                        input_invite.destroy();
                                        comfirmbox.destroy();
                                        options.cb(result, data);

                                    });
                                } else {
                                    $.post(constant.ROOT_PATH + 'task/add', data, function (result) {
                                        input_invite.destroy();
                                        comfirmbox.destroy();
                                        options.cb(result);

                                    })
                                }
                            }
                        });
                    });

                    //字数限制
//                    $('[name="message"]').on('keydown', function(event) {
//                        var self = $(this);
//                        var form = self.closest('form');
//                        var extraCount = 140 - self.val().length;
//                        form.find('.world-count').html(extraCount);
//                        if(extraCount < 0) {
//                            self.val(self.val().slice(0, 140));
//                            form.find('.world-count').html(0);
//                            return false;
//                        }
//                    }).on('keyup', function(event) {
//                            var self = $(this);
//                            var form = self.closest('form');
//                            var extraCount = 140 - self.val().length;
//                            form.find('.world-count').html(extraCount);
//                            if(extraCount < 0) {
//                                self.val(self.val().slice(0, 140));
//                                form.find('.world-count').html(0);
//                                return false;
//                            }
//                        })
                }, 0);


            }

        })
    }
});