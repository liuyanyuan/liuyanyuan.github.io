define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var tip = require('../common/tip');
    var Confirmbox = require('confirmbox');
    var Calendar = require('calendar');
    var Paging = require('../common/paging');
    var voteValidator = require('validator');

    //加载添加、引入投票弹出窗
    exports.selectAddVote_init = function(obj){
        $(obj.trigger).on('click',function(){
            $.ajax({
                url:constant.ROOT_PATH + 'vote/select-add-vote?&s='+new Date().getTime(),
                type:"get",
                data:{"groupid":obj.groupId},
                success:function(result){
                    Confirmbox.confirm(result.html, '插入投票',function(){},{
                        width: 750,
                        closeTpl: '×'
                    });
                    checkVote();
                    //表单验证
                    var valid = exports.addVoteFormValidator();
                    exports.addVoteInit(valid,obj.groupId,"selectAdd");
                },
                error:function(){
                    tip.open("获取投票失败", 1000);
                }
            });
        });
        //删除引用投票
        $("#delVoteCheck").on("click",function(){
            $(this).parent().hide();
            $("#btn-submit").attr("data-voteid",0);
        });
    }

    //加载添加投票弹出窗
    exports.addVoteWin_init = function(obj){
        $(obj.trigger).on('click',function(){
            $.post(constant.ROOT_PATH + 'vote/addVotePage',{},function(result){
                Confirmbox.confirm(result.html, '添加投票',function(){},{
                    width: 750,
                    closeTpl: '×'
                });
                //表单验证
                var valid = exports.addVoteFormValidator();
                exports.addVoteInit(valid,obj.groupId,"add");
            });
        });
    }

    //添加投票初始化 type "selectAdd":插入和添加,"add":添加
    exports.addVoteInit = function(valid,groupId,type){
        exports.vote_addOption(valid);
        exports.selectTime();
        //点确定添加投票
        $("#addVote-sub").on("click",function(){
            var voteName = $("#vote-name").val();
            valid.addItem({
                element: '.vote-item',
                required: true,
                display: '选项'
            });
            valid.execute(function (err, results, element) {   //表单验证成功才提交数据
                if (!err) {
                    var isValid = true;
                    var items = [];
                    $(".vote-item").each(function(i){
                        if($.trim($(this).val()) == ""){
                            isValid = false;
                            items.push(i);
                        }
                    });
                    if(!isValid){
                        $.each(items,function(index,n){
                            $(".vote-item").eq(n).siblings(".ui-form-explain").text("选项不能为空");
                        });
                        return;
                    }
                    exports.addVote_submit(groupId,function(rs){
                        tip.open("添加投票成功", 1000);
                        $("[data-role=cancel]").trigger("click");
                        if(type == "selectAdd"){
                            $("#btn-submit").attr("data-voteid",rs.voteId);
                            $("#checkedVote").text(voteName).parent().show();
                        }
                    });
                }
            });
        });
        //点取消关闭弹出窗
        $("#addVote-cancel").on("click",function(){
            $("[data-role=cancel]").trigger("click");
        });
    }

    //添加投票表单验证
    exports.addVoteFormValidator = function(){
        var validator_vote = new voteValidator({
            element: '#addVoteForm'
        });
        voteValidator.addRule("newrule",function(options){
            var element = options.element;
            if(element.val() > $("#vote-startTime").val()){
                return true;
            }else{
                return false;
            }
        });
        var endTime = voteValidator.getRule('date').and('newrule');
        voteValidator.addRule('endTime',endTime,'{{display}}必须大于开始时间');
        validator_vote.addItem({
            element: '#vote-name',
            required: true,
            display: '标题'
        }).addItem({
            element: '.vote-item',
            required: true,
            display: '选项'
        }).addItem({
            element: '#vote-description',
            required: true,
            display: '备注'
        }).addItem({
            element: '#vote-startTime',
            required: true,
            rule:'date',
            display: '生效时间'
        }).addItem({
            element: '#vote-endTime',
            required: true,
            rule:'endTime',
            display: '结束时间'
        });
        return validator_vote;
    }

    //提交添加投票
    exports.addVote_submit = function(groupId,fn) {
        var voteName = $("#vote-name").val();
        var voteType = $("#vote-type").is(":checked")?0:1;  //0：单选，1：多选
        var voteItems = [];
        $(".vote-item").each(function(){
            voteItems.push({"itemName":$(this).val()});
        });
        var voteDescription = $("#vote-description").val();
        var voteStartTime = $("#vote-startTime").val();
        var voteEndTime = $("#vote-endTime").val();
        var voteScore = $("#vote-score").val();
//        var voteCategory = $("#vote-category").val();
        var data = {
            "vote":{
                "title":voteName,
                "itemType":voteType,
                "description":voteDescription,
                "startTime":voteStartTime,
                "endTime":voteEndTime,
                "score":voteScore,
                "refId":groupId,
                "type":4
//                ,
//                "categoryId":voteCategory
            },
            "voteItems":voteItems
        };
        $.ajax({
            url:constant.ROOT_PATH + 'vote/addVote',
            type:"post",
            processData:false,
            contentType:"application/json",
            data: JSON.stringify(data),
            success:function(result) {
                if(result.success) {
                    fn(result);
                } else {
                    tip.open("添加失败", 700);
                }
            },
            error:function(){
                tip.open("请求失败", 700);
            }
        });
    };

    //添加投票选项
    exports.vote_addOption = function(valid) {
        $("#vote-addOption").on("click",function(){
            var opthin_html = '<div class="km-form-group"><label class="km-form-label" for=""></label><div class="km-form-content ui-form-item"><input type="text" maxlength="20" class="vote-item"/><div class="ui-form-explain"></div></div></div>';
            $(this).parents("div.km-form-group").before(opthin_html);
            if(valid){
                valid.removeItem(".vote-item");
            }
        });
    };

    //选择时间
    exports.selectTime = function(){
        new Calendar({trigger: '#vote-startTime'});
        new Calendar({trigger: '#vote-endTime'});
    }

    //引入投票弹出窗分页初始化
    exports.pagingInit = function(){
        $('.ui-paging').each(function(i, obj) {
            new Paging({
                element: obj,
                url:constant.ROOT_PATH + 'vote/voteList/2',
                params: {limit: 6},
                targetId: 'vote-tab',
                cb: function(data) {
                    $(".voteList-table tbody").html(data);
                    checkVote();
                }
            })
        });
    }

    //进行投票
    exports.castVote = function(){
        $("body").on("click","button",function(){
            var _this = $(this);
            if(_this.hasClass("vote-submit")){
                var data = [];
                var voteId = _this.data("voteid");
                var _theVoteItem = _this.parents("table").find("input[name='voteItem-type']");
                _theVoteItem.each(function(){
                    if($(this).is(":checked")){
                        data.push(parseInt($(this).val()));
                    }
                });
                console.log(JSON.stringify({"voteId":voteId,"itemId":data}));
                if(data.length < 1){
                    tip.open("请选择投票项", 2000);
                }else{
                    $.ajax({
                        url:constant.ROOT_PATH + "vote/cast-vote",
                        type:"post",
                        processData:false,
                        contentType:"application/json",
                        data:JSON.stringify({"voteId":voteId,"itemId":data}),
                        success:function(result){
                            if(result.success){
                                tip.open(result.message,700);
                                _this.parents(".voteBox").html(result.html);
                            }else if(result.isChecked){
                                tip.open("对不起，您已参与过此投票，不能再次投票！",2000);
                            }else{
                                tip.open("投票失败", 2000);
                            }
                        },
                        error:function(){
                            tip.open("请求失败", 2000);
                        }
                    });
                }
            }
        });
    }

    function checkVote(){
        //插入投票（引用）
        $(".checkVote").on("click",function(){
            var voteId = $(this).attr("data-id");
            var voteTitle = $(this).attr("data-title");
            $("#btn-submit").attr("data-voteid",voteId);
            $("[data-role=cancel]").trigger("click");
            $("#checkedVote").text(voteTitle).parent().show();
        });
    }
});

