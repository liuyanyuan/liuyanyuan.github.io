/**
 * Created by yanyuan.liu on 14-3-3.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var vote = require('./addVote');
    var constant = require('../constant');
    var Paging = require('../common/paging');
    var Tabs = require('tabs');

    //热门、最新投票列表分页
    $('.ui-paging').each(function(i, obj) {
        new Paging({
            element: obj,
            url: constant.ROOT_PATH + 'vote/voteList/'+(i+1),
            params: {limit: 10},
            targetId: 'vote-tab',
            cb: function(data) {
                $(".voteList-table").eq(i).find("tbody").html(data);
            }
        })
    });

    new Tabs({
        element: '#vote-tab',
        triggers:'#vote-tab .km-tab-v1-nav li',
        panels : '#vote-tab .km-tab-v1-switch',
        activeTriggerClass : 'cur',
        triggerType: 'click'
    });

    /**
     * 添加投票弹出窗
     */
    vote.addVoteWin_init({trigger:"#add-vote-btn"});
});
