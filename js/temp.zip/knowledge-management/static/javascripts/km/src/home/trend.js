/***
 * trend.js
 * 动态
 * by ruojun.zhang
 */
define(function (require, exports, module) {
    var $ = require("$");
    var constant = require('../constant');
    var Tip = require("../common/tip");
    var Share = require('../common/share');
    var Turntask = require('../common/turn-task');
    var Spinner = require('spin');
    var spinner;

    var trendMore = $('#trendMore'); //获取更多动态的trigger
    var isIe = window.navigator.userAgent.indexOf('MSIE') > 1;

    exports.init = function () {


//    滚动加载动态数据
        var scrollMonitor = require('scrollmonitor');
        var elementWatcher = scrollMonitor.create($('#trendMore'));
        elementWatcher.enterViewport(function () {
            getTrends();
        });


        //动态导航
        $('#trendsNav').on('click', 'a', function (event) {
            event.preventDefault();
            var $self = $(this);
            var parent = $self.parent();
            parent.addClass('trends-nav-item-current').siblings().removeClass('trends-nav-item-current');
            var type = $self.data('trend-type');
            $.data(trendMore[0], 'trend-type', type);
            $.data(trendMore[0], 'max-id', null);
            $.data(trendMore[0], 'is-search', 'false');
            $('#trendsWrapper').empty();
            getTrends();
            if (type == 0) {
                $('.trends-box-title').html('动态');
            } else if (type == 1) {
                $('.trends-box-title').html('消息');
                $self.find('.msg-count-tip').remove();
            }

        });

        //动态内容绑定事件
        $('#trendsWrapper').on('click', ' .km-trend-operate a, .answer-reply, .trend-answer-add, .trend-show, .trend-close, .show-origin, .show-abstruct', function (event) {


            var self = $(this);

            if (self.attr('href') == '' || self.attr('href') == '#' || self.attr('href') == '###') {
                event.preventDefault();
            }

            if (self.hasClass('trend-applaud')) {    //赞
                if (self.hasClass('trend-applaud-has')) {
                    Tip.open('你已经赞过了，不能重复赞', 1000);
                } else {
                    $.post(constant.ROOT_PATH + 'personal/trend/applaud', {knowledgeId: self.data('ref-id'), type: self.data('trend-type')}, function (result) {
                        if (result.success) {
                            var element = self.find('.applaudCount'),
                                count = parseInt(element.html());
                            element.html(count + 1);
                            self.addClass('trend-applaud-has');
                        } else {
                            Tip.open(result.message, 1000);
                        }
                    });
                }
            } else if (self.hasClass('trend-answer')) {    //获取回答


                var trendItem = self.closest('.km-trend-item'),
                    box = trendItem.find('.trend-answer-box'),
                    list = trendItem.find('.trend-answer-list');
//                box.slideToggle();
                box.toggle();
                if (list.length <= 0) {
                    spinner = new Spinner().spin(box.get(0));
                    $.ajax({
                        type: 'GET',
                        url: constant.ROOT_PATH + 'personal/qaMsg/answers',
                        data: {id: self.data('ref-id'), type: self.data('ref-type')},
                        cache: false
                    }).done(function (result) {
                        if (result) {
                            var list = $('<div class="trend-answer-list"></div>');
                            list.append(result);
                            box.prepend(list);
                        }
                    }).always(function (data, status, err) {
                        spinner.stop();
                    });

                }
            } else if (self.hasClass('trend-share')) {   //分享
                Share.share({ id: self.data('ref-id'), type: self.data('ref-type'), title: self.data('ref-title')});
            }
            else if (self.hasClass('trend-tasked')) {    //转为任务
                Turntask.turnTask(
                    {
                        tasktype: 1,
                        title: self.data('ref-title'),
                        refId: self.data('ref-id'),
                        refType: self.data('ref-type'),
                        cb: function (result) {
                            if (result.success) {
                                Tip.open('转为任务成功', 700);
                            } else {
                                Tip.open('转为任务失败，请重试', 700);
                            }
                        }
                    }
                );
            }
            else if (self.hasClass('trend-collect')) {   //收藏
                Tip.open('该功能暂未开发', 700);
            }
            else if (self.hasClass('trend-answer-add')) {    //添加回答或回复
                addAnswer(self);
            }
            else if (self.hasClass('answer-reply')) {    //获取回答的评论列表


                var parentId = self.data('id'),
                    parentUserId = self.data('user-id'),
                    parentUserName = self.data('user-name');
                var item = self.closest('.km-trend-item');
                var box = item.find('.trend-answer-box');
                var textarea = item.find('.imitate-textarea');

                if (self.hasClass('trend-topic-reply')) {
                    box.toggle();
                }

                if (textarea.find('.imitate-textarea-btn').length > 0) {
                    textarea.empty();
                    textarea.find('.imitate-textarea-btn').remove();
                }
                if (isIe) {
                    var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-parent-id=' + parentId + ' data-parent-user-name=' + parentUserName + ' data-parent-user-id=' + parentUserId + '>回复' + parentUserName + ':</button>');
                } else {
                    var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-parent-id=' + parentId + ' data-parent-user-name=' + parentUserName + ' data-parent-user-id=' + parentUserId + '>回复' + parentUserName + ':</button><br >');
                }
                textarea.prepend(button);

            }
            else if (self.hasClass('answer-favour')) {   //回答的顶
                voteAnswer(self, 1);
            }
            else if (self.hasClass('answer-stamp')) {    //回答的踩
                voteAnswer(self, 0);
            }
            else if (self.hasClass('answer-reply-reply')) {      //对回答进行评论
                showReplyForm(self);
            }
            else if (self.hasClass('trend-show')) {       //查看更多
                self.closest('.ellipsis-panel').removeClass('ellipsis-panel-close');
            }
            else if (self.hasClass('trend-close')) {         //收起
                self.closest('.ellipsis-panel').addClass('ellipsis-panel-close');
            }
            else if (self.hasClass('show-origin')) {
                self.closest('.abstruct-box').hide();
                self.closest('.abstruct-origin-box').find('.origin-box').show();
            }
            else if (self.hasClass('show-abstruct')) {
                self.closest('.origin-box').hide();
                self.closest('.abstruct-origin-box').find('.abstruct-box').show();
            }
            else if (self.is('img')) {     //动态中有图片
                window.open(self.attr('src'));
            }
        }).on('focusin', '.qa-answer-form-out .imitate-textarea', function (event) {
            var ele = $(this);
            ele.closest('form').removeClass('qa-answer-form-simple');
            ele.find('.placeText').remove();

        }).on('focusout', '.qa-answer-form-out .imitate-textarea', function (event) {
            var ele = $(this);
            if (ele.html() == '') {
                ele.closest('form').removeClass('qa-answer-form-simple').addClass('qa-answer-form-simple');
                ele.append($('<span class="placeText">点击回复</span>'));
            }
        }).on('keydown', '.imitate-textarea', function (event) {
            var ele = $(this);
            if (event.keyCode == 8 && !isIe) {  //修复div模拟textarea的某些bug
                if (ele.find('br').length <= 0 && ele.find('div').length <= 0) {
                    console.log(ele);
                    console.log(ele.find('br').length);
                    ele.append('<br />');
                }
            }
        }).on('mouseover', '.ellipsis-text img', function (event) {
            var self = $(this),
                src = self.attr('src');
            var popup = $('#ellipsis-img-popup');
            if (popup.length == 0) {
                var html = $('<div id="ellipsis-img-popup"></div>');
                $('body').append(html);
                popup = $('#ellipsis-img-popup');
                var img = $('<img src="' + src + '" />');
                popup.append(img);
                popup.on('mouseover', function (event) {
                    var self = $(this);
                    self.show();
                }).on('mouseout', function (event) {
                    var self = $(this);
                    self.hide();
                }).on('click', function () {
                    var self = $(this);
                    window.open(self.find('img').attr('src'));
                });
            } else {
                popup.hide();
                popup.show();
                popup.find('img').attr('src', src);
            }

            popup.css({
                position: 'fixed',
                cursor: 'pointer',
                top: event.pageY - $(document).scrollTop() + 'px',
                left: event.pageX - $(document).scrollLeft() + 'px',
                'z-index': 9999

            });


        }).on('mouseout', '.ellipsis-text img', function (event) {
            $('#ellipsis-img-popup').hide();
        });


        $('#trendSearchBtn').on('click', function (event) {
            event.preventDefault();
            searchTrend();
        });

        $('#trendSearchInp').on('keyup', function (event) {
            event.preventDefault();
            var keycode = event.keyCode;
            if (keycode == 13) {
                searchTrend();
            }
        });


    }


    //加载数据
    function getTrends() {
        var trendsWrapper = $('#trendsWrapper');
        if(trendsWrapper.length && !trendsWrapper.is(':hidden')) {
            if (trendMore.data('is-search') == 'true') { //查询
                if (trendMore.data('max-id') !== 'false') {
                    var spinner = new Spinner().spin(document.getElementById('trend-item-more'));

                    $.ajax({
                        type: 'GET',
                        url: '/personal/search',
                        data: {keyword: trendMore.data('key-world'), max: trendMore.data('max-id'), scope: trendMore.data('trend-type')},
                        cache: false
                    }).done(function (result) {
                        if (result) {
                            $('#trendsWrapper').append(result.html);
                            $.data(trendMore[0], 'max-id', result.max);

                        }
                    }).always(function (data, status, err) {
                        spinner.stop();
                    });

                }
            } else if (trendMore.data('max-id') + '' !== 'false') {
                var spinner = new Spinner().spin(document.getElementById('trend-item-more'));
                $.ajax({
                    type: 'GET',
                    url: '/personal/' + $('#personal-user-id').val() + '/message/' + trendMore.data('trend-type'),
                    data: {max: trendMore.data('max-id')},
                    cache: false
                }).done(function (result) {
                    if (result) {
                        trendsWrapper.append(result.html);
                        $.data(trendMore[0], 'max-id', result.max);

                    }
                }).always(function (data, status, err) {
                    spinner.stop();
                });

            }

        }



    }

    function placeCursor(ele) {
        ele = ele.get()[0];
        if (typeof window.getSelection != 'undefined' && typeof document.createRange != 'undefined') {
            var range = document.createRange();
            range.selectNodeContents(ele);
            range.collapse(false);
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        } else if (typeof document.body.createTextRange != 'undefined') {
            var textRange = document.body.createTextRange();
            textRange.moveToElementText(ele);
            textRange.collapse(false);
            textRange.select();
        }
    }

    function filterHtml(textarea) {
        textarea.find('button').remove();
        var html = textarea.html();
        html = html.replace('/[|]*\n/g', '\n'); //去除行尾空白
        html = html.replace(/\n[\s||]*\r/g, '\n'); //去除多余空行
        return html;
    }

    //搜索动态
    function searchTrend() {
        var val = $('#trendSearchInp').val();
        $.data(trendMore[0], 'is-search', 'true');//设置为当前在搜索
        $.data(trendMore[0], 'key-world', val);//设置搜索关键字
        $.data(trendMore[0], 'max-id', null);//当前无数据

        $.get('personal/search', {keyword: val, limit: 15, scope: trendMore.data('trend-type'), max: null}, function (result) {
            $('#trendsWrapper').empty().append(result.html);
            $.data(trendMore[0], 'max-id', result.max);  //设置当前动态列表的最大id
        });
    }

    //添加回复
    function addAnswer(ele) {
        var trendItem = ele.closest('.km-trend-item'),
            form = ele.closest('.km-form'),
            textarea = form.find('.imitate-textarea'),
            data = {},
            type = textarea.data('ref-type');

        if (type == 1) {
            data.refId = textarea.data('ref-id');
            if (textarea.find('.imitate-textarea-btn').length > 0) {
                var button = textarea.find('.imitate-textarea-btn');
                data.parentId = button.data('parent-id');
                data.parentUserId = button.data('parent-user-id');
                data.parentUserName = button.data('parent-user-name');
            }
        }
        if (type == 4) {
            var btn = trendItem.find('.trend-topic-reply');
            data.topicId = btn.data('topic-id');
            data.parentId = btn.data('id');
        }

        var content = filterHtml(textarea);
        data.content = content;
        if (content.replace(/<(S*?)[^>]*>.*?|<.*?\/>|\s|(&nbsp;)|(char) 12288/g, '') === '') {
            Tip.open('回复内容不能为空，请输入回复内容', 700);
            textarea.empty();
        } else {

            $.post('/personal/trend/answers', {params: data, type: type}, function (result) {
                textarea.empty();
                if (type == 4) {
                    Tip.open('回复成功。', 700);
                    ele.closest('.trend-answer-box').hide();
                } else {
                    if (ele.closest('.trend-answer-box').children('.trend-answer-list').length <= 0) {
                        var list = $('<div class="trend-answer-list"></div>');
                        list.prepend(result);
                        ele.closest('.trend-answer-box').prepend(list);
                    } else {
                        ele.closest('.trend-answer-box').children('.trend-answer-list').prepend(result);
                    }


                    var item = trendItem.find('.answer-count');
                    item.html(parseInt(item.html()) + 1);
                }

            });
        }
    }

    //获取回答的评论
    function getReplyList(ele) {
        var item = ele.closest('.trend-answer-item');

        item.toggleClass('trend-answer-open').siblings().removeClass('trend-answer-open');
        var textarea = item.find('.imitate-textarea');
        var parentId = ele.data('id');
        var userName = ele.data('user-name');
        var userId = ele.data('user-id');


        $.data(textarea[0], 'parent-id', parentId);
        $.data(textarea[0], 'user-name', userName)
        $.data(textarea[0], 'user-id', userId);

        textarea.empty();
        if (isIe) {
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-user-name=' + userName + ' data-user-id=' + userId + '>回复' + userName + ':</button>');
        } else {
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-user-name=' + userName + ' data-user-id=' + userId + '>回复' + userName + ':</button><br >');
        }
        textarea.prepend(button);
        placeCursor(textarea);

    }

    //
    function showReplyForm(ele) {
        var item = ele.closest('.trend-answer-item');
        var form = item.find('form');
        var textarea = item.find('.imitate-textarea');
        var userName = ele.data('user-name') || null;
        var userId = ele.data('user-id') || null;
        var id = ele.data('id');

        $.data(textarea[0], 'parent-id', id);

        if (!!userName) {
            textarea.empty();
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-user-name=' + userName + ' data-user-id=' + userId + '>回复' + userName + ':</button><br >');
            textarea.prepend(button);
            placeCursor(textarea);
            textarea.focus();

        }
    }

    function voteAnswer(ele, vote) {
        var id = ele.data('id');
        $.post('/personal/voteAnswer', {commentId: id, updown: vote}, function (result) {
            if (result.success) {
                var voteCount = parseInt(ele.children('.voteCount').html());
                if (vote == 0) {
                    vote = 1;
                }
                voteCount += vote;
                ele.children('.voteCount').html(voteCount);
            }

        });
    }

});
