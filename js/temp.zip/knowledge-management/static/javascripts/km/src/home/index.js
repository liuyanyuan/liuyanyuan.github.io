define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var hash_change = require('../common/hash-change');
    var Spinner = require('spin');
    var spinner;
    var userId = $('#personal-user-id').val();



    //个人信息
    $.get('/ajax/personal/avatar', function(data){
        $('#J-personal-head-wrap').html(data);
    });
    //个人未完成任务数
    $.get('/ajax/task/count', function(result) {
        if(result.count) {
            $('#task-msg-count').show().html(result.count);
        }
    });
    //积分兑换列表
    $.ajax({
        type: 'GET',
        url: constant.ROOT_PATH + 'ajax/personal/exchange/list',
        data: {limit: 6, page: 1}
    }).done(function(data) {
        $("#p-exchange-list").html(data);
    });



    //侧边栏导航选中状态
    $('.menu-list').on('click', '.menu-item', function (event) {
        event.stopPropagation();
        var $self = $(this);
        $self.addClass('on').siblings().removeClass('on');

        if($self.hasClass('menu-item-accordion')) {
            $self.find('.menu-list-son').toggle();
            $self.find('.iconfont-up').toggle();
            $self.find('.iconfont-down').toggle();
        }
    });



//    页面滚动fix效果
    var Sticky = require('sticky');
    var st2 = Sticky('#info-sidebar', 50, function(status) {
        var element = $('#info-sidebar');
        if(status) {
            if(!element.hasClass('fixed')) {
                element.addClass('fixed')
            }

        } else {
            if(element.hasClass('fixed')) {
                element.removeClass('fixed')
            }
        }
    });
    $(window).on('resize', function () {
        st2.adjust();
    });



    //hash
    var hash = window.location.hash.slice(1);
    var hashobj = hash.toJsonObj();
    if (hashobj.homeNav) {
        homeNav(hashobj.homeNav);
    } else {
        homeNav('trends');
    }
    hash_change.init(f_change);
    function f_change() {

        var hash = window.location.hash.slice(1);
        var hashobj = hash.toJsonObj();
        homeNav(hashobj.homeNav || 'trends');
    }

    function homeNav(type) {
        var wrapper = $('#home-main-change');
        var navItem = $('[href="#homeNav=' + type + '"]').closest('li');    //侧边栏导航菜单项


        if (spinner && spinner.el) return;//如果存在菊花则不执行返回
        spinner =  new Spinner().spin(wrapper.get(0));

        navItem.addClass('on').siblings().removeClass('on');
        wrapper.empty();

        switch (type) {
            case 'trends':  //动态
                $.ajax({
                    type: 'GET',
                    url: constant.ROOT_PATH + 'personal/trend',
                    data: {limit: 15},
                    cache: false
                }).done(function(result) {
                        console.log('trends');
                        wrapper.html(result.html);
                        var trend = require('./trend.js');
                        trend.init();
                    }).always(function(data, status, err) {
                        spinner.stop();
                    });

            break;
            case 'tasks':   //任务
                var mytask = require('../personal/mytask');
                mytask.get(function(result) {
                    wrapper.html(result);
                    spinner.stop();
                });
            break;
            case 'follows':   //关注
                var follow = require('../personal/follow');
                follow.get(userId, function(result) {
                    wrapper.html(result);
                    spinner.stop();
                });
                break;
            case 'groups':   //群组
                $.ajax({
                    type: 'GET',
                    url: constant.ROOT_PATH + 'users/' + userId + '/groups',
                    cache: false
                }).done(function (result) {
                        wrapper.html(result);
                        var groups = require('../personal/myGroups');
                        groups.groupsPagingInit();
                    }).always(function(data, status, err) {
                        spinner.stop();
                    });
                break;
            default :
                break;
        }

    }



});