define(function(require, exports, module) {
    var $ = require('$');
    var Tip = require('../common/tip');
    var constant = require('../constant.js');
    var isIe = window.navigator.userAgent.indexOf('MSIE') > 1;


    exports.getAnswers = function(type, id) {
        console.log(type, id);
        switch (type) {
            case 1:
                console.log(type);
                $.get(constant.ROOT_PATH + 'knowledge/getMoreReply', {id: id, page: 1, limit: 5}, function(result) {
                    $('.trend-answer-box').show();
                });
                break;
            default :
                break;
        }
    }
});