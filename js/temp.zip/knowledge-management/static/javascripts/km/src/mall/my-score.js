define(function(require, exports, module) {

    var $ = require('$');
    var constant = require('../constant');
    var Calendar = require('calendar');
    var Paging = require('../common/paging');

    //初始化各种事件
    var init = function() {
        //日历控件
        var c1 = new Calendar({trigger: '#date-start-trigger', output: "#date-start-output"}),
            c2 = new Calendar({trigger: '#date-end-trigger', output: "#date-end-output"})
        c1.on('selectDate', function(date) {
            c2.range([date, null]);
        });
        c2.on('selectDate', function(date) {
            c1.range([null, date]);
        });
        //分页控件
        var $paging = $('.mall-my-score').find('.ui-paging');
        if($paging.length) {
            new Paging({
                element: $paging,
                url: constant.ROOT_PATH + 'score/history',
                targetId: 'taskBox',
                cb: function (data) {
                    $('#score-list').empty().append(data);
                }
            })
        }
        //搜索按钮
        $('#score-search').on('click', function() {
            var startDate = Date.parse($('#date-start-output').val().replace(/-/g, '/') + ' 0:0:0'),
                endDate = Date.parse($('#date-end-output').val().replace(/-/g, '/') + ' 23:59:59'),
                limit = 12;

            $.ajax({
                type: 'GET',
                url: constant.ROOT_PATH + 'score/history/search',
                data: {startDate: startDate, endDate: endDate, page: 1, limit: limit}
            }).done(function(result) {

                $('#score-list').html(result.html);

                $.get('/ajax/paging?total=' + (result.count / limit) + '&limit=8', function (data) {
                    $('#my-score-paging').html(data)
                    $('.ui-paging').each(function (i, obj) {
                        new Paging({
                            element: obj,
                            url: constant.ROOT_PATH + 'score/history/search',
                            params: {startDate: startDate, endDate: endDate, limit: limit},
                            cb: function (data) {
                                $('#score-list').html(data.html);
                            }
                        });
                    });

                });
            })
        });
        //兑换积分按钮
        $('#score-exchange').on('click', function() {

        })

    }
    exports.init = init;

    //获取
    exports.get = function(cb) {
        $.ajax({
            url: constant.ROOT_PATH + 'mall/user/score',
            type: 'GET',
            cache: false
        }).done(function(result) {
            cb(result);
            init();
        })
    }
});