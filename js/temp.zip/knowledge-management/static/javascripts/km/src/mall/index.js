/**
 * Created by paper on 2014/6/16.
 */
define(function(require, exports, module) {

    var $ = require('$');
    var Tabs = require("tabs");
    var constant = require('../constant');
    var Paging = require('../common/paging');

    //一位数字 1-9 变  00 - 09
    function doubleNum(n){
        return n < 10 ? '0'+n : ''+n;
    }

    //根据 时间戳 生成 年-月-日-小时-分
    function dateFormat(v){
        var d = new Date(v);

        return {
            year :  d.getFullYear(),
            month :  d.getMonth() + 1,
            date :  d.getDate(),
            hour :  d.getHours(),
            mintue :  d.getMinutes()
        }
    }

    function dateFormatToString(v){
        var df = dateFormat(v);

        return df.year + '年' + df.month + '月' + df.date + '日' + doubleNum(df.hour) + ':' + doubleNum(df.mintue);
    }

    //根据开始时间，和 结束时间，显示 倒计时
    function getCountdown(beiginTime, endTime){
        var c1, c2, s, m, h;
        c1 = endTime - beiginTime;
        c2 = parseInt(c1 / 1000, 10);
        s = 0;
        m = 0;
        h = 0;

        h = parseInt( c2/3600, 10 );
        if( c2%3600 != 0 ){
            m = parseInt( (c2 - 3600*h)/60 );
        }
        s = c2 - 3600*h - 60*m;

        return {
            h : doubleNum(h),
            m : doubleNum(m),
            s : doubleNum(s)
        }
    }

    function letgoCountdown(beginTime, endTime, doingCallback, endCallback){
        if(beginTime >= endTime){
            callback && callback();
            return;
        }

        //var div = document.getElementById("daojishu-test");
        var r = getCountdown(beginTime, endTime);

        function fn(beginTime, endTime){
            setTimeout(function(){
                //div.innerHTML = r.h + ":" + r.m + ":" + r.s;
                doingCallback && doingCallback(r);
                beginTime += 1000;
                r = getCountdown(beginTime, endTime);

                if (beginTime > endTime) {
                    endCallback && endCallback();
                } else {
                    fn(beginTime, endTime);
                }
            },1000);
        }

        fn(beginTime, endTime);
    }

    //积分竞拍
    var getAuction = function(id){
        if( typeof id == "undefined" ) return;

        var url = "/ajax/mall/auction/detail/"+id;

        $.get(url, function(data){
            $("#J-jifen-auction").html(data);

            //判断 显示 竞拍物品状态
            var data = $.parseJSON( $("#J-auction-data").val() );

            if( data.gameState == 0 ){
                var $auctionDetailStep1 = $(".jifen-auction-detail-step-1");
                $auctionDetailStep1.show();

                var formatStartTime = dateFormatToString(data.startTime);
                var formatEndTime = dateFormatToString(data.endTime);

                $auctionDetailStep1.find(".item2 strong").html( formatStartTime + '-' + formatEndTime );
            }else if( data.gameState == 1 ){
                var $auctionDetailStep2 = $(".jifen-auction-detail-step-2");
                $auctionDetailStep2.show();

                letgoCountdown(data.currentTime, data.endTime, function(r){
                    var t = $auctionDetailStep2.find(".countdown ul li span");

                    t[0].innerHTML = r.h.charAt(0);
                    t[1].innerHTML = r.h.charAt(1);

                    t[2].innerHTML = r.m.charAt(0);
                    t[3].innerHTML = r.m.charAt(1);

                    t[4].innerHTML = r.s.charAt(0);
                    t[5].innerHTML = r.s.charAt(1);
                });
            }else{
                var $auctionDetailStep3 = $(".jifen-auction-detail-step-3");
                $auctionDetailStep3.show();
                //data.userId = 123
                if( data.userId ){  //有最后得主
                    $auctionDetailStep3.find(".personal-box .name").html( data.userName );
                    //$auctionDetailStep3.find(".personal-box .score").html( data.userScore );
                    $auctionDetailStep3.find(".personal-box .last-score span").html( data.endScore );
                }else{  //流拍
                    $auctionDetailStep3.find(".personal-box").html( "<p>非常可惜，流拍了</p>" );
                }
            }

            auctionItemAction();
            showMoreAuctionPeopleList();

        });
    };

    function showMoreAuctionPeopleList(){
        var $list = $("#J-jifen-auction-more-list");

        $("#J-jifen-auction-show-more-btn").click(function() {
            if( $list.is(":hidden") ){
                $list.show();
                $(this).html("收起全部");
            }else{
                $list.hide();
                $(this).html("展示全部");
            }
        });
    }

    //竞拍 出价 按钮
    function auctionItemAction(){
        var $inputNumber = $("#J-action-user-jifen-input");
        var $btn = $("#J-action-buy-btn");

        var productId = $btn.attr("data-productId");
        var shipmentid = $btn.attr("data-shipmentid");
        var beginScore = $btn.attr("data-beginScore");
        var hignScore = $btn.attr("data-hignScore");

        $btn.click(function(){
            var yourScore = +$.trim( $inputNumber.val() );

            if( !/^[1-9]\d*$/.test(yourScore) || yourScore <= 0){
                alert("请输入正确的积分");
                return;
            }

            if( yourScore < hignScore ){
                alert("出价积分必须大于最高价");
                return;
            }

            if( yourScore < beginScore ){
                alert("出价积分必须大于起拍价");
                return;
            }

            var params = {
                score : yourScore,
                shipmentId : shipmentid
            };

            $.get("/ajax/mall/auction/buy/" + productId, params, function(data){
                if( data.code == "200" ){
                    alert( data.message );
                }else{
                    alert( "系统繁忙，请稍后再试" );
                }
            });
        });
    };

    //初始化各种事件
    var init = function() {

        //积分兑换列表
        function getExchangeList(params){
            params = params || {};

            var page = typeof params.page == "undefined" ? 1 : params.page;
            var limit = typeof params.limit == "undefined" ? 16 : params.limit;
            var order = typeof params.order == "undefined" ? 0 : params.order;

            var reqData = {
                page : page,
                limit : limit,
                order : order
            }

            $.get("/ajax/mall/exchange/list/", reqData, function(data){
                var $listWrap = $("#J-jifen-exchange-list-wrap");
                $listWrap.html(data);

                var count = $("#J-exchange-list-count").val();
                var len = $listWrap.find(".jifen-box-style1").length;

                if (len < count) {
                    var total = 0;
                    total = count % len == 0 ? count / len : parseInt(count / len) + 1;

                    $.get("/ajax/paging?total="+ total +"&limit=" + 10, function(data){
                        $("#J-jifen-exchange-list-paging-wrap").html(data);

                        $('.ui-paging').each(function(i, obj) {
                            new Paging({
                                element: obj,
                                url: '/ajax/mall/exchange/list/?'+new Date().getTime(),
                                params: {limit: limit},
                                targetId: 'J-jifen-boxes-wrap',
                                cb: function(data) {
                                    $("#J-jifen-boxes-wrap").html(data);
                                }
                            });
                        });
                    });
                }
            });
        }

        getExchangeList();

        //个人信息
        $.get("/ajax/personal/avatar", function(data){
           $("#J-personal-head-wrap").html(data);
        });

        //竞拍历史
        $.get("/ajax/mall/auction/history/", function(data){
            $("#J-jifen-auction-history").html(data);
        });

        //热门兑换
        $.get("/ajax/mall/exchange/recommend/", function(data){
            $("#J-jifen-hot-exchange").html(data);
        });

        //标签切换
        var tabs = new Tabs({
            element : "#home-main-change",
            triggers:'#home-main-change .km-tab-v1-nav li',
            panels : '#home-main-change .km-tab-v1-switch',
            activeTriggerClass : 'cur',
            triggerType : "click"
        });

        var tabKey = [false, false, false, false];
        tabs.on('switched', function(toIndex, fromIndex) {
            //alert(toIndex +", " + fromIndex)
            //切换到 “积分竞拍”
            if( !tabKey[toIndex] && toIndex == 1 ){
                tabKey[toIndex] = true;

                //热门兑换
                $.get("/ajax/mall/auction/now/", function(r){
                    if( r.code == 200 ){
                        getAuction(r.data.shipmentId);
                    }
                });

            }

            ////切换到 “我的积分”
            if( !tabKey[toIndex] && toIndex == 2 ){
                tabKey[toIndex] = true;

                var score = require('./my-score');
                score.get(function(result) {
                    $("#J-my-jifen").html(result);
                    //spinner.stop();
                });

            }


        });
    };

    exports.init = init;
    exports.getAuction = getAuction;

});