/**
 * Created by paper on 2014/6/16.
 */
define(function(require, exports, module) {

    var $ = require('$');

    //初始化各种事件
    var init = function() {

        //图片导航
        function gallery(){
            var $miniLink = $(".jifen-item-gallery-mini-wrap li a");
            var $bigImg = $(".jifen-item-gallery-hd img");

            $miniLink.click(function(){
                var i = $miniLink.index(this);

                $miniLink.removeClass("cur");
                $miniLink.eq(i).addClass("cur");

                $bigImg.attr("src", $(this).attr("data-src"));
            });

            var $prevBtn = $(".jifen-item-gallery-bd .prev-btn");
            var $nextBtn = $(".jifen-item-gallery-bd .next-btn");
            var $listWrap = $(".jifen-item-gallery-mini-wrap ul");
            var disabledBtnClass = "jifen-item-gallery-btn-disabled";
            var animateKey = true;
            var pageShowMax = 5; //每次显示的最多个数
            var len = $miniLink.length;
            var step = 300; //每次移动的距离
            var total = len % pageShowMax == 0 ? parseInt(len/pageShowMax) : parseInt(len/pageShowMax) + 1;
            var i = 1;
            var marginLeft = 0;

            if( len <= pageShowMax ){
                $nextBtn.addClass( disabledBtnClass );
            }

            $prevBtn.click(function(){
                if( !animateKey || $prevBtn.hasClass( disabledBtnClass ) ) return;

                animateKey = false;
                marginLeft += step;
                $listWrap.animate({
                    "margin-left" : marginLeft + "px"
                }, function(){
                    animateKey = true;
                    i--;

                    if( i == 1 ){
                        $prevBtn.addClass( disabledBtnClass );
                        $nextBtn.removeClass( disabledBtnClass );
                    }
                });
            });

            $nextBtn.click(function(){
                if( !animateKey || $nextBtn.hasClass( disabledBtnClass ) ) return;

                animateKey = false;
                marginLeft -= step;
                $listWrap.animate({
                    "margin-left" : marginLeft + "px"
                }, function(){
                    animateKey = true;
                    i++;

                    if( i == total ){
                        $nextBtn.addClass( disabledBtnClass );
                        $prevBtn.removeClass( disabledBtnClass );
                    }
                });
            });
        }

        gallery();

        //立即换购
        function exchangeItemAction(){
            var $inputNumber = $("#J-jifen-item-exchange-number");
            var $btn = $("#J-jifen-item-exchange-btn");
            var id = $btn.attr("data-item-id");
            var stock = +$btn.attr("data-stock");

            $btn.click(function(){
                var number = +$.trim($inputNumber.val());

                if( !/^[1-9]\d*$/.test(number) || number <= 0){
                    alert("请输入正确的兑换数量");
                    return;
                }

                if( number > stock ){
                    alert("兑换数量大于库存数量");
                    return;
                }

                $.get("/ajax/mall/exchange/buy/" + id + "?num=" + number, function(data){
                    if( data.code == "200" ){
                        alert( data.message );

                        //刷新页面
                        location.reload();
                    }else{
                        alert( "系统繁忙，请稍后再试" );
                    }
                });
            });
        }

        exchangeItemAction();

        //个人信息
        $.get("/ajax/personal/avatar", function(data){
           $("#J-personal-head-wrap").html(data);
        });
    };

    exports.init = init;

});