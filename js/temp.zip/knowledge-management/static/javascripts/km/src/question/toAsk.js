/**
 * Created by peng.xie on 14-1-26.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var tip = require('../common/tip');
    var constant = require('../constant');
    var Validator = require('validator');
    var Spinner = require("spin");

    /**
     * 发起问题
     * add_type 1:可选择回答人，2：固定回答人
     */
    exports.addQuestion = function(add_type,comfirmbox) {
        add_type = add_type ? add_type : 1;
        var spinner;
        var editor = UM.getEditor('myEditor');
        /**
         * 表单验证
         */
        Validator.addRule('notEmpty', function (options) {
            var val = options.element[0].value;
            return val.replace(/' '|\s|\n|\r|&nbsp;/ig, '').length > 0;
        }, '{{display}}不能为空');

        var validator = new Validator({
            element: '.container',
            failSilently: true
        });

        validator.addItem({
            element: '#question-edit',
            required: true,
            rule: 'notEmpty',
            display: '问题详情'
        }).addItem({
            element: '#categoriesSelect2',
            required: true,
            errormessageRequired: '问题分类不能为空'
        })
        validator.execute(function (err, results, element) {
            if (!err) {
                if (spinner && spinner.el) return;//如果存在菊花则不执行返回
                spinner = new Spinner().spin($('.addQuestion')[0]);

                var question = $('#question-edit').val();
                var content = editor.getContent();
                var sortID = $('#categoriesSelect2').select2("val")[0];
                var score = $('#select-score').val();
                var type = $('#select-type').val();
                var inviteID = "";
                var inviteName = "";
                if(add_type == 1){
                    $($('#input-invite').select2("data")).each(function (i, obj) {
                        inviteID += inviteID == "" ? obj.id : "," + obj.id;
                    });
                    $($('#input-invite').select2("data")).each(function (i, obj) {
                        inviteName += inviteName == "" ? obj.userName : "," + obj.userName;
                    });
                }
                if(add_type == 2){
                    inviteID = $('#input-invite').data("userid");
                    inviteName = $('#input-invite').data("username");
                }
                var data = {
                    question: question,
                    content: content,
                    sortID: sortID,
                    score: score,
                    type: type,
                    inviteID: inviteID,
                    inviteName: inviteName
                };
                console.dir(data);
                $.post('/question/toAsk/setQuestion', data, function (result) {
                    if (result.message) {
                        spinner.stop();
                        tip.open(result.message, 1000);
                    } else {
                        if(add_type == 1){
                            window.location.href = "/question/detailedQuestion/" + result.data.id;
                        }
                        if(add_type == 2){
                            spinner.stop();
                            comfirmbox.destroy();
                            tip.open("向专家提问成功，请等待专家回答", 2000);
                        }
                    }
                });
            }
        });
    }

    /**
    * 初始化选择控件
    * type 1:可选择回答人，2：固定回答人
     */
    exports.initSelect_toAsk = function(type) {
        type = type ? type : 1;
        /**
         * 邀请回答
         */
        if(type == 1){
            var input_invite = require('../common/input_invite');
            input_invite.initSelect2("input-invite", 500);
        }
        /**
         * 初始化选择分类组件
         */
        var Kcategory = require('../common/k-category');
        new Kcategory({
            element: $('#categoriesSelect2'),
            parent: '.categories-box',
            width: 550,
            limit: 1,
            url: constant.ROOT_PATH + 'question/getQuestionSort'
        });
    }
});
