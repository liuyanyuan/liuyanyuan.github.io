/**
 * Created by peng.xie on 14-1-13.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var Tip = require('../common/tip');
    var Share = require('../common/share');
    var Turntask = require('../common/turn-task');
    var Spinner = require("spin");
    var editor = UM.getEditor('myEditor');
    var ImgFullSizeView = require('../common/img-fullSizeView');

    ImgFullSizeView.imgFullSizeView(".question-right-explain");
    /**
     * 滚动加载动态数据
     */
    var scrollMonitor = require('scrollmonitor');
    var elementWatcher = scrollMonitor.create($('#trendMore'));
    elementWatcher.enterViewport(function () {
        var trendsWrapper = $('#main-otherList');
        var questionId = parseInt($('#trendMore').data('question-id'));
        var userId = parseInt($('#trendMore').data('user-id'));
        var page = parseInt($('#trendMore').data('page'));
        var totalPage = parseInt($('#trendMore').data('total-page'));
        if (page < totalPage) {
            $.get('/question/getMoreAnswers', {questionId: questionId, page: page + 1, userId: userId}, function (result) {
                trendsWrapper.append(result);
                $('#trendMore').data('page', page + 1);
            });
        }
    });

    /**
     * 回复或补充编辑框淡入淡出
     */
    $('#btn-IWantAnswer').on('click', function () {
        if ($('.main-edit').data('key') != 'answer') {
            $('.main-edit').addClass('fn-hide');
            $('.main-edit').data('key', 'answer')
            $('.main-edit .box-head').html('我来解答');
            $('.main-edit .question-btn').html('提交回答');
//            $('.main-edit .main-ueditor-info').removeClass('fn-hide');
            $('#main-ueditor-check').attr("checked", false);
            editor.setContent('');

//            var questionId = $('#question-submit').data('question-id');
//            $.get('/question/searchMyAnswer', {questionId: questionId}, function (result) {
//                if (result != null) {
//                    editor.setContent(result.content);
//                    $('.main-edit').data('answerid', result.id);
//                }
//            });
        }
        editInOrOut();
    });
    $('#btn-addExplain').on('click', function () {
        if ($('.main-edit').data('key') != 'explain') {
            $('.main-edit').addClass('fn-hide');
            $('.main-edit').data('key', 'explain')
            $('.main-edit .box-head').html('问题补充');
            $('.main-edit .question-btn').html('提交补充');
//            $('.main-edit .main-ueditor-info').addClass('fn-hide');
            if ($('.question-right-explain').html() != null) {
                editor.setContent($('.question-right-explain').html());
            }
        }
        editInOrOut();
    });
    function editInOrOut() {
        if ($('.main-edit').hasClass('fn-hide')) {
            $('.main-edit').fadeIn();
            $('.main-edit').removeClass('fn-hide');
        }
        else {
            $('.main-edit').fadeOut();
            $('.main-edit').addClass('fn-hide');
        }
    };

    /**
     * 绑定答案板块中点击事件
     */
    var qaAnswer = require('../qa-answerlist');
    $('#main-otherList').on('click', '[data-role="c-trigger"]', function (event) {
        event.preventDefault();
        var ele = $(this);

        clickFunction(ele);
    });
    /**
     * 绑定采纳答案中的点击事件
     */
    $('#main-adopted').on('click', '[data-role="c-trigger"]', function (event) {
        event.preventDefault();
        var ele = $(this);

        clickFunction(ele);
    });
    function clickFunction(ele) {
        switch (ele.data('trigger-type')) {
            case 'reply':
                qaAnswer.getReplyList(ele);
                break;
            case 'reply-reply':
                qaAnswer.showReplyForm(ele);
                break;
            case 'add-answer':
                qaAnswer.addAnswer(ele);
                break;
            case 'up-answer':
                qaAnswer.voteAnswer(ele, 1);
                break;
            case 'down-answer':
                qaAnswer.voteAnswer(ele, 0);
                break;
            default :
                break;
        }
    }

    /**
     * 绑定提交答案或问题补充按钮
     */
    var spinner1;
    $('#question-submit').on('click', function () {
        if (editor.hasContents()) {
            if (spinner1 && spinner1.el) return;//如果存在菊花则不执行返回
            spinner1 = new Spinner().spin($('.main-edit')[0]);

            var key = $('.main-edit').data('key');
            var aynonvmos = $('#main-ueditor-check').prop("checked") ? 1 : 0;
            var content = editor.getContent();
            //用于判断是否为修改自己的历史回答
//            var answerID = $('.main-edit').data('answerid');
            if (key == 'answer') {
                var data = {
                    info: {
                        questionId: $(this).data("question-id"),
                        content: content,
                        parentId: null,
                        aynonvmos: aynonvmos
                    },
                    type: 2,
                    parentUserName: $(this).data("user-name"),
                    parentUserId: $(this).data("user-id"),
                    pageStr: 'detailedQuestion'
                };
//                if (answerID) {
//                    data.info.id = answerID;
//                }
                $.post('/personal/msg/reply', data, function (result) {
                    $('.main-edit').fadeOut();
                    $('.main-edit').addClass('fn-hide');

//                    if (data.info.id) {
//                        //修改历史回复
//                        $('#main-otherList #answer-' + answerID).remove();
//                        $('#resultStore').prepend(result);
//                        //***
//                        //未完成的代码，作用为修改被采纳的答案
//                        //***
//                    } else {
                    $('#main-otherList').prepend(result);
//                    }
                    editor.setContent('');
                    $('.main-otherAnswer .box-head').html('其他答案');
                    //判断该问题是否已有被采纳答案
                    if ($('#main-adopted .qa-answer-item').length > 0) {
                        $('#main-otherList .qa-answer-adopted-btn').remove();
                    }

                    spinner1.stop();
                });
            }
            else {
                var data = {
                    questionId: $(this).data("question-id"),
                    content: content
                }
                $.post('/question/toAsk/updateQuestion', data, function (result) {
                    if (result.code == 200) {
                        editInOrOut();
                        if ($('.question-right-explain').html() != null) {
                            $('.question-right-explain').html(content);
                        } else {
                            $('.question-right-info').after('<div class="question-right-explain"></div>');
                            $('.question-right-explain').html(content);
                        }
                    } else {
                        Tip.open('修改补充说明失败，请重试', 700);
                    }

                    spinner1.stop();
                });
            }
        }
        else {
            Tip.open('请输入待提交内容', 700);
        }
    });

    /**
     * 绑定采纳答案按钮
     */
    var spinner2;
    $('.qa-answer-adopted-btn').on('click', function () {
        if (spinner2 && spinner2.el) return;//如果存在菊花则不执行返回
        spinner2 = new Spinner().spin($('.main-toAsk')[0]);

        var questionId = $(this).data('qa-id');
        var answerID = $(this).data('id');
        var userId = $(this).data('user-id');
        var score = $(this).data('score');
        var item = $(this).closest('.qa-answer-item');
        $.post('/question/best-answer', {questionId: questionId, id: answerID, score: score, userId: userId}, function (result) {
            if (result.code == 200) {
                $('.qa-answer-adopted-btn').remove();
                $(item).find('.qa-op-right').append($(item).find('.qa-answer-info'));
                $('#main-adopted').append(item);
                $('#main-adopted').fadeIn();
                if ($('#main-otherList').find('div').length == 0)
                    $('.main-otherAnswer .box-head').html('');

                $('#btn-updateReward').addClass('km-btn-disabled').data('hasbestanswer', true);
            } else {
                Tip.open('采纳答案失败，请重试', result.message);
            }

            spinner2.stop();
        });
    });

    /**
     * 绑定分享按钮事件
     */
    $("#share").on("click", function () {
        Share.share({ id: $(this).data("id"), type: 5, title: $(this).data("title")});
    });

    /**
     * 绑定转为任务按钮事件
     */
    $("#turnTask").on("click", function () {
        Turntask.turnTask(
            {
                tasktype: 1,
                title: $(this).data("title"),
                refId: $(this).data("id"),
                refType: 5,
                cb: function (result) {
                    if (result.success) {
                        Tip.open('转为任务成功', 700);
                    } else {
                        Tip.open('转为任务失败，请重试', 700);
                    }
                }
            }
        );
    });

    /**
     * 绑定收藏按钮事件
     */
    $("#collect").on("click", function () {

    });

    /**
     * 绑定调整悬赏积分按钮事件
     */
    var spinner3;
    $("#btn-updateReward").on("click", function () {
        if ($(this).data('hasbestanswer') != true) {
            if (spinner3 && spinner3.el) return;//如果存在菊花则不执行返回
            spinner3 = new Spinner().spin($('.question-right-reward-choose')[0]);

            var data = {
                questionId: $(this).data("question-id"),
                score: $('#select-reward').val()
            }
            $.post('/question/toAsk/updateQuestion', data, function (result) {
                if (result.code == 200) {
                    Tip.open('调整悬赏积分成功', 700);
                } else {
                    Tip.open('调整悬赏积分失败，' + result.message, 700);
                }
                spinner3.stop();
            });
        }
    });


    /**
     *
     */
});