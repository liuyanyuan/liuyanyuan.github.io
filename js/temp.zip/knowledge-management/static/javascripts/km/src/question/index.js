/**
 * Created by peng.xie on 14-1-4.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Paging = require('../common/paging');
    var Spinner = require("spin");
    var Tip = require('../common/tip');
    var Share = require('../common/share');
    var Turntask = require('../common/turn-task');
    var ImgFullSizeView = require('../common/img-fullSizeView');

    /**
     * 热搜关键字浮动
     */
//    var Sticky = require('sticky');
//    var st1 = Sticky('#hotkey-box', 130, function (status) {
//    });
//    $(window).on('resize', function (event) {
//        st1.adjust();
//    });
    /**
     * 问答分类查询问题
     */
    var navtree = require("../common/navtree");
    navtree.clickHandle(function (id) {
        window.location.href = "/question/classifiedData#navtreeid=" + id;
    })
    /**
     * 排行榜切换
     */
//    $('.rankingList-box').on('mouseover', '.rankingList', function (event) {
//        $(this).parent().find('.selected').removeClass('selected');
//        $(this).addClass('selected');
//    });
//    $('.rankingList-box').each(function () {
//        $(this).find('.rankingList:first').addClass('selected');
//    });
    /**
     * 排行榜Tap
     */
    var Tabs = require('tabs');
    var tab1 = new Tabs({
        element: "#J-list-bd",
        triggers: '#J-list-bd .km-tab-v2-nav li',
        panels: '#J-list-bd .km-tab-v2-switch',
        activeTriggerClass: 'cur'
    });
    new Tabs({
        element: "#J-ranking-bd",
        triggers: '#J-ranking-bd .km-tab-v2-nav li',
        panels: '#J-ranking-bd .km-tab-v2-switch',
        activeTriggerClass: 'cur'
    });

    /*绑定分页控件事件*/
//    $('.ui-paging').each(function (i, obj) {
//        new Paging({
//            element: obj,
//            url: constant.ROOT_PATH + 'question/getQuestionList',
//            params: {type: i},
//            targetId: 'main-tab-question' + i,
//            cb: function (data) {
//                $('#main-tab-question' + i).html(data.html);
//            }
//        })
//    });

    /**
     * 请求当页数据
     */
    /*页面初始化自动获取列表*/
    var hash = window.location.hash;
    var data = decodeURI(hash).substring(1).toJsonObj();
    if (data.type != 0) {
//        $('#J-list-bd .km-tab-v2-switch').removeClass('cur');
//        $('#J-list-bd .km-tab-v2-switch').eq(data.type).addClass('cur');
        tab1.switchTo(data.type);
    }
    getList(data.type || 0, data.page || 1);

    var spinner;

    function getList(type, page) {
        window.location.hash = 'type=' + type + '&page=' + page;
        if (spinner && spinner.el) return;//如果存在菊花则不执行返回
        spinner = new Spinner().spin(document.getElementById('km-tab-v2-main'));
        $.get(constant.ROOT_PATH + 'question/getQuestionList', { type: type, page: page}).done(function (result) {
            $('#main-tab-question' + type).html(result.html);
            $.get('/common/paging', {paging: result.paging}, function (result2) {
                $('#main-tab-footer' + type).html(result2);

                /*绑定分页控件事件*/
                var paging = new Paging({
                    element: $('#main-tab-footer' + type + ' .ui-paging'),
                    url: constant.ROOT_PATH + 'question/getQuestionList',
                    params: {type: type},
                    targetId: 'main-tab-question' + type,
                    cb: function (data, newPage) {
                        $('#main-tab-question' + type).html(data.html);
                        window.location.hash = 'type=' + type + '&page=' + newPage;

                        ImgFullSizeView.imgFullSizeView(".question-content");
                    }
                })
                paging.toPage(page);
                ImgFullSizeView.imgFullSizeView(".question-content");
            });
        }).always(function () {
            spinner.stop();
        });
    }

    //tab页跳转自动获取数据
    tab1.on('switch', function (toIndex, fromIndex) {
        var type = toIndex;
        if ($.trim($('#main-tab-footer' + type).html()).length == 0) {
            getList(type, 1);
        } else {
            window.location.hash = 'type=' + type + '&page=' + (data.page || 1);
        }
    });

    /**
     * 首页获取问题部分答案
     */
    $('#J-list-bd').on('click', '.qa-btn-getAnswer', function () {
        var thisObj = $(this);
        var id = thisObj.data('id');
        var nextDiv = thisObj.closest('.index-question').next();
        if ($.trim(nextDiv.html()).length == 0) {
            var spinner = new Spinner().spin(thisObj[0]);
            $.get(constant.ROOT_PATH + 'question/detailedQuestion/' + id, { fromType: 'index'}).done(function (result) {
                nextDiv.html(result);
                nextDiv.removeClass('fn-hide');
            }).always(function () {
                spinner.stop();
            });
        } else {
            if (nextDiv.css('display') == 'none')
                nextDiv.fadeIn();
            else
                nextDiv.fadeOut();
        }
    })
    /**
     * 首页收起答案
     */
    $('#J-list-bd').on('click', '.btn-answer-close', function () {
        $(this).closest('.index-answer').fadeOut();
    })

    /**
     * 输入框获取焦点和失去焦点时，是否显示before的文字
     */
    $('body').on('focusin', '.imitate-textarea-box', function () {
        $(this).addClass('imitate-textarea-foucs');
    }).on('focusout', '.imitate-textarea-box', function () {
        if ($.trim($(this).find('.imitate-textarea').html()).length == 0) {
            $(this).removeClass('imitate-textarea-foucs');
        }
    })

    /**
     * 绑定分享按钮事件
     */
    $('#J-list-bd').on("click", '.share', function () {
        Share.share({ id: $(this).data("id"), type: 5, title: $(this).data("title")});
    });

    /**
     * 绑定转为任务按钮事件
     */
    $('#J-list-bd').on("click", '.turnTask', function () {
        Turntask.turnTask(
            {
                tasktype: 1,
                title: $(this).data("title"),
                refId: $(this).data("id"),
                refType: 5,
                cb: function (result) {
                    if (result.success) {
                        Tip.open('转为任务成功', 700);
                    } else {
                        Tip.open('转为任务失败，请重试', 700);
                    }
                }
            }
        );
    });

    /**
     * 绑定收藏按钮事件
     */
    $('#J-list-bd').on("click", '.collect', function () {

    });

    /**
     * 绑定添加答案按钮事件
     */
    $('#J-list-bd').on("click", '.qa-btn-answer', function () {
        var thisObj = $(this);
        var content = thisObj.closest('.questionList-footer').find('.imitate-textarea').html();
        if ($.trim(content).length != 0) {
            var data = {
                info: {
                    questionId: thisObj.data("question-id"),
                    content: content,
                    parentId: null,
                    aynonvmos: 0//非匿名提交
                },
                type: 2,
                parentUserName: thisObj.data("user-name"),
                patentUserId: thisObj.data("user-id"),
                pageStr: 'questionIndex'
            };

            $.post('/personal/msg/reply', data, function (result) {
                thisObj.closest('.questionList-footer').find('.imitate-textarea').html('');
                thisObj.closest('.questionList-footer').find('.imitate-textarea-box').removeClass('imitate-textarea-foucs');
                //当前弹出答案列表的话，插入
                if ($.trim(thisObj.closest('.index-question').next().html()).length != 0) {
                    thisObj.closest('.index-question').next().find('.other-list').prepend(result);
                }
                //若不存在查看答案按钮，插入
                if (thisObj.closest('.qa-btn-box').find('.qa-btn-getAnswer').length == 0) {
                    thisObj.closest('.qa-btn-box').prepend('<a class="km-btn qa-btn-getAnswer" data-id="' + thisObj.data("question-id") + '" data-count="1"><span class="km-ico km-ico-mini-4"></span>查看答案(1)</a>');
                } else {
                    var count = thisObj.closest('.qa-btn-box').find('.qa-btn-getAnswer').data('count');
                    count += 1;
                    thisObj.closest('.qa-btn-box').find('.qa-btn-getAnswer').data('count', count);
                    thisObj.closest('.qa-btn-box').find('.qa-btn-getAnswer').html('<span class="km-ico km-ico-mini-4"></span>查看答案(' + count + ')');
                }

            });
        }
        else {
            Tip.open('请输入待提交内容', 700);
        }
    });
});