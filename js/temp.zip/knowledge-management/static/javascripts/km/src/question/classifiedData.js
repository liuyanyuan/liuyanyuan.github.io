/**
 * Created by peng.xie on 14-3-18.
 */
define(function (require, exports, module) {
    var $ = require("$");
    var constant = require('../constant');
    var Paging = require('../common/paging');
    var Spinner = require("spin");

    var navtree = require("../common/navtree");

    /*页面初始化自动获取列表*/
    var hash = window.location.hash;
    if (hash.indexOf("navtreeid") >= 0) {
        var data = decodeURI(hash).substring(1).toJsonObj();
        getList(data.navtreeid);
    }
    /*点击左边树结构获取列表*/
    navtree.clickHandle(function (id) {
        window.location.hash = "#navtreeid=" + id;
        getList(id);
    })
    var spinner;

    function getList(id) {
        $("#main-body").data("id", id);
        if (spinner && spinner.el) return;//如果存在菊花则不执行返回
        spinner = new Spinner().spin(document.getElementById("navtree-inner"));
        $.get(constant.ROOT_PATH + 'question/classifiedList', {categoryId: id, page: 1, limit: 15}).done(function (result) {
            $("#main-body").html(result.html);
            $.get('/common/paging', {paging: result.paging}, function (result2) {
                $("#main-foot").html(result2);

                /*绑定分页控件事件*/
                new Paging({
                    element: $('.ui-paging'),
                    url: constant.ROOT_PATH + 'question/classifiedList',
                    params: {categoryId: $("#main-body").data("id"), limit: 15},
                    targetId: 'main-body',
                    cb: function (data) {
                        $("#main-body").html(data.html);
                    }
                })
            });
        }).always(function () {
                spinner.stop();
            });
    }
})