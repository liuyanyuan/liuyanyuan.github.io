define(function(require, exports, module) {
    var $ = require('$');
    var Tip = require('./common/tip');
    var isIe = window.navigator.userAgent.indexOf('MSIE') > 1;
    /**
     * 点击回答的评论按钮
     */
    exports.getReplyList = function(ele) {
        var item = ele.closest('.qa-answer-item');

        item.toggleClass('qa-reply-open').siblings().removeClass('qa-reply-open');
        var textarea = item.find('.imitate-textarea');
        var parentId = ele.data('id');
        var userName = ele.data('user-name');
        var userId = ele.data('user-id');


        $.data(textarea[0], 'parent-id', parentId);
        $.data(textarea[0], 'user-name', userName)
        $.data(textarea[0], 'user-id', userId);
//        textarea.data('parent-id', parentId);
//        textarea.data('user-name', userName);
//        textarea.data('user-id', userId);

        textarea.empty();
        if(isIe) {
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-user-name=' + userName + ' data-user-id='+ userId +'>回复' + userName + ':</button>');
        } else {
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-user-name=' + userName + ' data-user-id='+ userId +'>回复' + userName + ':</button><br >');
        }
        textarea.prepend(button);
        placeCursor(textarea);

    };
    /**
     * 点击回答的回答的评论按钮
     * @param ele
     */
    exports.showReplyForm = function(ele) {
        var item = ele.closest('.qa-answer-item');
        var form = item.find('.qa-answer-form');
        var textarea = item.find('.imitate-textarea');
        var userName = ele.data('user-name') || null ;
        var userId = ele.data('user-id') || null;
        var id = ele.data('id');

        $.data(textarea[0], 'parent-id', id);
//        textarea.data('parent-id', id);

        if(!!userName) {
            textarea.empty();
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;" data-user-name=' + userName + ' data-user-id='+ userId +'>回复' + userName + ':</button><br >');
            textarea.prepend(button);
            placeCursor(textarea);
            textarea.focus();

        }

    };

    /**
     * 获取textarea里面的数据
     * @param textarea
     * @returns {*|String}
     */
    function filterHtml(textarea) {
        textarea.find('button').remove();
        var html = textarea.html();

//        html = html.replace(/<[/]V?[^>]*>/g, '\n'); //去除HTML </..>tag
//        html = html.replace(/<V?[^>]*>/g, ''); //去除HTML <..>tag
        html = html.replace('/[|]*\n/g','\n'); //去除行尾空白
        html = html.replace(/\n[\s||]*\r/g, '\n'); //去除多余空行
        return html;
    };

    /**
     * 顶或踩回答
     * @param ele
     */
    exports.voteAnswer = function (ele, vote) {
        var id = ele.data('id');
        $.post('/personal/voteAnswer', {commentId: id, updown: vote}, function(result) {
            if(result.success) {
                var voteCount = parseInt(ele.children('.voteCount').html());
                if(vote == 0) {
                    vote = 1;
                }
                voteCount += vote;
                ele.children('.voteCount').html(voteCount);
            }

        });
    }

    /**
     * 对动态添加一条回复
     * @param ele
     */
    exports.addAnswer = function (ele) {

        var trendItem = ele.closest('.trend-item'),
            textarea = ele.closest('form').find('.imitate-textarea');


        var refId = textarea.data('qa-id');
        var type = textarea.data('type') || trendItem.find('input[name="type"]').val();
        var parentId = textarea.data('parent-id');
        var parentUserName = textarea.data('user-name');
        var patentUserId = textarea.data('user-id');

        if(textarea.find('button').length > 0 ) {
            var button = textarea.find('button');
            parentUserName = button.data('user-name');
            patentUserId = button.data('user-id');
        }

        var content = filterHtml(textarea);
        if(type == 4) {
            var info = {topicId: refId, content: content, parentId: parentId};
        } else {
            var info = {questionId: refId, content: content, parentId: parentId};
        }
        if(content.replace(/<(S*?)[^>]*>.*?|<.*?\/>|\s|(&nbsp;)|(char) 12288/g, '') === '') {
            Tip.open('回复内容为空，请输入回复内容', 700);
        } else {
            $.post('/personal/msg/reply', {info: info, type: type, parentUserName: parentUserName, patentUserId: patentUserId}, function(result) {
                ele.closest('.qa-box').children('.qa-answer-list').append(result);
                textarea.empty();
                if(patentUserId == null) {
                    var item = trendItem.find('.answer-count');
                    item.html(parseInt(item.html()) + 1);
                } else {
                    var item = ele.closest('.qa-answer-item').find('.answer-reply-count');
                    item.html(parseInt(item.html()) + 1);
                }
            });
        }
    }

    /**
     * 模拟textarea控件 div设置光标位置
     * @param ele
     */
    function placeCursor(ele) {
        ele = ele.get()[0];
        if(typeof window.getSelection != 'undefined' && typeof document.createRange != 'undefined') {
            var range = document.createRange();
            range.selectNodeContents(ele);
            range.collapse(false);
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        } else if(typeof document.body.createTextRange != 'undefined') {
            var textRange = document.body.createTextRange();
            textRange.moveToElementText(ele);
            textRange.collapse(false);
            textRange.select();
        }
    }


});