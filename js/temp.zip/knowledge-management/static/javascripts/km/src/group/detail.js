define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Confirmbox = require('confirmbox');
    var tip = require('../common/tip');
    var CatalogTree = require('../personal/catalog-tree');
    var groupMember = require('./member');
    var groupCommon = require('./groupCommon');
    var groupId = $("body").attr("data-groupid");
    var navtree = require("../common/navtree");
    var xss = require('../xss/index');

    navtree.clickHandle(function(id,name){
        window.location.href = '/group/category/list?categoryid=' + id +'&keyword='+name;
    });

    //群组公告（活动）
    groupCommon.groupNotice();
    //加入群组
    $("#putIn-group").on("click",function(){
        var _this = $(this);
        var users = _this.data("manages");
        var groupName = _this.data("groupname");
        var authType = _this.data("authtype"); //1：允许任何人加入，2：需要身份验证
        var data = [{"userId": 0}];
        if(authType == 1){
            groupMember.putInGroup(groupId,function(rs){
                if(rs.success) {
                    tip.open("加入成功", 700);
                    location.reload();
                } else {
                    tip.open("加入失败", 700);
                }
            });
        }else if(authType == 2){
            groupMember.addMember_askForPutIn(users,groupId,groupName);
        }
    });

    //成员退出群
    $("#exit-group").on("click",function(){
        var _this = $(this);
        var groupName = _this.parents("form").data("groupname");
        var userId = 0; //0：成员退出群在路由中获取当前用户id
        Confirmbox.confirm("确认退出 <span class='text-color-em'>"+xss(groupName)+"</span> 群？<br/>退出后需再次申请方可加入，退出前发布的个人记录及文件将保留在群中！", '退出群组',function() {
            groupMember.deleteMember(groupId,userId,function(rs){
                if(rs.success) {
                    tip.open("已退出群", 700);
                    location.href = "/group";
                } else {
                    tip.open("退出群失败", 700);
                }
            });
        },{
            width: 300,
            closeTpl: '×'
        });
    });

    //解散群、删除群
    $("#dismiss-group").on("click",function(){
        var groupName = $(this).parents("form").data("groupname");
        Confirmbox.confirm("确认解散 <span class='text-color-em'>"+xss(groupName)+"</span> 群？<br/>解散后该群中的所有数据(话题、文档、成员)将会被删除！", '解散群',function() {
            $.ajax({
                url:constant.ROOT_PATH + "group/delGroup",
                type:"post",
                processData:false,
                contentType:"application/json",
                data: JSON.stringify({groupId:groupId}),
                success:function(result) {
                    if(result.success) {
                        location.href = "/group";
                    } else {
                        tip.open("解散群失败", 2000);
                    }
                },
                error:function(){
                    tip.open("请求失败", 2000);
                }
            });
        },{
            width: 300,
            closeTpl: '×'
        });
    });

    //点击编辑群组按钮
    var oldData = {};
    $("#edit-groupInfo-btn").on('click',function(){
        var imgId = $('#userAvatar').attr('data-imgid');
        var groupName = $("#groupName-text").text();
        var description = $("#description-text").text();
        var category = $("#category-text").text();
        var department = $("#department-text").text();
        var categoryId = $("#category-text").attr("data-id");
        var departmentId = $("#department-text").attr("data-id");
        var authType = $("#authType-text").attr("data-val");
//        var guessAccess = $("#guessAccess-text").attr("data-val");
        oldData = {
            'name': groupName,'img': imgId,'description':description,'categoryId':categoryId,'departmentId':departmentId,'category':category,'department':department,'authType':authType
//            ,'guessAccess':guessAccess
        };
        groupInfoToEdit(oldData);
        $(".edit-groupImg").show();
        $("#groupInfo-form span.info-show").hide().siblings("span.info-hide").show();
//        if(authType == 0){
//            $("input[name='group-guessAccess']").attr("disabled","disabled");
//        }
        $(this).hide().siblings("#save-groupInfo-btn").show();
    });

    //编辑群组头像
    $(".edit-groupImg").on('click',function(){
        groupCommon.uploadGroupAvatar();
    });

    //树组件初始化
    new CatalogTree({
        trigger: '#category-edit',
        treeId: 'groupTypeTree',
        width: 500,
        hasBtn: false,
        title:"选择群组分类",
        onlyLeaf:true,
        parmas: {type:"groups"},
        url: constant.ROOT_PATH + 'treeModel',
        cb: function(result) {
            if(result.name){
                $("#category-edit").val(result.name).attr("data-id",result.target);
            }else{
                tip.open("请选择子节点！",2000);
            }
        }
    });

//    new CatalogTree({
//        trigger: '#department-edit',
//        treeId: 'groupDepartmentTree',
//        width: 500,
//        hasBtn: false,
//        title:"选择部门",
//        parmas: {type:"organization"},
//        url: constant.ROOT_PATH + 'treeModel',
//        cb: function(result) {
//            $("#department-edit").val(result.name).attr("data-id",result.target);
//        }
//    });

    //选择验证信息为不允许任何人，则群公开禁选
//    $("input[name='group-authType']").on("click",function(){
//        var _this = $(this);
//        if(_this.val() == 0){
//            $("input[name='group-guessAccess']").attr("disabled","disabled");
//        }else{
//            $("input[name='group-guessAccess']").removeAttr("disabled");
//        }
//    });

    //保存编辑-群组
    $("#save-groupInfo-btn").on('click',function(){
        var imgId = $('#userAvatar').attr('data-imgid');
        var groupName = $("#groupName-edit").val();
        var description = $("#description-edit").val();
        var category = $("#category-edit").val();
        var department = $("#department-edit").val();
        var categoryId = $("#category-edit").attr("data-id");
        var departmentId = $("#department-edit").attr("data-id");
        var authType = $("input[name='group-authType']:checked").val();
//        var guessAccess = $("input[name='group-guessAccess']:checked").val();  //1:允许非本群人员访问,2:允许非本群人员以访问和发言
        if($.trim(groupName) == ""){
            tip.open("群组名不能为空",1000);
            $("#groupName-edit").focus();
            return false;
        }
        if(groupName.length > 50){
            tip.open("群组名长度不能大于50",1000);
            $("#groupName-edit").focus();
            return false;
        }
        if($.trim(description) == ""){
            tip.open("群组描述不能为空",1000);
            $("#description-edit").focus();
            return false;
        }
        if(description.length > 140){
            tip.open("群组描述长度不能大于140",1000);
            $("#description-edit").focus();
            return false;
        }
        var data = {
            'name': groupName,
            'img': imgId,
            'description':description,
            'categoryId':categoryId,
            'departmentId':departmentId,
            'authType':authType
//            ,
//            'guessAccess':guessAccess
        };
        var dataobj = {
            'name': groupName,
            'img': imgId,
            'description':description,
            'categoryId':categoryId,
            'departmentId':departmentId,
            'category':category,
            'department':department,
            'authType':authType
//            ,
//            'guessAccess':guessAccess
        };
        $.ajax({
            url:constant.ROOT_PATH + 'group/editGroup',
            type:"post",
            processData:false,
            contentType:"application/json",
            data: JSON.stringify({groupid:groupId,data:data}),
            success:function(result) {
                if(result.success) {
                    tip.open("编辑成功", 700);
                    groupInfoInit(dataobj);
                    hideEditPanel();
                } else {
                    tip.open("编辑失败", 700);
                    groupInfoInit(oldData);
                    hideEditPanel();
                }
            },
            error:function(){
                tip.open("请求失败", 700);
                groupInfoInit(oldData);
                hideEditPanel();
            }
        });
    });

    //隐藏编辑面板，显示文本信息——编辑群组
    function hideEditPanel(){
        $(".edit-groupImg").hide();
        $("#groupInfo-form span.info-show").show().siblings("span.info-hide").hide();
        $("#save-groupInfo-btn").hide().siblings("#edit-groupInfo-btn").show();
    }

    //成功或失败后跟新显示文本信息——编辑群组
    function groupInfoInit(obj){
        var authTypes = ["不允许任何人","允许任何人","需要身份验证"];
//        var guessAccess_s = ["允许非本群人员访问","允许非本群人员访问并发言"];
        $('#userAvatar').attr("src",'/files/show/' +obj.img).attr('data-imgid',obj.img);
        $("#groupName-text").text(obj.name);
        $("#category-text").text(obj.category).attr("data-id",obj.categoryId);
        $("#department-text").text(obj.department).attr("data-id",obj.departmentId);
        $("#authType-text").text(authTypes[obj.authType]).attr("data-val",obj.authType);
//        $("#guessAccess-text").text(guessAccess_s[obj.guessAccess-1]).attr("data-val",obj.guessAccess);
        $("#description-text").text(obj.description);
    }

    //初始化编辑面板——编辑群组
    function groupInfoToEdit(obj){
        $("#groupName-edit").val(obj.name);
        $("#category-edit").val(obj.category).attr("data-id",obj.categoryId);
        $("#department-edit").val(obj.department).attr("data-id",obj.departmentId);
        $("input[name='group-authType'][value="+obj.authType+"]").attr("checked",true);
//        $("input[name='group-guessAccess'][value="+obj.guessAccess+"]").attr("checked",true);
        $("#description-edit").val(obj.description);
    }
})