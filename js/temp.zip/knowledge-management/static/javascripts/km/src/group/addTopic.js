/**
 * Created by yanyuan.liu on 14-2-20.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var vote = require('../vote/addVote');
    var tip = require('../common/tip');
    var constant = require('../constant');
    var editor = UM.getEditor('myEditor');
    var Validator = require('validator');
    var groupCommon = require('./groupCommon');
    var navtree = require("../common/navtree");
    var groupId = $("body").data("groupid");

    navtree.clickHandle(function(id,name){
        window.location.href = '/group/category/list?categoryid=' + id +'&keyword='+name;
    });

    //添加、引入投票
    vote.selectAddVote_init({trigger:"#addVote",groupId:groupId});

    //表单验证
    var validator = new Validator({
        element: '#addTopicForm'
    });
    Validator.addRule("topicTitle",function(options){
        if(options.element.val().length < 100){
            return true;
        }else{
            return false;
        }
    },'{{display}}长度不能大于100');
    Validator.addRule("topicContent",function(options){
        var content = editor.getContent();
        if(groupCommon.removeHtmlTag(content).length < 500){
            return true;
        }else{
            return false;
        }
    },'{{display}}长度不能大于500');

    validator.addItem({
        element: '#topic-title',
        required: true,
        rule:'topicTitle',
        display: '标题'
    }).addItem({
        element: '#topicCont_valid',
        required: true,
        //rule:'topicContent',
        display: '内容'
    });


    /**
     * 添加群话题
     */
    $('#btn-submit').on('click',function(){
        var _this = $(this);
        var type = _this.data("type");
        validator.execute(function (err, results, element) {   //表单验证成功才提交数据
            console.log(groupCommon.removeHtmlTag(editor.getContent()).length);
            if (!err) {
                var voteId = $('#btn-submit').attr("data-voteid");
                var groupId = _this.data("groupid");
                var title = $("#topic-title").val();
                //var categoryId = $("#topic-action").val();
                var content = editor.getContent();
                var params = {
                    groupid:groupId,
                    topic:{
                            title:title,
                            //categoryId:parseInt(categoryId),
                            content:content,
                            voteId:parseInt(voteId)
                    }
                };
                if(type == "add") {
                    $.ajax({
                        url: constant.ROOT_PATH + 'group/addTopic',
                        type: "post",
                        processData: false,
                        contentType: "application/json",
                        data: JSON.stringify(params),
                        success: function (result) {
                            if (result.success) {
                                tip.open("添加成功", 700);
                                location.href = "/group/" + groupId;
                            } else {
                                tip.open("添加失败", 700);
                            }
                        },
                        error: function () {
                            tip.open("请求失败", 700);
                        }
                    });
                }
                if(type == "edit"){
                    var topicId = $("#topicContent").data("topicid");
                    var editParams = params.topic;
                    editParams.id = topicId;
                    $.ajax({
                        url: constant.ROOT_PATH + 'group/editTopic',
                        type: "post",
                        processData: false,
                        contentType: "application/json",
                        data: JSON.stringify(editParams),
                        success: function (result) {
                            if (result.success) {
                                tip.open("编辑成功", 700);
                                location.href = "/group/" + groupId;
                            } else {
                                tip.open("编辑失败", 700);
                            }
                        },
                        error: function () {
                            tip.open("请求失败", 700);
                        }
                    });
                }
            }
        });
    });

    //编辑器失去焦点判断验证信息
    $("#myEditor").on("blur",function(){
        //addItem_validator_editor();
        $("#topicCont_valid").val(editor.getContent());
    });
    $("#myEditor").on("keyup",function(){
        //addItem_validator_editor();
        $("#topicCont_valid").val(editor.getContent());
    });
    //给编辑器添加或删除表单验证
    function addItem_validator_editor(){
        var contLength = groupCommon.removeHtmlTag(editor.getContent()).length;
        $("#topicCont_valid").val(editor.getContent());
        if(editor.getContent() && contLength < 500){
            validator.removeItem('#topicCont_valid');
        }else{
            validator.addItem({
                element: '#topicCont_valid',
                required: true,
                //rule:'topicContent',
                display: '内容'
            });
        }
    }
});
