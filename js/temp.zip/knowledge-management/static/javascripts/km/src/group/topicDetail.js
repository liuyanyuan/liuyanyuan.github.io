/**
 * Created by yanyuan.liu on 14-3-8.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var tip = require('../common/tip');
    var vote = require('../vote/addVote');
    var constant = require('../constant');
    var editor = UM.getEditor('myEditor');
    var Paging = require('../common/paging');
    var isIe = window.navigator.userAgent.indexOf('MSIE') > 1;
    var topicId = $("body").attr("data-topicid");
    var groupId = $("body").attr("data-groupid");
    var groupCommon = require('./groupCommon');
    var Validator = require('validator');
    var ImgFullSizeView = require('../common/img-fullSizeView');
    var Spinner = require("spin");

    exports.topicDetailInit = function(){
        //添加、引入投票
        vote.selectAddVote_init({trigger:"#addVote",groupId:groupId});
        //进行投票
        vote.castVote();
        var page = location.hash.split("/")[1];
        topicReplyListInit(parseInt(page)|| 1);
        //话题、话题回复中查看大图
        ImgFullSizeView.imgFullSizeView("#detailContent",678);
    }

    //话题回复列表数据初始化
    function topicReplyListInit(page){
        var pagelimit = 15;
        var spinner;
        $.ajax({
            url:constant.ROOT_PATH + 'topics/'+topicId+'/replys',
            type:"GET",
            cache:false,
            data: {limit: pagelimit,page:page},
            beforeSend:function(){
                spinner = new Spinner().spin(document.getElementById("topicReplyList"));
            },
            success:function(data){
                var replyCount = data.count;
                $("#topicReplyList").html(data.html);
                $.get(constant.ROOT_PATH + "common/paging",{paging:{total: Math.ceil(replyCount / pagelimit),limit: 8}},function(data){
                    if(replyCount > pagelimit){
                        $("#topicReplyList").after(data);
                        //话题回复列表分页
                        var paging = new Paging({
                            element: $('.ui-paging'),
                            url: constant.ROOT_PATH + 'topics/'+topicId+'/replys',
                            params: {limit: pagelimit},
                            targetId: 'topicReplyList',
                            cb: function(data) {
                                $("#topicReplyList").html(data.html);
                                location.hash = "page/"+data.page;
                            }
                        });
                        paging.toPage(page);
                    }
                });
            },
            error:function(){
                tip.open("获取话题回复列表失败！",1000);
            },
            complete:function(){
                spinner.stop();
            }
        });
    }

    $('body').on('keydown', '.imitate-textarea', function (event) {
        var ele = $(this);
        if (event.keyCode == 8 && !isIe) {  //修复div模拟textarea的某些bug
            if (ele.find('br').length <= 0 && ele.find('div').length <= 0) {
                ele.append('<br />');
            }
        }
    });

    //表单验证
    var validator = new Validator({
        element: '#replyForm form'
    });
    Validator.addRule("replyContent",function(options){
        var content = editor.getContent();
        if(groupCommon.removeHtmlTag(content).length < 500){
            return true;
        }else{
            return false;
        }
    },'{{display}}长度不能大于500');
    validator.addItem({
        element: '#replyCont_valid',
        required: true,
        //rule:'replyContent',
        display: '内容'
    });

    //添加话题评论
    $("#btn-submit").on("click",function(){
        var _this = $(this);
        var content = editor.getContent();
        var parentId = _this.attr("data-parentId");
        var parentUserName = _this.attr("data-parentUserName");
        var patentUserId = _this.attr("data-patentUserId");
        var voteId = _this.attr("data-voteid");
        var info = {topicId: topicId, content: content, parentId: parentId, voteId:voteId};
        validator.execute(function (err, results, element) {   //表单验证成功才提交数据
            console.log(groupCommon.removeHtmlTag(content).length);
            if (!err) {
                $.ajax({
                    url:constant.ROOT_PATH + 'group/topic/reply',
                    type:'post',
                    data:{data:{info: info, type: 4, parentUserName: parentUserName, patentUserId: patentUserId},replyType:"topic"},
                    success:function(result){
                        $("#checkedVote").parent().hide();
                        _this.attr("data-voteid",0);
                        editor.setContent("");
                        tip.open("发表成功！",1000);
                        console.log(result);
                        $("#topicReplyList").prepend(result);
                        if($(".contTip").text()){
                            $(".contTip").remove();
                        }
                    },
                    error:function(){
                        tip.open("发表评论失败！",2000);
                    }
                });
            }
        });
    });

    //编辑器失去焦点判断验证信息
    $("#myEditor").on("blur",function(){
//        addItem_validator_editor();
        $("#replyCont_valid").val(editor.getContent());
    });
    $("#myEditor").on("keyup",function(){
//        addItem_validator_editor();
        $("#replyCont_valid").val(editor.getContent());
    });
    //给编辑器添加或删除表单验证
    function addItem_validator_editor(){
        var contLength = groupCommon.removeHtmlTag(editor.getContent()).length;
        $("#replyCont_valid").val(editor.getContent());
        if(editor.getContent() && contLength < 500){
            validator.removeItem('#replyCont_valid');
        }else{
            validator.addItem({
                element: '#replyCont_valid',
                required: true,
                rule:'replyContent',
                display: '内容'
            });
        }
    }

    //回复评论
    $("#topicReplyList").on("click","[data-role='c-trigger']",function(e){
        var _this = $(this);
        //点击评论的回复链接
        if(_this.hasClass("topicReplyBtn")){
            var contentBox = _this.parent().siblings();
            if(_this.hasClass("isShow")){               //如果回复框为show点击回复就hide回复框
                _this.removeClass("isShow");
                if(_this.find("span").text() > 0){      //如果回复数大于0值hide表单，否则hide回复列表div
                    contentBox.find("form.reply-floor-form").hide();
                }else{
                    contentBox.find(".qa-reply-box").hide();
                }
            }else{
                _this.addClass("isShow");
                var textArea = contentBox.find("form.reply-floor-form").find(".imitate-textarea");
                textArea.attr("data-parent-id",_this.attr("data-parent-id"));
                textArea.attr("data-user-name",_this.attr("data-user-name"));
                textArea.attr("data-user-id",_this.attr("data-user-id"));
                contentBox.find(".qa-reply-box").show().find("form.reply-floor-form").show();
                textareaInit(textArea,_this.attr("data-user-name"));
                placeCursor(textArea);
                $('body,html').animate({scrollTop:e.pageY+contentBox.height()-($(window).height()/2)},500);
            }
        }
        //点击"回复"按钮，发表评论回复(回复评论)
        if(_this.hasClass("qaReply")){
            var textArea = _this.parent().siblings().find(".imitate-textarea");
            addTopicReply(textArea,function(res){
                textArea.text("").parents("form").hide().siblings(".qa-answer-list").append(res);
            });
        }
        //点击"回复"按钮，发表评论回复中的回复（回复评论中的回复）
        if(_this.hasClass("qa-reply-r")){
            var textArea = _this.parent().siblings().find(".imitate-textarea");
            addTopicReply(textArea,function(res){
                console.log("回复评论中的回复");
                textArea.text("").parents("form").hide().parents(".qa-answer-list").append(res);
            });
        }
        //点击回复图标按钮
        if(_this.hasClass("qa-reply-trigger")){
            var replyForm = _this.parents(".qa-reply-detail").siblings("form");
            if(_this.hasClass("isShow")) {               //如果回复框为show点击回复就hide回复框
                _this.removeClass("isShow");
                replyForm.hide();
            }else{
                _this.addClass("isShow");
                var textArea = replyForm.find(".imitate-textarea");
                textArea.attr("data-parent-id",_this.attr("data-id"));
                textArea.attr("data-user-name",_this.attr("data-user-name"));
                textArea.attr("data-user-id",_this.attr("data-user-id"));
    //            textArea.attr("data-voteid",_this.attr("data-voteid"));
                textareaInit(textArea,_this.attr("data-user-name"));
                replyForm.show();
                placeCursor(textArea);
            }
        }
    });

    //添加话题评论回复
    function addTopicReply(textArea,callback){
        textArea.find('button').remove();
        var content = textArea.text();
        var parentId = textArea.attr("data-parent-id");
        var parentUserName = textArea.attr("data-user-name");
        var patentUserId = textArea.attr("data-user-id");
        var voteId = textArea.attr("data-voteid");
        var info = {topicId: topicId, content: content, parentId: parentId,voteId:voteId};
//        if($.trim(content) == ""){
//            textareaInit(textArea,parentUserName);
//            placeCursor(textArea);
//            tip.open("回复内容为空，请输入回复内容",1000);
//            return;
//        }
        if (content.replace(/<(S*?)[^>]*>.*?|<.*?\/>|\s|(&nbsp;)|(char) 12288/g, '') === '') {
            tip.open('回复内容不能为空，请输入回复内容', 700);
            textareaInit(textArea,parentUserName);
            placeCursor(textArea);
            return;
        }
        $.ajax({
            url:constant.ROOT_PATH + 'group/topic/reply',
            type:'post',
            data:{info: info, type: 4, parentUserName: parentUserName, patentUserId: patentUserId},
            success:function(result){
                var replyCountItem = textArea.parents(".detail-item-cont").find(".topicReplyBtn span");
                var replyCount = replyCountItem.text();
                replyCountItem.text(parseInt(replyCount)+1);    //界面上该条评论回复数加1
                callback(result);
            },
            error:function(){
                tip.open("回复失败！",2000);
            }
        });
    }

    //话题回复列表重新加载
    function topicReplyReload(){
        var page = 1;
        $(".ui-paging a").each(function(){
            if($(this).hasClass("ui-paging-current")){
                page = $(this).text();
            }
        });
        $.get(constant.ROOT_PATH + "topics/"+topicId+"/replys",{limit:10,page:page},function(result){
            $("#topicReplyList").html(result);
            editor.setContent("");
        });
    }

    //回复框初始化，增加回复给xxx
    function textareaInit(textarea,userName){
        textarea.empty();
        if(isIe) {
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;">回复' + userName + ':</button>');
        } else {
            var button = $('<button class="imitate-textarea-btn" contenteditable="false" oncontrolselect="return false;" onclick="return false;">回复' + userName + ':</button><br >');
        }
        textarea.prepend(button);
    }

    /**
     * 模拟textarea控件 div设置光标位置
     * @param ele
     */
    function placeCursor(ele) {
        ele = ele.get()[0];
        if(typeof window.getSelection != 'undefined' && typeof document.createRange != 'undefined') {
            var range = document.createRange();
            range.selectNodeContents(ele);
            range.collapse(false);
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        } else if(typeof document.body.createTextRange != 'undefined') {
            var textRange = document.body.createTextRange();
            textRange.moveToElementText(ele);
            textRange.collapse(false);
            textRange.select();
        }
    }
});
