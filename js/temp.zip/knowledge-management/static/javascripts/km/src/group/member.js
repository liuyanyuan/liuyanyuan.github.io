/**
 * Created by yanyuan.liu on 14-3-6.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var tip = require('../common/tip');
    var constant = require('../constant');

    //添加群成员
    exports.addMember = function(groupId,data,fn){
        $.ajax({
            url:constant.ROOT_PATH + 'group/addMember',
            type:"post",
            processData:false,
            contentType:"application/json",
            data: JSON.stringify({groupid:groupId,data:data}),
            success:function(result) {
                fn(result);
            },
            error:function(){
                tip.open("请求失败", 700);
            }
        });
    }

    //申请加入（加入群不需要身份验证）
    exports.putInGroup = function(groupId,fn){
        $.ajax({
            url:constant.ROOT_PATH + 'group/askforjoin',
            type:"post",
            processData:false,
            contentType:"application/json",
            data:JSON.stringify({userId:null,groupId:groupId,joinType:1}),//joinType 1：同意加入，2：不同意加入
            success:function(result){
                fn(result);
            },
            error:function(){
                tip.open("请求失败！", 700);
            }
        });
    }

    //申请加入（如果加入群需要身份验证）
    exports.addMember_askForPutIn = function(users,groupId,groupName){
        $.ajax({
            url:constant.ROOT_PATH + 'group/join/isapply',
            type:"post",
            data:{groupId:groupId},
            success:function(result){
                if(result.success){
                    if(result.isApply){
                        tip.open("请勿重复发出申请，耐心等待审核！", 2000);
                    }else{
                        askForJoinGroup(users,groupId,groupName);
                    }
                }
            },
            error:function(){
                tip.open("请求失败！", 2000);
            }
        });
    }

    //删除群成员(踢出/退出群)
    exports.deleteMember = function(gid,uid,fn){
        $.ajax({
            url:constant.ROOT_PATH + 'group/delMember',
            type:"post",
            processData:false,
            contentType:"application/json",
            data: JSON.stringify({groupId:gid,userId:uid}),
            success:function(result) {
                fn(result);
            },
            error:function(){
                tip.open("请求失败", 700);
            }
        });
    }

    //取消或授权管理员（设置群员角色）
    exports.setUserRole = function(gid,uid,role,fn){
        $.ajax({
            url:constant.ROOT_PATH + 'group/set-user-role',
            type:"post",
            processData:false,
            contentType:"application/json",
            data: JSON.stringify({groupId:gid,userId:uid,role:role}),
            success:function(result) {
                fn(result);
            },
            error:function(){
                tip.open("请求失败", 700);
            }
        });
    }

    function askForJoinGroup(users,groupId,groupName){
        var userName = $(".user-account-name span").text()||"";
        $.ajax({
            url:constant.ROOT_PATH + 'task/add',
            type:"post",
            data:{
                title: '申请加入群',
                message: userName+ " 申请加入群 "+groupName,
                refType:3,
                type: 1,  //只要有一人执行则结束任务
                refId:groupId,
                performers:users,
                status:1,
                deadline: '2014-4-15'
            },
            success:function(result){
                if(result.success){
                    tip.open("申请已发出，请等待审核！", 2000);
                }else{
                    tip.open("发出申请失败！", 2000);
                }
            },
            error:function(){
                tip.open("发出申请失败！", 2000);
            }
        });
    }
});
