/**
 * Created by yanyuan.liu on 14-4-3.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var Confirmbox = require('confirmbox');
    var constant = require('../constant');
    var tip = require('../common/tip');
    var Slide = require("slide");
    var uploadAvatar = require('../personal/upload-avatar');

    //群组公告（活动）
    exports.groupNotice = function(){
        if($(".groupNotice-slide ul").length > 0){
            var slide = new Slide({
                element:".groupNotice-slide",
                effect:"fade",
                interval:3000,
                activeIndex:0
            }).render();
        }
    }

    //上传群组头像
    exports.uploadGroupAvatar = function(){
        $.post(constant.ROOT_PATH + 'group/uploadAvatar', {type:2}, function(html) {
            Confirmbox.confirm(html, '上传群组头像',function() {
                uploadAvatar.submit();
            },{
                width: 600,
                closeTpl: '×'
            });
            uploadAvatar.init({
                url: constant.ROOT_PATH + 'group/setAvatar',
                trigger: '.upload-avatar-btn',
                callback: function(result) {
                    $('#userAvatar').attr('src', '/files/show/' + result.data).attr("data-imgid",result.data);
                }
            });
        });
    }

    //去除掉字符串中的html标签
    exports.removeHtmlTag = function(str){
        str = str.replace(/<\/?[^>]*>/g,'');
        str = str.replace(/[ | ]*\n/g,'\n');
        str = str.replace(/\n[\s| | ]*\r/g,'\n');
        str = str.replace(/&nbsp;/ig,'');
        return str;
    }
});
