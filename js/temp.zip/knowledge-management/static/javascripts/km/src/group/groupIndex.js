/**
 * Created by yanyuan.liu on 14-3-6.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var tip = require('../common/tip');
    var Tabs = require('tabs');
    var groupMember = require('./member');
    var groupCommon = require('./groupCommon');
    var navtree = require("../common/navtree");
    var Paging = require('../common/paging');
    var Confirmbox = require('confirmbox');

    navtree.clickHandle(function(id,name){
        window.location.href = '/group/category/list?categoryid=' + id +'&keyword='+name;
    });

    if($("#topic-list-tab").length > 0){ //群组首页中才有该tab
        var topicTab = new Tabs({
            element: '#topic-list-tab',
            triggers:'#topic-list-tab .km-tab-v1-nav li',
            panels : '#topic-list-tab .km-tab-v1-switch',
            activeTriggerClass : 'cur',
            triggerType: 'click'
        });
    }

    //群组公告（活动）
    groupCommon.groupNotice();

    $("body").on("click","a",function(){
        var _this = $(this);
        if(_this.hasClass("group_enjoin")){
            tip.open("该群暂不对外公开！",2000);
        }
        if(_this.hasClass("group_validate")){
            var groupId = _this.data("groupid");
            var groupName = _this.data("groupname");
            var users = _this.data("manages");
            Confirmbox.confirm("<span class='text-color-em'>"+groupName+"</span>需要身份验证，请先申请加入该群！", '确认',function(){
                ApplyToJoin(users,groupId,groupName,2);
            },{
                width: 300,
                confirmTpl:'<a class="ui-dialog-button-orange" href="javascript:;">申请加入</a>',
                closeTpl: '×'
            });
        }
        if(_this.hasClass("askForPutIn-group")){
            var users = _this.data("manages");
            var groupId = _this.data("groupid");
            var groupName = _this.data("groupname");
            var authType = _this.data("authtype");
            ApplyToJoin(users,groupId,groupName,authType,_this);
        }
    });

    //申请加入群组
    function ApplyToJoin(users,groupId,groupName,authType,handleObj){
        var data = [{"userId": 0}]; //0是标识，在路由中判断后取当前用户id
        if(authType == 1){          //1：允许任何人加入，2：需要身份验证
            groupMember.addMember(groupId,data,function(rs){
                if(rs.success) {
                    tip.open("加入成功", 700);
                    handleObj.hide();
                } else {
                    tip.open("加入失败", 700);
                }
            });
        }else if(authType == 2){
            console.log(users);
            groupMember.addMember_askForPutIn(users,groupId,groupName);
        }
    }

    exports.groupsPagingInit = function(type,categoryId,keyword){
        var categoryId = categoryId || 0;
        $('.ui-paging').each(function(i,obj) {
            new Paging({
                element: obj,
                url: constant.ROOT_PATH + 'group/category/list-paging/'+ type +'?categoryid='+categoryId+'&keyword='+keyword,
                params: {limit: 10},
                targetId: 'groupListBox',
                cb: function(data) {
                    $("#group-search-list").html(data);
                }
            })
        });
    }
});
