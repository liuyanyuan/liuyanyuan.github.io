/**
 * Created by yanyuan.liu on 14-2-21.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var tip = require('../common/tip');
    var constant = require('../constant');
    var Validator = require('validator');
    var groupCommon = require('./groupCommon');
    var CatalogTree = require('../personal/catalog-tree');
    var navtree = require("../common/navtree");
    var selectUsers = require("../common/selectUsersOrGroups");
    var Spinner = require("spin");

    navtree.clickHandle(function(id,name){
        window.location.href = '/group/category/list?categoryid=' + id +'&keyword='+name;
    });
    //选择人员
    selectUsers.userBoxBing();
    //树组件初始化
    new CatalogTree({
        trigger: '#groupTypeSelect',
        treeId: 'groupTypeTree',
        width: 500,
        hasBtn: false,
        title:"选择群组分类",
        onlyLeaf:true,
        parmas: {type:"groups"},
        url: constant.ROOT_PATH + 'treeModel',
        cb: function(result) {
            if(result.name){
                $("#group-type").val(result.name).attr("data-id",result.target);
                validator.removeItem('#group-type');
            }else{
                tip.open("请选择子节点！",2000);
            }
        }
    });

//    new CatalogTree({
//        trigger: '#group-department',
//        treeId: 'groupDepartmentTree',
//        width: 500,
//        hasBtn: false,
//        title:"选择部门",
//        parmas: {type:"organization"},
//        url: constant.ROOT_PATH + 'treeModel',
//        cb: function(result) {
//            $("#group-department").val(result.name).attr("data-id",result.target);
//        }
//    });

    /**
     * 上传群组头像
     */
    $('#upload-groupImg-btn').on('click',function(){
        groupCommon.uploadGroupAvatar();
    });

    //选择验证信息为不允许任何人，则群公开禁选
//    $("input[name='group-authType']").on("click",function(){
//        var _this = $(this);
//        if(_this.val() == 0){
//            $("input[name='group-guessAccess']").attr("disabled","disabled");
//        }else{
//            $("input[name='group-guessAccess']").removeAttr("disabled");
//        }
//    });

    //表单验证
    Validator.addRule("groupName",function(options){
        if(options.element.val().length < 50){
            return true;
        }else{
            return false;
        }
    },'{{display}}长度不能大于50');
    Validator.addRule("groupDescription",function(options){
        if(options.element.val().length < 140){
            return true;
        }else{
            return false;
        }
    },'{{display}}长度不能大于140');
    var validator = new Validator({
        element: '#addGroupBox form'
    });
    validator.addItem({
        element: '#group-name',
        required: true,
        rule:'groupName',
        display: '群组名称'
    }).addItem({
        element: '#group-type',
        required: true,
//        display: '群组分类'
        errormessageRequired: '请选择群组分类'
    }).addItem({
        element: '#group-description',
        required: true,
        rule:'groupDescription',
        display: '群组说明'
    });

    /**
     * 新建群组
     */
    $('#btn-submit').on('click',function(){
        var _this = $(this);
        var curUserId = $(this).data("cur-userid");
        var imgid = $('#userAvatar').attr("data-imgid");
        var group_name = $("#group-name").val();//群名
        var group_type = $("#group-type").attr("data-id");//群组类型
//        var group_department = $("#group-department").attr("data-id");//所属部门
        var group_description = $("#group-description").val();//群组描述
        var group_scale = $("#group-scale").val();//群组规模
        var group_auth_type = $("input[name='group-authType']:checked").val();//验证类型
//        var group_guest_access = $("input[name='group-guessAccess']:checked").val();//公开性
        var users = [];
        var isCurUser = false;
        $("#userBox-usersSelected li").each(function(i,obj){
            var userid = parseInt($(obj).data("id"));
            if(userid == parseInt(curUserId)){
                isCurUser = true;
            }
            users.push({"userId": userid});
        });
        if(isCurUser){
            tip.open("不能添加自己哦！",2000);
            return;
        }
        var groupdata = {
            "img":imgid,
            "name":group_name,
            "categoryId":group_type,
//            "departmentId":group_department,
            "description":group_description,
            "scale":group_scale,
            "authType":group_auth_type,
//            "guessAccess":group_guest_access,
            "members":users
        };
        console.log(groupdata);
        validator.execute(function (err, results, element) {   //表单验证成功才提交数据
            if (!err) {
                var spinner;
                $.ajax({
                    url:constant.ROOT_PATH + 'group/addGroup',
                    type:"post",
                    processData:false,
                    contentType:"application/json",
                    data: JSON.stringify(groupdata),
                    beforeSend:function(){
                        spinner = new Spinner().spin(document.getElementById("addGroupBox"));
                        _this.attr("disabled","disabled");
                    },
                    success:function(result) {
                        tip.open(result.message, 2000);
                        if(result.success) {
//                            if(result.message.indexOf("成功") != -1){
                                location.href = "/group";
//                            }
//                        } else {
//                            tip.open("添加失败", 2000);
                        }
                    },
                    error:function(){
                        tip.open("请求失败", 2000);
                    },
                    complete:function(){
                        spinner.stop();
                        _this.removeAttr("disabled");
                    }
                });
            }
        });
    });
});
