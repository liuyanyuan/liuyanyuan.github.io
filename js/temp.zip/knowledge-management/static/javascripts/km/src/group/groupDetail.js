define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Confirmbox = require('confirmbox');
    var tip = require('../common/tip');
    var Tabs = require('tabs');
    var input_invite = require('../common/input_invite');
    var Paging = require('../common/paging');
    var groupMember = require('./member');
    var groupId = $("body").attr("data-groupid");
    var groupName = $("body").data("grouname");
    var powerType = $("body").attr("data-powerType");
    var authType = $("#authType-text").attr("data-val");
    var knowledge = require('../personal/personalKnowledge');
    var mytask = require('../personal/mytask');
    var xss = require('../xss/index');
    var Spinner = require("spin");

    exports.groupDetailInit = function(){
        var pageUrl = location.href;
        var tabId = ["#tab-topic","#tab-doc","#tab-task","#tab-member"];
        var pageTabId = pageUrl.substring(pageUrl.indexOf("#"));
        var tabActiveIndex = 0;
        for(var i = 0; i < tabId.length; i++){
            if(tabId[i] == pageTabId){
                tabActiveIndex = i;
            }
        }
        var tabs = new Tabs({
            element : "#group-tabs-container",
            triggers:'#group-tabs-container .km-tab-v2-nav li',
            panels : '#group-tabs-container .km-tab-v2-switch',
            triggerType: 'click',
            activeTriggerClass : 'cur',
            activeIndex:tabActiveIndex
        });
//        if(tabActiveIndex == 2){
//            $(".groupNotice-slide").hide();
//            $("#personnelBox").show();
//        }
//        tabs.on('change:activeIndex', function(toIndex, fromIndex) {
//            if(toIndex == 2){
//                $(".groupNotice-slide").hide();
//                $("#personnelBox").show();
//            }else{
//                $("#personnelBox").hide();
//                $(".groupNotice-slide").show();
//            }
//        });
        detail_pagingInit();
        //获取文档列表
        $.ajax({
            type:"GET",
            url:constant.ROOT_PATH +"group/doc/list",
            data:{attachedId:groupId,catalog:0,order: 'asc',powerType:powerType,authType:authType},
            cache:false,
            success:function(result){
                $("#docList").html(result);
                knowledge.init();
            },
            error:function(){
                $("#docList").html("获取文档列表失败！");
            }
        });
        //获取任务列表
        $.ajax({
            type:"GET",
            url:constant.ROOT_PATH +"task/group/" + groupId + "/home",
            data: {groupName: groupName, powerType: powerType},
            cache:false,
            success:function(result){
                $("#groupTask").html(result);
                mytask.init();
            },
            error:function(){
                $("#groupTask").html("获取任务列表失败！");
            }
        });
        addMember();
    }

    //任务tab中，按任务或者人员显示列表
    $(".group-task-tab-nav a").on("click",function(){
        var $this = $(this);
        var index = $this.index();
        $this.removeClass("km-btn-info").siblings().addClass("km-btn-info");
        $(".group-task-tab-items > div").eq(index).show().siblings().hide();
    });

    //查看任务进度
    $("#personnelList").on("mouseover",".schedule",function(){
        var _this = $(this);
        var taskId = _this.data("task-id");
        if(!_this.hasClass("isReq")){
            $.get(constant.ROOT_PATH + 'task/replys/' + taskId, {order: 'desc'}, function(result) {
                _this.addClass("isReq").find(".schedule-bubble").find(".schedule-bubble-cont").html(result);
            });
        }
//        _this.find(".schedule-bubble").show();
    });

    //人员分页方法
    function personnelPageing(page){
        var spinner;
        $.ajax({
            url:constant.ROOT_PATH + 'group/'+groupId+'/groupInfos/3?'+new Date().getTime(),
            type:"GET",
            data:{limit:10,page:page},
            beforeSend:function(){
                spinner = new Spinner().spin(document.getElementById("personnelList"));
            },
            success:function(result) {
                $("#personnelList").html(result);
            },
            error:function(){
                tip.open("请求失败", 1000);
            },
            complete:function(){
                spinner.stop();
            }
        });
    }

    //人员分页（群组任务）
    var personnelPage = 1;
    $("#personnelPaging").on("click","a",function(){
        var _this = $(this);
        var pageCount = $("#personnelPaging span.max").text();
        if(!!_this.hasClass("btn-disabled")){
            return;
        }
        if(!!_this.siblings("a").hasClass("btn-disabled")){
            _this.siblings("a").removeClass("btn-disabled");
        }
        //上一页
        if(_this.hasClass("prev-btn")){
            personnelPage --;
            if(personnelPage <= 1){
                personnelPage = 1;
                _this.addClass("btn-disabled");
            }
            $("#personnelPaging span.cur").text(personnelPage);
            personnelPageing(personnelPage);
        }
        //下一页
        if(_this.hasClass("next-btn")){
            personnelPage ++;
            if(personnelPage >= pageCount){
                personnelPage = pageCount;
                _this.addClass("btn-disabled");
            }
            $("#personnelPaging span.cur").text(personnelPage);
            personnelPageing(personnelPage);
        }
    });

    //群组话题列表、成员列表各事件绑定（删除话题、取消管理员、设为管理员、踢出成员）
    $("#group-tabs-container").on("click","a",function(event){
        //event.preventDefault();
        var _this = $(this);
        if(_this.hasClass("del-topic")){
            var topicid = _this.parents("tr").attr("data-id");
            var topicName = _this.parents("tr").data("topicname");
            Confirmbox.confirm("确认要删除话题 <span class='text-color-em'>"+xss(topicName)+"</span> 吗？", '删除话题',function(){
                delTopic(topicid,_this);
            },{
                width: 300,
                closeTpl: '×'
            });
        }
        if(_this.hasClass("setRole-cancel")){
            var userId = _this.parents("tr").attr("data-id");
            var userName = _this.parents("tr").data("username");
            Confirmbox.confirm("确认要取消 <span class='text-color-em'>"+userName+"</span> 的管理员资格吗？", '取消管理员',function(){
                setRole_cancel(userId,_this);
            },{
                width: 300,
                closeTpl: '×'
            });
        }
        if(_this.hasClass("setRole-set")){
            var userId = _this.parents("tr").attr("data-id");
            var userName = _this.parents("tr").data("username");
            Confirmbox.confirm("确认将 <span class='text-color-em'>"+userName+"</span> 设为管理员？", '设为管理员',function(){
                setRole_set(userId,_this);
            },{
                width: 300,
                closeTpl: '×'
            });
        }
        if(_this.hasClass("del-member")){
            var userId = _this.parents("tr").attr("data-id");
            var userName = _this.parents("tr").data("username");
            Confirmbox.confirm("确认将 <span class='text-color-em'>"+userName+"</span> 踢出该群？", '踢出成员',function(){
                delMember(userId,_this);
            },{
                width: 300,
                closeTpl: '×'
            });
        }
    });

    //话题、成员、敏捷开发列表分页
    function detail_pagingInit(){
        var limitCount = [20,10,20]; //话题列表每页20条，成员每页10条，敏捷团队每页10条
        $('.ui-paging').each(function(i, obj) {
            i = $(this).siblings(".dataList").data("pagetype"); // 1：话题，2：群成员，3：敏捷开发
            new Paging({
                element: obj,
                url: constant.ROOT_PATH + 'group/'+groupId+'/groupInfos/'+i+'?'+new Date().getTime(),
                params: {limit: limitCount[i-1],powerType:powerType},
                targetId: 'group-tabs-container',
                cb: function(data) {
                    if(i == 3){
                        $("#personnelList").html(data);
                    }else{
                        $("#listTable"+i+" tbody").html(data);
                    }
                }
            })
        });
    }

    //删除话题
    function delTopic(topicId,_self){
        $.ajax({
            url:constant.ROOT_PATH + 'group/delTopic',
            type:"post",
            processData:false,
            contentType:"application/json",
            data: JSON.stringify({topicid:topicId}),
            success:function(result) {
                if(result.success) {
                    tip.open("删除成功", 700);
                    _self.parents("tr").remove();
                } else {
                    tip.open("删除失败", 700);
                }
            },
            error:function(){
                tip.open("请求失败", 700);
            }
        })
    }

    //添加群成员
    function addMember(){
        var hasCurUser = false;
        var noUser = false;
        input_invite.initButton("addMemberBtn",{title:"添加成员"},function(result){
            var curUserId = $("#addMemberBtn").data("cur-userid");
            var data = [];
            $.each(result,function(i,obj){
                var userid = parseInt(obj.id);
                if(userid == parseInt(curUserId)){
                    hasCurUser = true;
                }
                data.push({"userId": userid});
            });
            if(data.length == 0){
                tip.open("请选择人员添加到选中名单中！",1000);
                noUser = true;
                return;
            }else{
                noUser = false;
            }
            if(hasCurUser){
                tip.open("不能添加自己哦！",1000);
            }else{
                groupMember.addMember(groupId,data,function(rs){
                    if(rs.success) {
                        tip.open("添加成功", 700);
                        $.post(constant.ROOT_PATH +'group/memberInfo',{data:rs.data,powerType:powerType,group_id:groupId},function(rsHtml){
                            $("#listTable2 tbody").append(rsHtml);
                        });
                    } else {
                        tip.open("添加失败", 700);
                    }
                });
            }
        },function(){
            if(hasCurUser){
                hasCurUser = false;
                return false;
            }else if(noUser){
                noUser = false;
                return false;
            }
        });
    }

    //踢出群成员
    function delMember(userId,_self){
        groupMember.deleteMember(groupId,userId,function(rs){
            if(rs.success) {
                tip.open("踢出成功", 700);
                _self.parents("tr").remove();
            } else {
                tip.open("踢出失败", 700);
            }
        });
    }

    //授权为管理员
    function setRole_set(userId,_self){
        groupMember.setUserRole(groupId,userId,1,function(rs){  //0：普通成员，1：管理员
            if(rs.success) {
                tip.open("设置成功", 700);
                _self.text("取消管理员").removeClass("setRole-set").addClass("setRole-cancel");
            } else {
                tip.open("设置失败", 700);
            }
        });
    }

    //取消管理员
    function setRole_cancel(userId,_self){
        groupMember.setUserRole(groupId,userId,0,function(rs){  //0：普通成员，1：管理员
            if(rs.success) {
                tip.open("取消管理员成功", 700);
                _self.text("授权为管理员").removeClass("setRole-cancle").addClass("setRole-set");
            } else {
                tip.open("取消管理员失败", 700);
            }
        });
    }

    //重新加载话题列表
    function topic_reload(){
        $.get(constant.ROOT_PATH + "group/"+groupId+"/groupInfos/1",{limit:10,page:1,powerType:powerType},function(result){
            $("#listTable1 tbody").html(result);
        });
    }

    //重新加载成员列表
    function member_reload(){
        var page = 1;
        $("#group-memberListBox .ui-paging a").each(function(){
            if($(this).hasClass("ui-paging-current")){
                page = $(this).text();
            }
        });
        $.get(constant.ROOT_PATH + "group/"+groupId+"/groupInfos/2",{limit:10,page:page,powerType:powerType},function(result){
            $("#listTable2 tbody").html(result);
        });
    }
})