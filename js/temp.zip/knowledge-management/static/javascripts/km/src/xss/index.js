define(function (require, exports, module) {
    /**
     * 模块入口
     *
     * @author 老雷<leizongmin@gmail.com>
     */

    var DEFAULT = require('./default');
    var parser = require('./parser');
    var FilterXSS = require('./xss');


    /**
     * XSS过滤
     *
     * @param {String} html 要过滤的HTML代码
     * @param {Object} options 选项：whiteList, onTag, onTagAttr, onIgnoreTag, onIgnoreTagAttr, safeAttrValue, escapeHtml
     * @return {String}
     */
    function filterXSS(html, options) {
        var xss = new FilterXSS(options);
        return xss.process(html);
    }


// 输出
    exports = module.exports = filterXSS;
    exports.FilterXSS = FilterXSS;
    for (var i in DEFAULT) exports[i] = DEFAULT[i];
    for (var i in parser) exports[i] = parser[i];

})