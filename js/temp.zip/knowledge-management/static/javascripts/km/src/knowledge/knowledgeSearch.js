/**
 * Created by peng.xie on 14-4-4.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Tabs = require('tabs');
    var Paging = require('../common/paging');

    new Tabs({
        element: "#J-search-bd",
        triggers: '#J-search-bd .km-tab-v1-nav li',
        panels: '#J-search-bd .km-tab-v1-switch',
        activeTriggerClass: 'cur'
    });

    var data = decodeURI(window.location.search).substring(1).toJsonObj();

    $('.ui-paging').each(function (i, obj) {
        new Paging({
            element: obj,
            url: constant.ROOT_PATH + 'knowledge/search',
            params: {keyword: data.keyword, type: "paging"},
            targetId: 'km-tab-v1-main',
            cb: function (data) {
                $(".km-tab-v1-switch").eq(i).find(".search-list-wrap").html(data);
            }
        })
    });
});
