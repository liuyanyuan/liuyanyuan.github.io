/**
 * Created by peng.xie on 14-3-3.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var Paging = require('../common/paging');
    var constant = require('../constant');
    /*绑定下拉按钮事件*/
    $(".marketStrategy_opts .dropDown").on("click", function(){
        var isDown = $(".dropDown-list").hasClass("fn-hide");
        if(isDown){
            $(".dropDown-list").fadeIn();
            $(".dropDown-list").removeClass("fn-hide");
            $(this).find("#down").addClass("fn-hide");
            $(this).find("#up").removeClass("fn-hide");
        }
        else{
            $(".dropDown-list").fadeOut();
            $(".dropDown-list").addClass("fn-hide");
            $(this).find("#down").removeClass("fn-hide");
            $(this).find("#up").addClass("fn-hide");
        }
    });
    /*绑定分页控件事件*/
    new Paging({
        element: $('.ui-paging'),
        url: constant.ROOT_PATH + 'knowledge/knowledgeByPage',
        params: {type: 1},
        targetId: 'main-body',
        cb: function(data) {
            $("#main-body").html(data);
        }
    })
});