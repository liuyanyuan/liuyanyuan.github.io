/**
 * Created by peng.xie on 14-3-10.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var Tip = require('../common/tip');
    var knowledgeLibrary = require('../common/knowledge-library');
    var Confirmbox = require('confirmbox');
    var sceneType = window.location.pathname.indexOf('knowledge/gameGuide') > 0 ? 3 :2;  //2为知识库，3为游戏玩法库
    var constant = require('../constant');
    var uploadAvatar = require('../personal/upload-avatar');

    knowledgeLibrary.initUpdate();
//    if($('#knowledge-attachment-trigger').length > 0 ) {
//        knowledgeLibrary.initAttachment();
//    }

    //更新文档按钮事件绑定
    $('#knowledgeSubmit').on('click', function(event) {
        event.preventDefault();
        var self = $(this);
        knowledgeLibrary.updateKnowledge({}, self.data('id'), function(reulst) {
            if(reulst.success) {
                Tip.open('修改知识点成功', 1000);
                setTimeout(function(){
                    window.location.href = "/personal";
                },1000)
            } else {
                Tip.open(reulst.message, 1000);
            }
        })
    });

    //上传玩法库图片
    function uploadGameGuideImg(){
        $.post(constant.ROOT_PATH + 'group/uploadAvatar', {type:2}, function(html) {
            Confirmbox.confirm(html, '上传玩法库文档图片',function() {
                uploadAvatar.submit();
            },{
                width: 600,
                closeTpl: '×'
            });
            uploadAvatar.init({
                url: constant.ROOT_PATH + 'group/setAvatar',
                trigger: '.upload-avatar-btn',
                callback: function(result) {
                    $('#gameGuideImg').attr('src', '/files/show/' + result.data).attr("data-imgid",result.data);
                }
            });
        });
    }
    if( sceneType == 3 ){
        /**
         * 上传知识库图片
         */
        $("#main-new").on("click", "#imgUploadBtn", function () {
            uploadGameGuideImg();
            return false;
        });
        /**
         * 玩法库选中分类
         */
        $("#main-new ").on("click", ".ul-game-category li",function(){
            $(this).find('a').toggleClass('selected');
            return false;
        });
    }

});
