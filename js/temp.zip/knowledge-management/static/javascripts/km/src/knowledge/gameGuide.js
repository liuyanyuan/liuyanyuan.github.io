/**
 * Created by hai.zhang on 14-05-21.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var tip = require('../common/tip');
    var Paging = require('../common/paging');
    var Tabs = require('tabs');

    /**
     * 玩法库分类导航
     */
    //分类、标签着色
    var targetId = window.location.search.substring(window.location.search.lastIndexOf('=')+1);
    var childIndex = $(".km-tab-v4-main div").index($('#'+targetId).parent().parent());
    $('#'+targetId).find('a').addClass('selected');
    //初始化分类tab插件
    var tabC1 = new Tabs({
        element: "#tabGuideCategory",
        triggers: '#tabGuideCategory .km-tab-v4-nav li',
        panels: '#tabGuideCategory .km-tab-v4-switch',
        activeTriggerClass: 'cur',
        activeIndex:childIndex == -1 ? 0: childIndex
    });

    /**
     * 玩法库分类单选
     */
    $(".ul-game-category").delegate("li","click",function(){
        var curLink = $(this).find('a');
        $(this.parentNode).find('li a').each(function(){
            if((curLink[0] === $(this)[0])){
                $(this).toggleClass('selected');
            }else{
                $(this).removeClass('selected');
            };
        });
        reloadDocList();
    });
    /**
     * 玩法库排序单选
     */
    $(".order-category").delegate("a", "click", function(){
        $(this.parentNode).find('a').each(function(){
            $(this).removeClass('cur');
        });
        $(this).addClass('cur');
        //alert(getSearchConditions());
        reloadDocList();
    });
    //玩法库分页
    function initialPaging(){

        $('.ui-paging').each(function(i, obj) {
            new Paging({
                element: obj,
                url: constant.ROOT_PATH + 'knowledge/gameGuide/docList',
                params: getSearchConditions(),
                targetId: 'topic-detail-content',
                cb: function(data) {
                    $("#guideListContent").html(data);
                }
            })
        });

    }
    initialPaging();
    //获取查询参数
    function getSearchConditions( pageIndex ){

        var guideCategory = null;
        var page = typeof pageIndex != 'undefined' ? pageIndex : parseInt($('.ui-paging .ui-paging-current').text()) + 1;
        var jsonStr = '"type":"30","limit":"12","page":"1"';
        //玩法库分类
       $('#tabGuideCategory .ui-switchable-content div').each(function(){
            if( $(this).css('display') == 'block' ){
                guideCategory = $(this).find('ul.ul-game-category li a.selected');
                if( guideCategory.length > 0 && guideCategory.text() != '不限' ){
                    jsonStr = jsonStr+','+'"catagoryId":"'+guideCategory.parent().attr('id')+'"';
                }else{
                    jsonStr = jsonStr+','+'"catagoryId":""';
                }
            }
        });
        //玩法库角度
        $('[aspect="true"].ul-game-category').each(function(){
            jsonStr =  jsonStr + ',"'+$(this).attr('id')+'":"'+ ($(this).find('li a.selected').parent().length>0 ? $(this).find('li a.selected').parent().attr('id'):'')+'"';
        });
        //玩法库排序
        jsonStr = '{'+jsonStr + ',"order":"'+$(".order-category a.cur").attr('id')+'"}';

        return JSON.parse(jsonStr);

    }

    //根据查询条件加载列表
    function reloadDocList(){

        var queryStr = decodeURIComponent($.param(getSearchConditions())) + '&search=y';
        $.ajax({
            type: 'get',
            url: constant.ROOT_PATH + 'knowledge/gameGuide/docList?'+queryStr ,
            cache: false
        }).done(function (result) {
                $("#gameGuideList").html(result);
                initialPaging();
            });
    }

});
