/**
 * Created by peng.xie on 14-3-4.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Spinner = require("spin");
    var Tip = require('../common/tip');
    var star = require('../common/star-score');
    var Share = require('../common/share');
    var Turntask = require('../common/turn-task');
    var xss=require('../xss/index');
    var ImgFullSizeView = require('../common/img-fullSizeView');

    ImgFullSizeView.imgFullSizeView(".main-content-text");
    star = new star();
    var o = {
        "1": "很差",
        "2": "较差",
        "3": "还行",
        "4": "推荐",
        "5": "力荐"
    }
    /* 绑定评分按钮事件 */
    star.init("km-star-score", {
        "click": function (v) {
            var knowledgeId = $("#km-star-score").data("id");
            var spinner = new Spinner().spin(document.getElementById("km-star-score"));
            $.post(constant.ROOT_PATH + 'knowledge/reply', {type: 1, knowledgeId: knowledgeId, score: v}).done(function (result) {
                if (result.data) {
                    $(".num .count").html(result.data.userCount);
                    $(".num .score").html(result.data.avg);
                }
                else {
                    Tip.open(result.message, 1000);
                }
            }).always(function () {
                    spinner.stop();
                });
        },
        "mousemove": function (v) {
            $("#appraise-type").html(o[v]);
        },
        "mouseout": function (v) {
            $("#appraise-type").html("");
        }
    });
    /*绑定相关知识推荐按钮事件*/
    $(".box-head-control").on("click", ".km-page-v3 > a", function () {
        if (!$(this).hasClass("btn-disabled")) {
            $(this).addClass("btn-disabled");
            if ($(this).hasClass("prev-btn")) {
                $(".num > .cur").addClass("select");
                $(".num > .max").removeClass("select");
                $(".km-page-v3 > .next-btn").removeClass("btn-disabled");
                $("#tap-two").hide();
                $("#tap-one").fadeIn();
            } else if ($(this).hasClass("next-btn")) {
                $(".num > .cur").removeClass("select");
                $(".num > .max").addClass("select");
                $(".km-page-v3 > .prev-btn").removeClass("btn-disabled");
                $("#tap-one").hide();
                $("#tap-two").fadeIn();
            }
        }
    });
    /* 绑定回复按钮弹出事件 */
    $("#replyListBox").on("click", ".openReviewBox", function () {
        var box = $(this).closest(".replyList").find(".toReviewBox");
        if (box.hasClass("fn-hide")) {
            box.fadeIn();
            box.removeClass("fn-hide");
        }
        else {
            box.hide();
            box.addClass("fn-hide");
        }
    });
    /* 绑定印象评价按钮事件 */
    var spinner2;
    $("#addAppraise").on("click", function () {
        if (spinner2 && spinner2.el) return;//如果存在菊花则不执行返回
        var appraise = $("#appraise").val();
        if (appraise == "" || $.trim(appraise) == "") {
            Tip.open("请输入知识点印象！", 1000);
            return;
        }
        var knowledgeId = $(this).data("id");
        spinner2 = new Spinner().spin(document.getElementById("addAppraise"));
        $.post(constant.ROOT_PATH + 'knowledge/reply', {type: 2, knowledgeId: knowledgeId, description: appraise}).done(function (result) {
            if (result.data) {
                $("#appraise-list").append('<button class="km-btn km-btn-info new" data-id="' + result.data.id + '" data-knowledgeid="' + result.data.knowledgeId + '">' + xss(result.data.description) + '(<span>' + result.data.effectApplaud + '</span>)</button>');
            }
            else {
                Tip.open(result.message, 1000);
            }
        }).always(function () {
                spinner2.stop();
                $("#appraise").val("");
            });
    });
    /*绑定印象加一按钮事件*/
    $("#appraise-list").on("click", "button", function () {
        if (spinner2 && spinner2.el) return;//如果存在菊花则不执行返回
        var self = $(this);
        var id = self.data("id");
        var knowledgeId = $(this).data("knowledgeid");
        spinner2 = new Spinner().spin(document.getElementById("addAppraise"));
        $.post(constant.ROOT_PATH + 'knowledge/reply', {type: 0, id: id, knowledgeId: knowledgeId}).done(function (result) {
            if (result.message) {
                Tip.open(result.message, 1000);
            } else {
                var num = self.find("span").html();
                num = parseInt(num) + 1;
                self.find("span").html(num);
                if (!self.hasClass("more")) {
                    self.removeClass("zero").removeClass("new").addClass("more");
                }
            }
        }).always(function () {
                spinner2.stop();
            });
    })
    /* 绑定提交评论按钮事件 */
    var spinner3;
    $("#topReview").on("click", ".review-button", function () {
        var self = $(this);
        if (spinner3 && spinner3.el) return;//如果存在菊花则不执行返回
        var content = self.closest(".toReviewBox").children(".box-review").html();
        if (content.replace(/<(S*?)[^>]*>.*?|<.*?\/>|\s|(&nbsp;)|(char) 12288/g, '') === '') {
            Tip.open("请输入知识点评论！", 1000);
            return;
        }
        var data = {
            type: 3,
            knowledgeId: $(this).data("id"),
            content: content
        }
        spinner3 = new Spinner().spin(document.getElementById("main-review"));
        $.post(constant.ROOT_PATH + 'knowledge/reply', data).done(function (result) {
            $("#replyListBox").prepend(result);
            self.closest(".toReviewBox").children(".box-review").html("");
        }).always(function () {
                spinner3.stop();
            });
    });
    $("#replyListBox").on("click", ".review-button", function () {
        var self = $(this);
        if (spinner3 && spinner3.el) return;//如果存在菊花则不执行返回
        var content = self.closest(".toReviewBox").children(".box-review").html();
        if (content.replace(/<(S*?)[^>]*>.*?|<.*?\/>|\s|(&nbsp;)|(char) 12288/g, '') === '') {
            Tip.open("请输入知识点评论！", 1000);
            return;
        }
        var data = {
            type: 3,
            knowledgeId: $(this).data("id"),
            content: content,
            parentId: $(this).data("parentid"),
            parentUserId: $(this).data("userid"),
            parentUserName: $(this).data("username")
        }
        spinner3 = new Spinner().spin(document.getElementById("main-review"));
        $.post(constant.ROOT_PATH + 'knowledge/reply', data).done(function (result) {
            $("#replyListBox").prepend(result);
            self.closest(".toReviewBox").children(".box-review").html("");
            var box = self.closest(".replyList").find(".toReviewBox");
            box.hide();
            box.addClass("fn-hide");
        }).always(function () {
                spinner3.stop();
            });
    });
    /* 绑定查看更多评论按钮 */
    var spinner4;
    $("#loadMoreReview a").on("click", function () {
        if (spinner4 && spinner4.el) return;//如果存在菊花则不执行返回
        var self = $(this);
        var knowledgeId = self.data("id");
        var replyCount = self.data("count");
        var page = self.data("page");
        var limit = self.data("limit");
        spinner4 = new Spinner().spin(document.getElementById("loadMoreReview"));
        $.get(constant.ROOT_PATH + 'knowledge/getMoreReply', {id: knowledgeId, page: page + 1, limit: limit}).done(function (result) {
            $("#replyListBox").append(result);
            if (replyCount <= (page + 1) * limit) {
                $("#loadMoreReview").remove();
            } else {
                self.data("page", page + 1);
            }
        }).always(function () {
                spinner4.stop();
            });
    });
    /*绑定分享按钮事件*/
    $("#share").on("click", function () {
        Share.share({ id: $(this).data("id"), type: 1, title: $(this).data("title")});
    });
    /*绑定转为任务按钮事件*/
    $("#turnTask").on("click", function () {
        Turntask.turnTask(
            {
                tasktype: 1,
                title: $(this).data("title"),
                refId: $(this).data("id"),
                refType: 1,
                cb: function (result) {
                    if (result.success) {
                        Tip.open('转为任务成功', 700);
                    } else {
                        Tip.open('转为任务失败，请重试', 700);
                    }
                }
            }
        );
    });
    /*绑定收藏按钮事件*/
    $("#collect").on("click", function () {

    });

    /*评论太长时，绑定弹出和隐藏按钮事件*/
    $("#replyListBox").on("click", ".review-info .show-origin", function (event) {
        event.preventDefault();
        $(this).closest('.km-trend-abstruct').hide();
        $(this).closest('.right').find('.km-trend-origin').show();
    });
    $("#replyListBox").on("click", ".review-info .show-abstruct", function (event) {
        event.preventDefault();
        $(this).closest('.km-trend-origin').hide();
        $(this).closest('.right').find('.km-trend-abstruct').show();
    });

    /*绑定知识点编辑按钮事件*/
    $(".main-options #update").on("click", function () {
        var knowledgeId = $(this).data("id");
        var type = $(this).data("type");
        var docType = $(this).data("doctype");
        if( docType == '30'){
            window.location.href = "/knowledge/gameGuide/update/" + type + "/" +  docType + "/" +knowledgeId;
        }else{
            window.location.href = "/knowledge/update/" + type + "/" +  +knowledgeId;
        }

    });
});
