/**
 * Created by peng.xie on 14-1-7.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');

    var navtree = require("../common/navtree");
    navtree.clickHandle(function (id) {
        window.location.href = "/knowledge/classifiedData#navtreeid=" + id;
    })

    var Tabs = require('tabs');
    var Spinner = require("spin");
    /*排行榜切换*/
    $('.rankingList-box').on('mouseover', '.rankingList', function () {
        $(this).parent().find('.selected').removeClass('selected');
        $(this).addClass('selected');
    });
    $('.rankingList-box').each(function () {
        $(this).find('.rankingList:first').addClass('selected');
    });

    new Tabs({
        classPrefix: 'knowledgeTree',
        element: '#knowledgeTree',
        triggers: '#knowledgeTree-title li',
        panels: '#knowledgeTree-body .hidden',
        activeIndex: 0,
        effect: 'fade',
        activeTriggerClass: 'knowledgeTree-li-active'
    });

    //分页按需加载最新知识树数据
    $("#knowledgeTree-title").on("mouseover", ".knowledgeTree-li-active", function () {
        var level = $(this).data("level");
        var ul = $("#ul-" + level);
        //若尚未加载该tab分页的html片段，则请求数据
        if ($.trim(ul.html()).length == 0) {
            var spinner = new Spinner().spin(document.getElementById("ul-" + level));
            $.get(constant.ROOT_PATH + 'knowledge/newKnowledgeList', {level: level, page: 1, type: "tree_li"}).done(function (result) {
                ul.html(result);
            }).always(function () {
                    spinner.stop();
                });
        }
    })
});