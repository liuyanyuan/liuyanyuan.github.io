/**
 * Created by peng.xie on 14-3-8.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var knowledgeLibrary = require('../common/knowledge-library');
    var Confirmbox = require('confirmbox');
    var Tip = require('../common/tip');

    //初始化页面控件
    knowledgeLibrary.initUpdate();

    $('#knowledgeSubmit').on('click', function(event) { //新增知识点
        event.preventDefault();
                knowledgeLibrary.addKnowledge({type: 13, knowledgeType: 2 , catalogId: 0}, function(reulst) {
                    if(reulst.success) {
                        Confirmbox.confirm(reulst.html, '', null, {
                            cancelTpl: '',
                            confirmTpl: '',
                            closeTpl: '×',
                            title: '',
                            beforeHide: function() {
                                window.location.href = '/personal';
                            }
                        })
                        $(window).off("beforeunload")
                    } else {
                        Tip.open(reulst.html, 700);
                    }
                })

    })

    $(window).on("beforeunload",function(e){
//            e = e || window.event;
        var form = $('#uploadKnowledgeForm');
        var data = form.serializeObject();
        if(data.author!=""||data.catagoryId!=""||data.content!=""||data.description!=""||data.keyword!=""||data.source!=""||data.title!=""){
            if (e) {
                e.returnValue = "还有未保存的文章1篇！";
            }
            return "还有未保存的文章1篇！";
        }
    })
});
