/**
 * Created by peng.xie on 14-3-7.
 */
define(function (require, exports, module) {
    var $ = require('$');
    var Tip = require('../common/tip');
    var knowledgeLibrary = require('../common/knowledge-library');
    var Confirmbox = require('confirmbox');
    var sceneType = window.location.pathname == '/knowledge/gameGuide/upload' ?3 :2;  //2为知识库，3为游戏玩法库
    var constant = require('../constant');
    var uploadAvatar = require('../personal/upload-avatar');


//        $(window).on("beforeunload",function(e){
////            e = e || window.event;
//            if (e) {
//                e.returnValue = "还有未保存的文档1篇！";
//            }
//            return "还有未保存的文档1篇！";
//        })
//
//        $(window).off("beforeunload");
//        window.location.href = "/knowledge/upload";
    //上传文件
    knowledgeLibrary.initUpload({
        params: {type: sceneType, upload_url: sceneType == 3 ? 'knowledge/gameGuide/add/' : '', trigger: "uploadKnowledge"},
        callback: function (result) {
            $("#main-info").html(result);
            $("#main-upload").hide();
            $(window).focus();

            $(window).on("beforeunload", function (e) {
//            e = e || window.event;
                if ($("#main-info").html() != "" && $.trim($("#main-info").html()) != "") {
                    if (e) {
                        e.returnValue = "还有未保存的文档1篇！";
                    }
                    return "还有未保存的文档1篇！";
                }
            })
            knowledgeLibrary.initUpdate();

            $('#knowledgeSubmit').on('click', function (event) { //新增知识点
                event.preventDefault();
                knowledgeLibrary.addKnowledge({type: sceneType == 3 ? 30 : 13, knowledgeType: 1, catalogId: 0}, function (reulst) {
                    console.log(reulst);
                    if (reulst.success) {
                        Confirmbox.confirm(reulst.html, '', null, {
                            cancelTpl: '',
                            confirmTpl: '',
                            closeTpl: '×',
                            title: '',
                            beforeHide: function () {
                                window.location.href = '/personal';
                            }
                        })
                        $(window).off('beforeunload');
//                        Tip.open('新增知识点成功');
                    } else {
                        Tip.open(reulst.html, 700);
                    }
                })

//                $(window).off("beforeunload");
//                window.location.href = "/knowledge/upload";
            })
        }
    });
    $("#main-info").on("click", ".upload-knowledge-again .km-btn", function () {
        $("#main-info").html("");
        $("#main-upload").fadeIn();
    });

    //上传玩法库图片
    function uploadGameGuideImg(){
        $.post(constant.ROOT_PATH + 'group/uploadAvatar', {type:2}, function(html) {
            Confirmbox.confirm(html, '上传玩法库文档图片',function() {
                uploadAvatar.submit();
            },{
                width: 600,
                closeTpl: '×'
            });
            uploadAvatar.init({
                url: constant.ROOT_PATH + 'group/setAvatar',
                trigger: '.upload-avatar-btn',
                callback: function(result) {
                    $('#gameGuideImg').attr('src', '/files/show/' + result.data).attr("data-imgid",result.data);
                }
            });
        });
    }

    if( sceneType == 3 ){
        /**
         * 上传知识库图片
         */
        $("#main-info").on("click", "#imgUploadBtn", function () {
            uploadGameGuideImg();
            return false;
        });
        /**
         * 玩法库选中分类
         */
        $("#main-info ").on("click", ".ul-game-category li",function(){
            $(this).find('a').toggleClass('selected');
            return false;
        });
    }
});
