define(function(require, exports, module) {

    var $ = require('$');
    var constant = require('../constant');
    require('select2');
    var Confirmbox = require('confirmbox');
    var input_invite = require('../common/input_invite');
    var Validator = require('validator');
    var Paging = require('../common/paging');
    var Select = require('select');
    var Turntask = require('../common/turn-task');
    var Tip = require('../common/tip');
    var xss = require('../xss/index');
    var Spinner = require('spin');
    var spinner;

    var pageType;
    var powerType = $("body").attr("data-powerType");








    var getTask = function(status) {
        if(spinner && spinner.el) return;//如果存在菊花则不执行返回
        spinner = new Spinner().spin($('#task-wrapper').get(0));

        var groupId = $('body').data('groupid');




        var taskUrl;

        switch(pageType) {
            case 2:
                taskUrl = constant.ROOT_PATH + 'task/group/' + groupId + '/status/' + status;
                break;
            case 1:
                taskUrl = constant.ROOT_PATH + 'task/personal/status/' + status;
                break;
            default :
                taskUrl = constant.ROOT_PATH + 'task/personal/status/' + status;
                break;
        }

        $.ajax({
            type: 'GET',
            url: taskUrl,
            data: {powerType: powerType},
            cache: false
        }).done(
            function (result) {
                $('#task-gather').empty().append(result);
                var $paging = $('#taskBox').find('.ui-paging');
                if($paging.length) {
                    new Paging({
                        element: $paging,
                        url: taskUrl,
                        targetId: 'taskBox',
                        cb: function (data) {
                            $('#task-list').empty().append(data);
                            $('#task-wrapper .task-item:odd').addClass('task-item-gray');
                        }
                    })
                }
                var $nav = $('#taskBox').find('[data-task-type="' + status +'"]');

                $nav.addClass('task-nav-current').siblings().removeClass('task-nav-current');
                $('#task-wrapper .task-item:odd').addClass('task-item-gray');
            }
        ).always(function () {
                spinner.stop();
            })

    }



    exports.get = function(cb) {
        $.ajax({
            type: 'GET',
            url: constant.ROOT_PATH + 'task/personal/home',
            cache: false
        }).done(function (result) {
            cb(result);
            init();
        });
    }

    exports.init = init;

    function init() {


        //分页插件初始化

        pageType = $('#taskBox').data('page-type');

        var sourceType = $('.add-task-btn').data('source-type');
        var groupId = $('body').data('groupid');
        var taskUrl;
        if(sourceType == 2) {
            taskUrl = constant.ROOT_PATH + 'task/group/' + groupId + '/status/1';
        } else {
            taskUrl = constant.ROOT_PATH + 'task/personal/status/1';
        }
        var $paging = $('#taskBox').find('.ui-paging');
        if($paging.length) {
            new Paging({
                element: $paging,
                url: taskUrl,
                targetId: 'taskBox',
                cb: function (data) {
                    $('#task-list').empty().append(data);
                    $('#task-wrapper .task-item:odd').addClass('task-item-gray');
                }
            });
        }

        $('#task-wrapper .task-item:odd').addClass('task-item-gray');


//        //分页插件
//        $('.ui-paging').each(function(i, obj) {
//            new Paging({
//                element: obj,
//                url: constant.ROOT_PATH + 'users/task/' + (i + 1) + '/page',
//                params: {limit: 15},
//                targetId: 'qaBox',
//                cb: function(data) {
//                    $('[data-panel-value=' + (i + 1) + ']').find('.task-list').html(data);
//                }
//            })
//        });
        //新增任务
        $('.add-task-btn').on('click', function(event) {
            event.preventDefault();
            var $self = $(this);
            Turntask.turnTask({
                tasktype: 0,
                sourceType: $self.data('source-type'),    //任务来源 1个人2群组
                sourceId: $self.data('source-id'),
                sourceName: $self.data('source-name'),
                cb: function(result) {
                    if(result.success) {
//                        console.log(result.data);
                        Tip.open('新增任务成功', 700);
                        //新增成功后实时刷新任务列表

                            getTask(1);


                    } else {
                        Tip.open('新增任务失败，请重试', 700);
                    }
                }
            });

        });

        //任务类型选择
//        if($('#taskSelect').length > 0) {
//            var select = new Select({
//                trigger: '#taskSelect',
//                triggerTpl: '<a href="#"><span data-role="trigger-content"></span><i class="iconfont">&#x35d7;</i></a>',
//                classPrefix: 'task-select',
//                width: 75
//            }).on('change', function(target) {
//                    var status = target.data('value');
//                    $('#searchInp').data('status', status);
////                $('[data-panel-value=' + status + ']').show().siblings().hide();
//                    getTask(status);
//
//                }).render();
//        }



        //群组任务
        $('.task-nav').on('click', 'a', function(event) {
            var $self = $(this),
                taskType = $self.data('task-type');
//            $self.addClass('task-nav-current').siblings().removeClass('task-nav-current');
            $('#searchInp').data('status', taskType);
            getTask(taskType);


        });

//        getTask(1);

        //任务列表显示初始化


        $('.task-search-trigger').on('click', function(event) {
            event.preventDefault();
            var ele = $(this);
            searchTask(ele);
        });
        $('.task-search-inp').on('keyup', function(event) {
            var ele = $(this);
            if(event.keyCode == 13) {
                searchTask(ele);
            }
        });

        //提交回复回车触发
        $('.task-gather').on('keyup', '.reply-input', function(event) {
            var ele = $(this);
            var ele = $(this);
            if(event.keyCode == 13) {
                postReply(ele);
            }
        }).on('focusin', '.reply-input', function(event) {
                var ele = $(this);

                ele.closest('.task-item').find('.form-explain').hide();
            });




        $('.task-gather').on('click', 'a, button, .btn-priority', function(event) {
//            event.preventDefault();

            var ele = $(this),
                item = ele.closest('.task-item');


            if(ele.hasClass('btn-priority')) {  //优先级处理

                var $self = $(this),
                    taskId = $self.data('id'),
                    pageType = $self.data('page-type'),
                    priority;


                if($self.hasClass('btn-up-top') || $self.hasClass('btn-down-bottom')) {  //优先级复位
                    priority = 1;

                } else if($self.hasClass('btn-up-normal') || $self.hasClass('btn-up-bottom')) {   //优先级置顶
                    priority = 2;

                } else if($self.hasClass('btn-down-normal') || $self.hasClass('btn-down-top')) {    //优先级置底
                    priority = 0;

                }
                $.post(constant.ROOT_PATH + 'task/' + taskId + '/priority/' + priority , function(result) {
                    if(result.success) {


                            getTask(1);

                    }
                })


            } else if(ele.hasClass('task-item-title') || ele.hasClass('btn-task-audit')) {//点击任务信息弹出详情框
                item.toggleClass('task-item-open').siblings().removeClass('task-item-open');
                if(item.find('.task-reply-item').length <= 0) {
                    $.get(constant.ROOT_PATH + 'task/replys/' + ele.data('task-id'), {order: 'desc'}, function(result) {
                        item.find('.task-reply-list').html(result);
                    });
                }

            } else if(ele.hasClass('btn-task-claim')) {//认领任务

                var taskId = ele.data('id');
                $.post(constant.ROOT_PATH + 'task/' + taskId + '/claim', function(result) {
                    if(result.success) {
                        Tip.open('任务已认领', 700);
                        ele.replaceWith('<button class="km-btn km-btn-hot btn-task-start" data-id="' + taskId + '">开启</button>')
                    }
                })
            } else if(ele.hasClass('btn-task-start')) {//开启任务

                var taskId = ele.data('id');
                $.post(constant.ROOT_PATH + 'task/' + taskId + '/start', function(result) {
                    if(result.success) {
                        Tip.open('任务启动', 700);
                        ele.replaceWith('<button class="km-btn km-btn-success btn-task-finish" data-page-type="2" data-id="' + taskId + '">完成</button>')
                    }
                })
            } else if(ele.hasClass('btn-task-finish')) {//完成任务

                taskFinish(ele, item);

            } else if(ele.hasClass('task-proceed')) {//重启任务

                taskRestart(ele, item);

            } else if(ele.hasClass('task-allot')) {   //分配任务

                taskAllot(ele);

            } else if(ele.hasClass('task-check-pass') || ele.hasClass('task-check-reject')) {  //审核任务通过

                var taskId = ele.data('id'),
                    pageType = ele.data('page-type'),
                    check,
                    message;
                if(ele.hasClass('task-check-pass')) {
                    check = 2;
                    message = "任务已审核通过";
                } else {
                    check = 1;
                    message = "任务已审核拒绝";
                }
                $.post(constant.ROOT_PATH + 'task/' + taskId + '/check/' + check, function(result) {
                    if(result.success) {

                        Tip.open(message, 700);
                        item.remove();
                        $('.task-item:even').addClass('gray');
                        $('.task-item:odd').removeClass('gray');
                        var count = $('.task-msg-count').html();
                        if (count == '99+') {
                            return;
                        } else {
                            $('.task-msg-count').html(count - 1);
                        }
                    } else {
                        Tip.open('审核失败，请重试。');
                    }
                })

            } else if(ele.hasClass('qa-reply-trigger')) {//点击回复小图标

                var userId = ele.data('user-id'),
                    userName = ele.data('user-name'),
                    input = item.find('.reply-input');
                item.find('.replyee-box').show().find('.replyee-name').html(userName);
                input.data('user-id', userId).data('user-name', userName);

            } else if(ele.hasClass('replyee-del')) {//删除被回复人

                item.find('.reply-input').data('user-id', null).data('user-name', null);
                ele.closest('.replyee-box').hide();

            } else if(ele.hasClass('reply-btn')) {//提交回复

                postReply(ele);

            } else if(ele.hasClass("task-askFor")){//是否同意加入群组申请

                var join_val = parseInt(ele.data("val"));
                var userId = ele.data("userid");
                var groupId = ele.data("groupid");
                $.ajax({
                    url:'/group/askforjoin',
                    type:'post',
                    processData:false,
                    contentType:"application/json",
                    data:JSON.stringify({userId:userId,groupId:groupId,joinType:join_val}),//joinType 1：同意，2：不同意
                    success:function(result){
                        if(result.success){
                            Tip.open('您'+ele.text()+'了该申请！',700);
                            window.setTimeout(function(){taskFinish(ele,item);},700);
//                            item.remove();
                        }
                    },
                    error:function(){
                        Confirmbox.show('请求失败，请重试！');
                    }
                });

            } else if(ele.hasClass('task-del')) {//删除我发起的任务

                Confirmbox.confirm('确定删除？', '删除任务', function() {
                    $.post(constant.ROOT_PATH + 'task/' + ele.data('task-id') + '/delete', function(result) {
                        if(result.success) {
                            item.remove();
                            $('.task-item:even').addClass('gray');
                            $('.task-item:odd').removeClass('gray');
                            Tip.open('删除成功', 700);
                        } else {
                            Tip.open('删除失败, 请重试', 700);
                        }
                    });
                });
            } else if(ele.hasClass('task-edit')) {//编辑我的任务

                if(ele.hasClass('task-edit-unable')) {
                    Tip.open('改任务正在审核中，不能编辑。', 700)
                } else {
                    Turntask.turnTask(
                        {
                            tasktype: 2,
                            sourceType: ele.data('source-type'),
                            sourceId: ele.data('source-id'),
                            taskdata: ele.data('task'),
                            cb: function(result, data) {
                                if(result.success) {

                                    Tip.open('编辑任务完成', 700);
//
//                               //执行人
                                    var performers_a = '',
                                        performers_span = '';
                                    $.each(data.performers, function (i, performer) {
                                        var a = '<a href="/user/' + performer.userId + '/home">' + performer.userName + '</a>';
                                        var span = performer.userName + '&nbsp;';
                                        performers_a += a;
                                        performers_span += span;
                                    });
                                    //审核人
                                    var judgers = '';
                                    $.each(data.judgers, function(i, judger) {
                                        var a = '<a href="/user/' + judger.userId + '/home">' + judger.userName + '</a>';
                                        judgers += a;
                                    });

                                    item.find('.task-item-title').html(xss(data.title));
                                    item.find('.task-content').html(xss(data.content));
                                    item.find('.task-item-performers').html(xss(performers_span));
                                    item.find('.task-performers').html(xss(performers_a));
                                    item.find('.task-judgers').html(xss(judgers));
                                    item.find('.task-item-deadline').html(xss(data.deadline));
                                    item.find('.task-edit').data('task', data);
                                } else {
                                    Tip.open('编辑任务失败，请重试', 700);
                                }
                            }
                        });
                }


            }
        });

    }

    //分配任务
    function taskAllot(self) {
        var taskId = self.data('task-id'),
            sourceType = self.data('source-type'),
            sourceId = self.data('source-id'),
            item = self.closest('.task-item'),
            taskTitle = item.find('.task-item-title').attr('title'),
            taskMessage = item.find('.task-content').html();;

        $.get(constant.ROOT_PATH + 'task/allot', function(result) {
            var comfirmbox = new Confirmbox({
                title: '',
                message: result,
                width: 660,
                cancelTpl: '',
                confirmTpl: '',
                closeTpl: 'X'
            }).show().after("hide", function () {
                    input_invite.destroy();
                    comfirmbox.destroy();
                });


            setTimeout(function() {
                //选人组件
                if(sourceType == 2) {
                    input_invite.initSelect2('performersSelect2', '100%', {hasMask: false, url: '/group/' + sourceId + '/members/selectBox'});
                } else {
                    input_invite.initSelect2('performersSelect2', '100%', {hasMask: false});
                }


                var validator = new Validator({
                    element: '.task-allot-box form',
                    failSilently: true
                });
                validator.addItem({
                    element: '.turn-task-box [name="performers"]',
                    required: true,
                    errormessageRequired: '任务执行人不能为空'
                });


                $('.task-allot-commit').on('click', function (event) {
                    event.preventDefault();
                    var $self = $(this),
                        form = $self.closest('form'),
                        data = form.serializeObject(),
                        rest = {taskTitle: taskTitle, taskMessage: taskMessage};


                    validator.execute(function (err, results, element) {   //表单验证成功才提交数据
                        if (!err) {
                            data.performers = [];

                            $.each($('.task-allot-box [name="performers"]').select2('data'), function(i, item) {
                                data.performers.push({userId: item.id, userName: item.name + '|' + item.userName});
                            });


                            $.post(constant.ROOT_PATH + 'task/' + taskId + '/allot', {params: data, rest: rest}, function (result) {
                                if(result.success) {
                                    input_invite.destroy();
                                    comfirmbox.destroy();
                                        getTask(1);
                                }

                            })
                        }
                    })


                });

            }, 0);





        })

    }


    //完成任务
    function taskFinish(self, parent) {
        var taskId = self.data('id'),
            item = self.closest('.task-item'),
            taskTitle = item.find('.task-item-title').attr('title'),
            taskMessage = item.find('.task-content').html();
        $.post(constant.ROOT_PATH + 'task/' + taskId + '/finish', {taskTitle: taskTitle, taskMessage: taskMessage}, function(result) {
            if(result.success) {
                //群组页里面
                if(pageType == 2) {
                    Tip.open('任务已完成', 700);
                    self.remove();
                } else {  //个人页里面
                    Tip.open('任务已标记为完成，可到已处理中查看', 700);
                    parent.remove();
                    $('.task-item:even').addClass('gray');
                    $('.task-item:odd').removeClass('gray');
                    var count = $('.task-msg-count').html();
                    if(count == '99+') {
                        return;
                    } else if(count == '1') {
                        $('.task-msg-count').remove();
                    } else {
                        $('.task-msg-count').html(count - 1);
                    }
                }
            }
        });
    }


    //任务重启
    function taskRestart(self, parent) {
        var taskId = self.data('id'),
            pageType = self.data('page-type');

        $.post(constant.ROOT_PATH + 'task/' + taskId + '/restart', function(result) {
            if(result.success) {

                //群组页面
                if(pageType == 2) {
                    Tip.open('任务已重启', 700);
                    self.remove();
                    var btn = '<button class="km-btn km-btn-success btn-task-finish" data-page-type="2" data-id="' + taskId + '">完成</button>';
                    parent.find('.task-item-status').html(btn)
                } else {
                    Tip.open('任务已重启，可到待处理中查看');
                    parent.remove();
                    $('.task-item:even').addClass('gray');
                    $('.task-item:odd').removeClass('gray');
                    var count = $('.task-msg-count').html();
                    if (count == '99+') {
                        return;
                    } else {
                        $('.task-msg-count').html(+count + 1);
                    }
                }
            }
        })
    }





//    function taskFinish(element,item){
//        $.post(constant.ROOT_PATH + 'task/finish/' + element.data('id'), function(result) {
//            if(result.success) {
//                Confirmbox.show('任务已标记为完成，可到已处理中查看');
//                item.remove();
//
//                $('.task-item:even').addClass('gray');
//                $('.task-item:odd').removeClass('gray');
//                var count = $('.task-msg-count').html();
//                if(count == '99+') {
//                    return;
//                } else {
//                    $('.task-msg-count').html(count - 1);
//                }
//            }
//        });
//    }




    //搜索任务
    function searchTask(ele) {
        var box = ele.closest('.task-search'),
            input = box.find('input'),
            status = input.data('status');
        if(spinner && spinner.el) return;//如果存在菊花则不执行返回
        spinner = new Spinner().spin($('#task-wrapper').get(0));
        $.get(constant.ROOT_PATH + 'task/search', {keyword: input.val(), status: status}, function(result) {
            $('#task-wrapper').empty().append(result);
            $('#task-wrapper .task-item:odd').addClass('task-item-gray');
        }).always(function() {
                spinner.stop();
            });
    }




    //提交回复
    function postReply(ele) {
        var item = ele.closest('.task-item');
        var input = item.find('.reply-input');
        if(input.val() !== '') {
            $.post(constant.ROOT_PATH + 'task/reply', {referUserId: input.data('user-id'), referUserName: input.data('user-name'), taskId: input.data('task-id'), message: input.val()}, function(result) {
                input.val('');
                item.find('.task-reply-list').prepend(result);
            });
        } else {
//            item.find('.form-explain').show();
            Tip.open('回复内容不能为空', 1000);
        }
    };




});