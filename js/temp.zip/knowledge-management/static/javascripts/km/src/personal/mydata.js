define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Validator = require('validator');
    require('select2');
    var Tip = require('../common/tip');
    var Tab = require('./personal-tab');
    var uploadAvatar = require('./upload-avatar');
    var validator;
    var xss = require('../xss/index');


    exports.get = function(userId, cb) {
        $.ajax({
            type: 'GET',
            url: constant.ROOT_PATH + 'users/' + userId + '/info',
            cache: false
        }).done(function (result) {
            cb(result);
            init();
        });
    }

    exports.init = init;

    function init() {
        new Tab({element:$('.personal-data-tab')});

        $('#specialtySelect').select2({
            tags:[],
            separator: ';',
            tokenSeparators: [ ',', ';','，','；'],
            selectOnBlur: true,
            dropdownCss: {display: 'none'}
        });
        $('#interestSelect').select2({
            tags:[],
            separator: ';',
            tokenSeparators: [',', ';','，','；'],
            selectOnBlur: true,
            dropdownCss: {display: 'none'}
        });

        //表单验证
        Validator.addRule('phone', /^(\(\d{3,4}\)|\d{3,4}\-|\s)?\d{7,14}$/, '请输入合法的{{display}}')
        validator = new Validator({
            element: 'form[name="contact-info"]',
            failSilently: true
        });
        validator.addItem({
            element: '[name="email"]',
            rule: 'email',
            display: '邮箱格式'
        }).addItem({
                element: '[name="mobile"]',
                rule: 'mobile',
                display: '手机号码格式'
            }).addItem({
                element: '[name="phone"]',
                rule: 'phone',
                display: '电话号码'
            });

        /**
         * 上传头像
         */
        if($('.upload-avatar-btn').length > 0) {
            uploadAvatar.init({
                url: constant.ROOT_PATH + 'upload/avatar',
                trigger: '.upload-avatar-btn',
                callback: function(result) {
//                $('#userAvatar').attr('src', '/personal/' + result.data + '/avatar');
                }
            });
        }


        /**
         *  编辑个人信息
         */
        $('#personalDataWrapper').on('click', 'a', function(event) {

//            event.preventDefault();
            var ele = $(this),
                dataBox = ele.closest('.personal-data-box');

            if(ele.hasClass('personal-data-edit')) {    //如果是编辑按钮，切换到编辑状态
                dataBox.toggleClass('personal-is-edit');
            }

            if(ele.hasClass('personal-data-save')) {    //保存按钮，保存数据
                savePersonalInfo(ele);
            };

            if(ele.hasClass('imitate-textarea-delete')){    //输入框里面数据的删除按钮
                var btn = ele.closest('button');
                btn.remove();
            }

            if(ele.hasClass('save-password')) {  //保存密码
                savePassword(ele);
            }

            if(ele.hasClass('save-avatar')) {   //保存头像
                uploadAvatar.submit();
            }

        });

        $('.personal-data-textarea').on('keydown', function(event) {
            var ele = $(this);
            if(event.keyCode == 32) {
                var records = [];
                ele.find('.imitate-textarea-btn').each(function() {
                    records.push($(this).data('record'));
                    $(this).remove();
                });
                var text = ele.text().replace(/(^\s*)|(\s*$)/g, '');
                var textArr = text.split(' ');
                var last = textArr[textArr.length - 1].replace(/(^\s*)|(\s*$)/g, '');
                if(last.length > 0) {
                    records.push(last);
                }
                ele.empty();
                for(var i = 0; i < records.length; i += 1) {
                    var button = $('<button class="imitate-textarea-btn" oncontrolselect="return false;" contenteditable="false" onclick="return false;" data-record="' + records[i] + '">&nbsp;&nbsp;&nbsp;' + records[i] + '&nbsp;&nbsp;<a class="imitate-textarea-delete">×</a>&nbsp;&nbsp;&nbsp;</button>');
                    ele.append(button);
                }

                if(!isIe) {
                    ele.append('<br />');
                    ele.focus();
                    placeCursor(ele);
                }
            } else if(event.keyCode == 13) {
                return false;
            }
        });


        /**
         * 日期联动
         */
        dateSelector($('#bsMonth'), $('#bsDate'));

    }


    /**
     * 保存个人信息
     * @param ele
     */
    function savePersonalInfo(ele) {
        var dataBox = ele.closest('.personal-data-box'),
            form = dataBox.find('form'),
            info = form.serializeObject();


        if(!!info.month) {
            info.birthday = new Date(2000, info.month, info.date).getTime();
        }

        var edit = true;

        if(form.attr('name') == 'contact-info') {
            validator.execute(function(err, results, element) {
                console.log(err)
                if(err)  edit = false;
            })
        }
        if(edit) {
            $.post(constant.ROOT_PATH + 'users/info', {type: ele.data('save-type'), data: info}, function(result) {
                if(result.success) {
                    $.each(info, function(key, value) {
                        if(key == 'specialty' || key == 'interest') {
                            var records = value.split(';');
                            $([name = key]).val(value).trigger('change');
                            $('[data-name=' + key + ']').empty();
                            for(var i = 0; i < records.length; i += 1) {
                                if(records[i] !== '') {
                                    records[i] = xss(records[i]);
                                    var div = $('<div class="personal-select-item" data-record="' + records[i] + '">' + records[i] + '</div>');
                                    $('[data-name=' + key + ']').append(div);
                                }
                            }
                        } else {
                            if(key == 'birthday') {
                                var month = new Date(value).getMonth() + 1;
                                $('[data-name="month"]').html(month);

                                var date = new Date(value).getDate();
                                $('[data-name="date"]').html(date);
                            }
                            $([name=key]).val(value);
                            $('[data-name=' + key + ']').html(xss(value));
                        }
                    });
                    dataBox.toggleClass('personal-is-edit');
                    Tip.open('编辑信息成功', 700);
                } else {
                    Tip.open('编辑信息失败，请重试', 700);
                }
            });
        }

    }



    /**
     * 保存密码 123@abcd
     * @param ele
     */
    function savePassword(ele) {
        var form = ele.closest('form');
        var data = form.serializeObject();
        if(data['new'] === data['newagain'] ){
            $.post(constant.ROOT_PATH + 'update/password', data, function(result) {
                if(result.success) {
                    form.find('input').val('');
                    form.find('.save-pwd-tip').html('保存成功').css('color', '#37DB37');
                } else {
                    form.find('.save-pwd-tip').html(xss(result.data)).css('color', '#FF4040');
                }
            });
        };
    }


    function dateSelector (monthSelect, dateSelect) {
        var selectedMonth = monthSelect.data('bs-month');
        var selectedDate = dateSelect.data('bs-date');
        for(var i = 1; i <= 12; i += 1) {
            if(selectedMonth == i) {
                monthSelect.append('<option selected value="'+ (i - 1) +'">'+ i +'</option>');
            } else {
                monthSelect.append('<option value="'+ (i - 1) +'">'+ i +'</option>');
            }
        }
        for(var j = 1; j <= (new Date(2000, selectedMonth, 0)).getDate(); j += 1) {
            if(selectedDate == j) {
                dateSelect.append('<option selected value="'+ j +'">'+ j +'</option>');
            } else {
                dateSelect.append('<option value="'+ j +'">'+ j +'</option>');
            }

        }
        monthSelect.on('change', function(event) {
            dateSelect.empty();
            var month = parseInt(monthSelect.val(), 10) + 1;
            var date = (new Date(2000, month, 0)).getDate();
            for(var i = 1; i <= date; i += 1) {
                if(selectedDate == i) {
                    dateSelect.append('<option selected value="'+ i +'">'+ i +'</option>');
                } else {
                    dateSelect.append('<option value="'+ i +'">'+ i +'</option>');
                }
            }
        });
    };

    /**
     * 模拟textarea控件 div设置光标位置
     * @param ele
     */
    function placeCursor(ele) {
        ele = ele.get()[0];
        if(typeof window.getSelection != 'undefined' && typeof document.createRange != 'undefined') {
            var range = document.createRange();
            range.selectNodeContents(ele);
            range.collapse(false);
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        } else if(typeof document.body.createTextRange != 'undefined') {
            var textRange = document.body.createTextRange();
            textRange.moveToElementText(ele);
            textRange.collapse(false);
            textRange.select();
        }
    }







});
