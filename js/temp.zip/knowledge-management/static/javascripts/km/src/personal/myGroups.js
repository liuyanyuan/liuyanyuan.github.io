/**
 * Created by yanyuan.liu on 14-4-8.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Paging = require('../common/paging');

    var userId = $('#personal-user-id').val();

    exports.groupsPagingInit = function(){
        $('.ui-paging').each(function(i,obj) {
            new Paging({
                element: obj,
                url: constant.ROOT_PATH + 'users/'+userId+'/group-paging',
                params: {limit: 10},
                targetId: 'myGroup-list',
                cb: function(data) {
                    $("#myGroup-list").html(data);
                }
            })
        });
    }
});
