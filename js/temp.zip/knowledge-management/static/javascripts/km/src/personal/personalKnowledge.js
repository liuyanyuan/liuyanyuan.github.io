/**
 * 个人知识库 群组知识库 的各种操作
 */
define(function (require, exports, module) {
    var $ = require('$');
    var Confirmbox = require('confirmbox');
    var constant = require('../constant');
    var Tip = require('../common/tip');
    var Crumbs = require('../common/crumbs');
    var knowledgeLibrary = require('../common/knowledge-library');
    var Spinner=require('spin');
    var araleTip = require('arale-tip');
    var spinner;
    var xss = require('../xss/index');

    //获取某个人的知识列表
    exports.get = function(userId, cb) {
        $.ajax({
            type: 'GET',
            url: constant.ROOT_PATH + 'users/' + userId + '/knowledge',
            data: {order: 'asc', catalog: 0, attachedType: 1, attachedId: userId},
            cache: false
        }).done(function(result) {
            cb(result);
            init();
        });
    }

    exports.init = init;

    function init() {
        var crumbs = $('#knowledgeCrumbs');
        var attachedType = $('[name="attachedType"]').val();
        var attachedId = $('[name="attachedId"]').val();
        var powerType = $('[name="powerType"]').val();
        var authType = $('[name="authType"]').val();
        var catalog = $('[name="catalog"]').val();

        //面包屑组件
        new Crumbs({
            element: crumbs,
            trigger: '.km-filesys-folder',
            parent: '#knowledgeList',
            extraTrigger: '[data-item-id="knowledgeBox"]',
            extraParent: '.personal-menu',
            url: constant.ROOT_PATH + 'knowledge/list',
            params: {attachedType: attachedType, attachedId: attachedId, id: catalog, powerType: powerType, authType: authType},
            cb: function (result) {
                $('[name="catalog"]').val(result);
                var extra = $('.knowledge-menu-list').find('[data-id="' + result + '"]');
                if (extra.length == 1) {
                    $('#knowledgeBox').show().siblings().hide();
                    console.log(extra.closest('li'));
                    extra.parent().parent().addClass('on').siblings().removeClass('on');
                    window.location.hash = '#personalNav=my-knowledge';
                    extra.addClass('on').siblings().removeClass('on');
                }

            }
        });

        //目录树组件初始化
        var CatalogTree = require('./catalog-tree');
        new CatalogTree({
            parent: '#knowledgeMain',
            trigger: '.knowledge-move',
            treeId: 'pkCatalogTree',
            width: 500,
            hasBtn: false,
            parmas: {attachedType: attachedType, attachedId: attachedId},
            url: constant.ROOT_PATH + 'knowledge/catalog',
            cb: function (result) {
                var trigger = result.trigger;
                var path = result.path;
                var idlist = result.idlist;
                var targetId = result.target;
                var selfId = trigger.data('id');

                if (targetId == selfId) {
                    Tip.open('不能自己移动到自己', 700);
                } else if ((idlist + '').indexOf(selfId) >= 0) {
                    Tip.open('不能移动到自己的子目录', 700);
                } else {
                    $.post(constant.ROOT_PATH + 'catalog/edit', {params: {parentId: targetId, name: trigger.data('name'), attachedType: attachedType, attachedId: attachedId}, catalog: {id: selfId, flag: trigger.data('flag')}}, function (result) {
                        if (result.success) {
                            Tip.open('已成功移动到目录 ' + path);
                            trigger.closest('.km-filesys-item').hide();
                            var extra = $('.knowledge-menu-list').find('[data-id="' + selfId + '"]');
                            extra.hide();
                        } else {
                            Tip.open(result.message, 1000);
                        }
                    });
                }


            }
        });


        //上传文件
        new araleTip({
            trigger: $('.upload-file-btn'),
            theme: 'blue',
            content: '<div class="upload-file-tip">' +
                '<h1>上传须知：</h1>' +
                '<p>上传的文档不超过' + constant.FILE_SIZE_LIMIT + 'M</p>' +
                '<p><span>上传支持格式：</span>' +
                '<span class="km-ico km-ico-file-mini-2"></span><span>pdf</span>' +
                '<span class="km-ico km-ico-file-mini-4"></span><span>doc,docx</span>' +
                '<span class="km-ico km-ico-file-mini-1"></span><span>ppt,ppx</span>' +
                '<span class="km-ico km-ico-file-mini-3"></span><span>xls,xlsx</span>' +
                '</p>' +
                '</div>',
            arrowPosition: 1
        })

        knowledgeLibrary.initUpload({
            params: {type: 1},
            callback: function (result) {
                if (result) {
                    var updateConfirmbox = new Confirmbox({
                        title: '',
                        message: result,
                        width: 700,
                        cancelTpl: '',
                        confirmTpl: '',
                        closeTpl: '<div id="closeUpdateConfirmbox">×</div>'
                    }).show();

                    setTimeout(function() {
                        $('#closeUpdateConfirmbox').on('click', function (event) {
                            updateConfirmbox.destroy();
                        });

                        $('#knowledgeCancel').on('click', function(event) {
                            console.log('click');
                            event.preventDefault();
                            updateConfirmbox.destroy();
                        })

                        knowledgeLibrary.initUpdate();
                        $('#knowledgeSubmit').on('click', function (event) { //新增知识点
                            event.preventDefault();
                            knowledgeLibrary.addKnowledge({type: attachedType, attachedId: attachedId, knowledgeType: 1, catalogId: $('[name="catalog"]').val()}, function (result) {
                                if (result.success) {
                                    Tip.open('新增知识点成功');
                                    var klist = $('#knowledgeList');
                                    if (klist.find('.has-no-data').length > 0) {
                                        klist.find('.has-no-data').hide();
                                    }
                                    var folders = klist.find('.km-filesys-item-folder'),
                                        folders_length = folders.length;
                                    if(folders_length > 0) {
                                        $(result.html).insertAfter(folders[folders_length - 1]);
                                    } else {
                                        klist.prepend(result.html);
                                    }


                                    updateConfirmbox.destroy();
                                    updateSideNav({
                                        type: 2,
                                        count: 1,
                                        id: $('[name="catalog"]').val()
                                    });
                                } else {
                                    Confirmbox.show(result.html);
                                }
                            })
                        });
                    }, 0);



                }
            }
        });


        //创建文档
        $('#createFile').on('click', function (event) {
            if(spinner && spinner.el) return;//如果存在菊花则不执行返回
            spinner = new Spinner().spin(document.body);
            $.get(constant.ROOT_PATH + 'knowledge/personal/create', function (result) {
                var updateConfirmbox = new Confirmbox({
                    title: '创建文档',
                    message: result,
                    width: 700,
                    cancelTpl: '',
                    confirmTpl: '',
                    closeTpl: '<div id="closeUpdateConfirmbox">×</div>'
                }).show();

                setTimeout(function() {
                    knowledgeLibrary.initUpdate();
                    $('#closeUpdateConfirmbox').on('click', function (event) {
                        updateConfirmbox.destroy();
                    });

                    $('#knowledgeCancel').on('click', function(event) {
                        console.log('click');
                        event.preventDefault();
                        updateConfirmbox.destroy();
                    })
                    $('#knowledgeSubmit').on('click', function (event) { //新增知识点
                        event.preventDefault();
                        knowledgeLibrary.addKnowledge({type: attachedType, attachedId: attachedId, knowledgeType: 2, catalogId: $('[name="catalog"]').val()}, function (result) {
//                            console.log(result);
                            if (result.success) {
                                Tip.open('新增知识点成功');
                                var klist = $('#knowledgeList');
                                if (klist.find('.has-no-data').length > 0) {
                                    klist.find('.has-no-data').hide();
                                }
                                var folders = klist.find('.km-filesys-item-folder'),
                                    folders_length = folders.length;
                                if(folders_length > 0) {
                                    $(result.html).insertAfter(folders[folders_length - 1]);
                                } else {
                                    klist.prepend(result.html);
                                }

                                updateSideNav({
                                    type: 2,
                                    count: 1,
                                    id: $('[name="catalog"]').val()
                                });
                                updateConfirmbox.destroy();
                            } else {
                                Confirmbox.show(result.html);
                            }
                        })
                    })
                }, 0);





            }).always(function(data, status, err) {
                    spinner.stop();
                });;
        });




        //新建文件夹绑定事件
        $('#addFolder').on('click', function (event) {
            event.preventDefault();
            var self = $(this);
            var catalog = $('[name="catalog"]').val();
            var isConfirm = false;
            var errorMessage = '';
            //'<label for="">请输入新文件夹的名称：</label><input style="width: 200px;padding: 3px;" name="newFloderName" type="text"><p class="limit-world-count" style="float: right;color: red;">限制15个字</p>'
            Confirmbox.confirm(folderHtml(), '新建文件夹', function () {
                var name = $('[name="folder-name"]').val();
                if(name == '') {
                    isConfirm = true;
                    errorMessage = '输入文件夹名称不能为空';
//                    Tip.open('输入文件夹名称不能为空', 1000);
                } else {
                    $.post(constant.ROOT_PATH + 'knowledge/personal/catalog/add', {name: name, parentId: catalog, attachedType: attachedType, attachedId: attachedId}, function (result) {
                        if (result.html) {
                            $('#knowledgeList').prepend(result.html);
                            var klist = $('#knowledgeList');
                            if (klist.find('.has-no-data').length > 0) {
                                klist.find('.has-no-data').hide();
                            }
                            if (catalog == 0) {
                                var extra = $('.knowledge-menu-list');
                                var html = '<li class="menu-item menu-item-son knowledge-crumbs-extra" data-id="' + result.data.id + '" data-name="' + name + '"><a href="" ><span>' + name + '</span>(<span class="count">0</span>)</a></li>'
                                extra.prepend(html);

                            }
                            updateSideNav({
                                type: 2,
                                count: 1,
                                id: catalog
                            });
                        } else if(result.message) {
                            Tip.open(result.message, 1000);
                        }
                    });
                }

            }, {
                beforeHide: function() {
                    if(isConfirm) {
                        $('[name="folder-name"]').closest('.km-form-group-folder').find('.ui-form-explain').html(xss(errorMessage)).show();
                        isConfirm = false;
                        return false;
                    }
                },
                closeTpl: '×',
                width: 400
            });

            setTimeout(function() {
                var $inp_f = $('[name="folder-name"]');
                $inp_f.focus();
                limitWords($inp_f, 15);
            }, 0);




        });

        //目录各种操作绑定事件
        $('#knowledgeMain').on('click', 'a', function (event) {
//            event.preventDefault();
            var self = $(this);

            if (self.hasClass('knowledge-edit')) {   //编辑 重命名或者修改知识点
                renameFloder(self);
            }

            if (self.hasClass('knowledge-share')) {  //分享

                var Share = require('./../common/share');
                Share.share({title: self.data('name'), id: self.data('id'), type: 1});
            }

            if (self.hasClass('knowledge-delete')) { //删除文件或目录
                deleteCatalog(self);
            }

            if(self.hasClass('file-reviews')) {
                var id= self.data('id');
                if(spinner && spinner.el) return;//如果存在菊花则不执行返回
                spinner = new Spinner().spin(document.body);
                $.ajax({
                    type: 'GET',
                    url: constant.ROOT_PATH + 'knowledge/review/' + id,
                    cache: false
                }).done(function (result) {
                    Confirmbox.confirm(result, '预览', null, {
                        closeTpl: '×',
                        width: 800,
                        confirmTpl: ''
                    });
                    var ImgFullSizeView = require('../common/img-fullSizeView');

                    ImgFullSizeView.imgFullSizeView('.edui-editor-body');
                }).always(function (data, status, err) {
                    spinner.stop();
                });

            }

        });


    };

    //删除知识提示
    function showDeleteTip(options, cb) {
        $.get(constant.ROOT_PATH + 'knowledge/delete/tip', options, function(result) {
            cb(result);
        })
    }


    //侧边栏知识库更新
    function updateSideNav(options) {
        var extra = $('.knowledge-menu-list').find('[data-id="' + options.id + '"]');
        if(extra.length > 0) {
            switch (options.type) {
                case 1:  //name变更
                    extra.find('.name').html(xss(options.name));
                    break;
                case 2: //count变更
                    var count = parseInt(extra.find('.count').html());
                    extra.find('.count').html(xss(count + options.count));
                    break;
                default:
                    break;

            }
        }

    }

    function folderHtml(value) {
        var defaultVal = value ? value : '';
        return '<div class="km-form-group km-form-group-folder">'
            + '<label class="km-form-label" for="">新文件名：</label>'
            + '<div class="km-form-content ui-form-item">'
            + '<div class="form-input-wrapper">'
            + '<input name="folder-name" type="text" value="' + defaultVal +'">'
            + '</div>'
            + '<div class="ui-form-explain"></div>'
            + '</div>'
            + '</div>';
    }
    function limitWords(element, count) {
        element.on('keydown',function() {
            var self = $(this);
            var extraCount = count - self.val().length;
            self.closest('.km-form-group-folder').find('.ui-form-explain').hide();
            if(extraCount < 0) {
                self.val(self.val().slice(0, count));
                self.closest('.km-form-group-folder').find('.ui-form-explain').html('最多输十五个字符').show();
                return false;
            }
        }).on('keyup', function() {
                var self = $(this);
                var extraCount = count - self.val().length;
                self.closest('.km-form-group-folder').find('.ui-form-explain').hide();
                if(extraCount < 0) {
                    self.val(self.val().slice(0, count));
                    self.closest('.km-form-group-folder').find('.ui-form-explain').html('最多输十五个字符').show();
                    return false;
                }
            });
    }


    //删除
    function deleteCatalog(element) {
        var id = element.data('id'),
            name = element.data('name'),
            flag = element.data('flag'),
            count = element.data('child-count'),
            type = element.data('type'),
            item = element.closest('.km-filesys-item');


        showDeleteTip({flag: flag, name: name, type: type || 1}, function (result) {
            Confirmbox.confirm(result, '', function () {
                $.post(constant.ROOT_PATH + 'catalog/delete', {catalog: {id: id, flag: flag}}, function (result) {
                    if (result.success) {
                        item.remove();
                        var extra = $('.knowledge-menu-list').find('[data-id="' + id + '"]');
                        extra.hide();
                        updateSideNav({
                            type: 2,
                            count: -1,
                            id: $('[name="catalog"]').val()
                        });
                        Tip.open('成功删除', 700);
                    } else {
                        if(flag == 1) {
                            showDeleteTip({flag: flag, message: result.message, type: 2}, function(html) {
                                Confirmbox.show(html)
                            });
                        } else {
                            Tip.open('删除失败' + result.message, 700);
                        }

                    }

                })
            }, {
                closeTpl: '×',
                width: 400,
                title: '',
                cancelTpl: '',
                confirmTpl: ''
            });
        })

//        Confirmbox.confirm('确定删除' + name + '？', '', function () {
//            $.post(constant.ROOT_PATH + 'catalog/delete', {catalog: {id: id, flag: flag}}, function (result) {
//                if (result.success) {
//                    item.remove();
//                    var extra = $('.knowledge-menu-list').find('[data-id="' + id + '"]');
//                    extra.hide();
//                    updateSideNav({
//                        type: 2,
//                        count: -1,
//                        id: $('[name="catalog"]').val()
//                    });
//                    Tip.open('成功删除', 700);
//                } else {
//                    Tip.open('删除失败' + result.message, 700);
//                }
//
//            })
//        }, {
//            closeTpl: '×',
//            width: 400,
//            title: ''
//        });


    }





    //重命名文件夹
    function renameFloder(element) {
        var id = element.data('id'),
            name = element.closest('.km-filesys-item').find('.knowledge-name').html(),
            flag = element.data('flag'),
            parent = element.data('parent'),
            newname = name;
        var attachedType = $('[name="attachedType"]').val();
        var attachedId = $('[name="attachedId"]').val();

        if (flag == 1) {

            var isConfirm = false;
            var errorMessage = '';
            Confirmbox.confirm(folderHtml(newname), '重命名', function () {
                var that = this;
                console.log(that);
                isConfirm = true;
                newname = $('[name="folder-name"]').val();
                if($('[name="folder-name"]').val() == '') {
                    errorMessage = '输入文件夹名称不能为空';
                    return;
                }else if(newname == name) {
                    isConfirm = false;
                    return;
                } else {
                    isConfirm = false;
                    $.post(constant.ROOT_PATH + 'catalog/edit', {params: {name: newname, parentId: parent, attachedType: attachedType, attachedId: attachedId}, catalog: {id: id, flag: flag}}, function (result) {
                        if (result.success) {
                            var item = element.closest('.km-filesys-item');
                            item.find('.knowledge-name').html(xss(newname));
                            item.find('[data-name="' + name + '"]').each(function () {
                                $(this).data('name', newname);
                            });
                            var extra = $('.knowledge-menu-list').find('[data-id="' + id + '"]').find('.name');
                            if (extra.length == 1) {
                                extra.html(xss(newname));
                            }
//                            that.destroy();
                        } else {
//                            errorMessage = result.message;
                            Tip.open(result.message, 1000);
//                            $('[name="folder-name"]').closest('.km-form-group-folder').find('.ui-form-explain').html(result.message).show();
                            return;
                        }
                    });
                }


            }, {
                beforeHide: function() {
                    if(isConfirm) {
                        $('[name="folder-name"]').closest('.km-form-group-folder').find('.ui-form-explain').html(xss(errorMessage)).show();
                        isConfirm = false;
                        return false;
                    }
                },
                closeTpl: '×',
                width: 400

            });
            setTimeout(function() {
                var $inp_f = $('[name="folder-name"]');
                $inp_f.focus();
                limitWords($inp_f, 15);
            }, 0);

        } else {
            if(spinner && spinner.el) return;//如果存在菊花则不执行返回
            spinner = new Spinner().spin(document.body);
            $.get(constant.ROOT_PATH + 'knowledge/doc', {file_name: name, id: id}, function (result) {
                var updateConfirmbox = new Confirmbox({
                    title: '',
                    message: result,
                    width: 700,
                    cancelTpl: '',
                    confirmTpl: '',
                    closeTpl: '<div id="closeUpdateConfirmbox">×</div>'
                }).show();

                setTimeout(function() {
                    knowledgeLibrary.initUpdate();
                    $('#closeUpdateConfirmbox').on('click', function (event) {
                        updateConfirmbox.destroy();
                    });
                    $('#knowledgeCancel').on('click', function(event) {
                        console.log('click');
                        event.preventDefault();
                        updateConfirmbox.destroy();
                    })

                    $('#knowledgeSubmit').on('click', function (event) {
                        event.preventDefault();
                        var self = $(this);
                        knowledgeLibrary.updateKnowledge({type: $('[name="attachedType"]').val(), attachedId: $('[name="attachedId"]').val()}, self.data('id'), function (result, data) {
                            if (result.success) {

                                if(data.knowledgeType == 2) {
                                    $('.km-filesys-substance[data-id="' + data.id +  '"]').attr('title', data.title).find('.knowledge-name').html(xss(data.title));
                                }

                                if(data.type == '13' || data.type == '23') {
                                    var parent = $('.km-filesys-substance[data-id="' + data.id +  '"]').parent();
                                    parent.find('.km-file-status').html('审核中');
                                    parent.find('.knowledge-delete').remove();
                                    parent.find('.knowledge-share').remove();
                                    parent.find('.knowledge-edit').remove();
                                    Tip.open('与公共知识库已同步', 700);

                                } else {
                                    Tip.open('修改知识点成功', 700);
                                }


                                updateConfirmbox.destroy();
                            } else {
                                Confirmbox.show(result.message);
                            }
                        })
                    })
                }, 0);

            }).always(function(data, status, err) {
                    spinner.stop();
                });
        }
    }

})