define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Uploader = require('upload');
    var Tip = require('../common/tip');
    var formObj = {};

    exports.init = function () {
        $('#applyBox').on('click', 'a', function (event) {
            event.preventDefault();
            var self = $(this);

            if (self.hasClass('apply-scan')) {
                var data = self.data('apply-details');
                showApplyDetails(data);
                updateApplyCrumbs('查看申请');
            }

            if (self.hasClass('apply-index')) {
                $('.my-apply-table').show().siblings().hide();
                $('.apply-box-title').html('我的申请');
            }

            if(self.hasClass('add-apply-btn')) {
                $('#applyAddBox').show().siblings().hide();
                updateApplyCrumbs('新增申请');
            }

            if(self.hasClass('apply-attachment-delete')) {
                var id = self.data('id');
                $.post(constant.ROOT_PATH + 'files/delete/' + id, function(result) {
                    if(result.success) {
                        var li = self.closest('li');
                        li.remove();
                    } else {
                        Tip.open('删除失败，请重试', 700);
                    }
                })
            }

            if(self.hasClass('apply-commit')) {
                var obj = {};
                var type = $('[name="apply-type"]');
                var category = $('[name="apply-category"]');
                var explain = $('[name="apply-explain"]');
                obj.explain = explain.val();
                obj.doc = [];
                $.each($('.apply-attachment-list li'), function() {
                    obj.doc.push($(this).data('id'))
                });

                $.post(constant.ROOT_PATH + 'users/apply', obj, function(result) {
                    if(result) {
                        explain.val('');
                        $('.apply-attachment-list').empty();
                        $('.my-apply-table').find('tbody').append(result);
                        Tip.open('提交申请成功。', 700);
                    } else {
                        Tip.open('提交申请失败，请重试',700);
                    }
                })

                console.log(obj);
            }
        })

        //上传申请资料
        var uploader = new Uploader({
            trigger: '#applyAttachment',
            action: constant.ROOT_PATH + 'files/upload',
            name: 'upfile',
            multiple: false
        }).success(function(result) {
            result = JSON.parse(result);
            if(result.success) {
                console.log(result);
                var list = $('.apply-attachment-list');
                var html = '<li data-id="' + result.data.id + '">' + result.data.file_name + '<a href="#" class="apply-attachment-delete" title="删除" data-id="' + result.data.id + '"><i class="iconfont">&#x34e4;</i></a></li>';
                list.append($(html));
            } else {
                Tip.open('上传资料失败，请重试。', 700);
            }

        });
        formObj.form = uploader._uploaders[0].form;
    }
    exports.formObj = formObj;

    function updateApplyCrumbs(str) {
        var newTitle = '<a href="#" class="apply-index">我的申请</a>' + '>' + '<span>' + str + '</span>';
        $('.apply-box-title').html(newTitle);
    }

    function showApplyDetails(data) {
        var box = $('#applyDetailsBox');
        box.find('.apply-details-time').text(data.createTime);
        box.find('.apply-details-user').text(data.userName);
        box.find('.apply-details-type').text(data.type);
        box.find('.apply-details-category').text(data.category);
        box.find('.apply-details-explain').text(data.explain);
        var docHtml = '';
        $.each(data.doc, function() {
            var p = '<p>' + this.name + '</p>';
            docHtml += p;
        });

        box.find('.apply-details-doc').html(docHtml);
        box.show().siblings().hide();
    }


});