define(function(require, exports, module) {
    var $ = require('$');

    function Tab(options) {
        this.settings = {
            element: $('.personal-tab'),
            triggers: '.personal-tab-nav li',
            panels: '.personal-tab-content .hidden',
            triggerType: 'click',
            activeIndex: 0,
            activeTriggerClass: 'personal-tab-nav-active'
        }
        $.extend(this.settings, options);
        this.init();

    }

    Tab.prototype.init = function() {
        var that = this.settings;
        $(that.element.find(that.panels)[that.activeIndex]).show().siblings().hide();
        $(that.element.find(that.triggers)[that.activeIndex]).addClass(that.activeTriggerClass);
        that.element.on(that.triggerType, that.triggers, function(event) {
             var self = $(this);
            self.addClass(that.activeTriggerClass).siblings().removeClass(that.activeTriggerClass);
            var index = that.element.find(that.triggers).index(this);
            $(that.element.find(that.panels)[index]).show().siblings().hide();
        })
    }
    module.exports = Tab;

});