define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Turntask = require('../common/turn-task');
    var Tip = require('../common/tip');
    var Spinner = require('spin');
    var hash_change = require('../common/hash-change');
    var spinner;
    var userId = $('#personal-user-id').val();
    var questionToAsk = require('../question/toAsk');
    var Confirmbox = require('confirmbox');



    //个人信息
    $.get('/ajax/personal/avatar', {userId: userId}, function(data){
        $('#J-personal-head-wrap').html(data);
    });
    //个人未完成任务数
    $.get('/ajax/task/count', function(result) {
        if(result.count) {
            $('#task-msg-count').show().html(result.count);
        }
    })

//    页面滚动fix效果
    var Sticky = require('sticky');
    var st2 = Sticky(' #info-sidebar', 50, function(status) {
        var element = $(' #info-sidebar');
        if(status) {
            if(!element.hasClass('fixed')) {
                element.addClass('fixed')
            }

        } else {
            if(element.hasClass('fixed')) {
                element.removeClass('fixed')
            }
        }
    });
    $(window).on('resize', function () {
        st2.adjust();
    });


    //hash字符串转对象
//    function hashObj(str) {
//        var obj = {};
//        var arr = str.split('&');
//        $.each(arr, function (index, value) {
//            var name = value.split('=');
//            obj[name[0]] = name[1];
//        });
//        return obj;
//    }


    var hash = window.location.hash.slice(1);
    var hashobj = hash.toJsonObj();;

    if (hashobj.personalNav) {
        personalNav(hashobj.personalNav);
    } else {
        personalNav('my-knowledge');
    }


    hash_change.init(f_change);

    function f_change() {
        var hash = window.location.hash.slice(1);
        hashobj = hash.toJsonObj();
        personalNav(hashobj.personalNav || 'my-knowledge');
    }



    function personalNav(type) {
        var wrapper = $('#personal-main-change');    //页面的显示内容
        var navItem = $('[data-item-type="' + type + '"]');    //侧边栏导航菜单项
        var box = $('#' + navItem.data('item-id'));                  //对应菜单项的内容


        navItem.addClass('on').siblings().removeClass('on');
        if (box.length > 0) {    //如果要显示的内容已经存在
            box.show().siblings().hide();

        } else {    //不存在加载新数据

            spinner =  new Spinner().spin(wrapper.get(0));
            switch (type) {
                case 'my-data':
                    var mydata = require('./mydata');
                    mydata.get(userId, function(result) {
                        wrapper.append(result);
                        $('#' + navItem.data('item-id')).show().siblings().hide();
                        spinner.stop();
                    });
                    break;
                case 'my-task':
                    var mytask = require('./mytask');
                    mytask.get(function(result) {
                        wrapper.append(result);
                        $('#' + navItem.data('item-id')).show().siblings().hide();
                        spinner.stop();
                    });
                    break;
                case 'my-follow':
                    var follow = require('./follow');
                    follow.get(userId, function(result) {
                        wrapper.append(result);
                        $('#' + navItem.data('item-id')).show().siblings().hide();
                        spinner.stop();
                    });
                    break;
                case 'my-group':
                    $.ajax({
                        type: 'GET',
                        url: constant.ROOT_PATH + 'users/' + userId + '/groups',
                        cache: false
                    }).done(function (result) {
                            wrapper.append(result);
                            var groups = require('../personal/myGroups');
                            groups.groupsPagingInit();
                            $('#' + navItem.data('item-id')).show().siblings().hide();
                        }).always(function(data, status, err) {
                            spinner.stop();
                        });
                    break;
                case 'my-knowledge':
                    var personalKnowledge = require('./personalKnowledge');
                    personalKnowledge.get(userId, function(result) {
                        wrapper.append(result);
                        $('#' + navItem.data('item-id')).show().siblings().hide();
                        spinner.stop();
                    });

                    break;
                case 'my-trend':
                    $.ajax({
                        type: 'GET',
                        url: constant.ROOT_PATH + 'users/' + userId + '/trends',
                        cache: false
                    }).done(function (result) {
                            wrapper.append(result.html);
                            var trend = require('../home/trend.js');
                            trend.init();
                            $('#' + navItem.data('item-id')).show().siblings().hide();
                        }).always(function() {
                            spinner.stop();
                        });
                    break;
                case 'my-apply':
                    $.ajax({
                        type: 'GET',
                        url: constant.ROOT_PATH + 'users/apply',
                        cache: false
                    }).done(function (result) {
                            wrapper.append(result);
                            var apply = require('./apply');
                            apply.init();

                            $('#' + navItem.data('item-id')).show().siblings().hide();
                        }).always(function(data, status, err) {
                            spinner.stop();
                        });
                    break;
                default :
                    break;
            }

        }

    }



    /**
     * 侧边栏
     */
    $('.personal-box').on('click', 'li.menu-item, a.order-task, a.order-toAsk, a.personal-follow-operate', function (event) {
        event.stopPropagation();
//        event.preventDefault();

        var self = $(this),
            type = self.data('item-type'),
            userId = self.data('user-id');



        if(self.hasClass('order-task')) {
            var userName = self.data('user-name');
            Turntask.turnTask({
                tasktype: 3,
                taskdata: {
                    performers: {
                        userName: userName,
                        userId: userId
                    }
                },
                cb: function (result) {
                    if (result.success) {
                        Tip.open('发送任务成功', 700);
                    } else {
                        Tip.open('发送任务失败，请重试', 700);
                    }
                }
            })

        }else if(self.hasClass('order-toAsk')) {
            var userName = self.data('user-name');
            $.get(constant.ROOT_PATH +'expert/addQuestion?type=2&userid='+userId+'&username='+userName,function(result){
                var comfirmbox = new Confirmbox({
                    title: '提问',
                    message: result,
                    width: 680,
                    cancelTpl: '',
                    confirmTpl: '',
                    closeTpl: 'X'
                }).show().after("hide", function () {
                        comfirmbox.destroy();
                    });
                questionToAsk.initSelect_toAsk(2);
                $('#btn-submit').on('click', function () {
                    questionToAsk.addQuestion(2,comfirmbox);
                });
            })
        } else if(self.hasClass('menu-item')) {
            if (!self.hasClass('menu-item-son')) {
                window.location.hash = '#personalNav=' + type;
            }
            if (self.find('ul').length > 0) {
                self.toggleClass('open');
            }
        } else if(self.hasClass('personal-follow-cancel')) {
            $.post(constant.ROOT_PATH + 'users/follow/' + userId, function(result) {
                var status = $('.personal-follow-status');
                if(result.success) {
                    status.find('.status').html('未关注');
                    status.find('.personal-follow-operate').removeClass('personal-follow-cancel').addClass('personal-follow-add').html('关注Ta');
                } else {
                    Tip.open('取消关注失败，请重试', 700);
                }
            });
        } else if(self.hasClass('personal-follow-add')) {
            $.post(constant.ROOT_PATH + 'users/follow', {userId: userId}, function(result) {
                var status = $('.personal-follow-status');
                if(result.success) {
                    status.find('.status').html('√已关注');
                    status.find('.personal-follow-operate').removeClass('personal-follow-add').addClass('personal-follow-cancel').html('取消');
                }else {
                    Tip.open('添加关注失败，请重试',700);
                }
            })
        }




    });




});