define(function (require, exports, module) {
    var $ = require('$');
    var constant = require('../constant');
    var Tip = require('../common/tip');
    var input_invite = require('../common/input_invite');
    var Confirmbox = require('confirmbox');
    var Paging = require('../common/paging');


    exports.get = function(userId, cb) {
        $.ajax({
            type: 'GET',
            url: constant.ROOT_PATH + 'users/' + userId + '/following',
            cache: false
        }).done(function (result) {
            cb(result);
            init();
        });
    }

    exports.init = init;

    function init() {

        if($('.ui-paging').length > 0) {
            new Paging({
                element: $('.ui-paging'),
                url: constant.ROOT_PATH + 'users/' + $('#personal-user-id').val() + '/following/page',
                targetId: 'followBox',
                cb: function(data) {
                    $('.follow-list').empty().append(data);
                }
            })
        }


        //加关注
        input_invite.initButton("followAdd", {title: '选择关注的人'},function(data) {
            var userId = [],
                userName = '';
            $.each(data, function() {
                userId.push(this.id);
                userName += '<span style="color: #3570A5;margin: 0 3px;">' + this.name + '</span>';
            });
            userId = userId.join(',');
            var selfUserId = $('#personal-user-id').val();
            if(userId == selfUserId) {
                Tip.open('不能自己关注自己', 700);
            } else if(userId == ''){
                Tip.open('你没有选择关注的人', 700);
            } else {
                $.post(constant.ROOT_PATH + 'users/follow', {userId: userId}, function(result) {
                    if(result.success) {
                        Tip.open('已成功添加对' + userName + '的关注', 700);
                        window.location.reload();
                    } else {

                        Tip.open('添加关注失败，请重试', 700);
                    };
                });
            }

        });

        $('#followBox').on('click', 'a', function(event) {
//            event.preventDefault();
            var self = $(this);

            if(self.hasClass('follow-cancel')) {    //取消关注
                var id = self.data('id'),
                    name = self.data('name');
                Confirmbox.confirm('<p style="font-size: 14px; padding: 10px 0;">确定要取消对<span style="color: #3570A5;margin: 0 3px;">' + name + '</span>的关注吗？</p>', '提示', function() {
                    $.post(constant.ROOT_PATH + 'users/follow/' + id, function(result) {
                        if(result.success) {
                            Tip.open('已取消对' + name + '的关注', 700);
                            var followItem = self.closest('.follow-item');
                            console.log(followItem)
                            followItem.remove();
//                            self.removeClass('follow-cancel').addClass('follow-add');
//                            self.html('加关注');
                        } else {
                            Tip.open('取消关注失败，请重试', 700);
                        }
                    });
                }, {
                    closeTpl: '×',
                    width: 350
                })

            }

//            if(self.hasClass('follow-add')) {   //加关注
//                var id = self.data('id');
//                var userId = [];
//                userId.push(id);
//                $.post(constant.ROOT_PATH + 'users/follow', {userId: userId}, function(result) {
//                    if(result.success) {
//                        self.removeClass('follow-add').addClass('follow-cancel');
//                        self.html('取消关注');
//                    } else {
//                        Tip.open('关注失败，请重试', 700);
//                    };
//                });
//            }

            if(self.hasClass('send-message')) {
                var id = self.data('id');
            }
        });
    }

});