define(function(require, exports, module){
    var $=require("$");
    var Widget = require("widget");
    var Confirmbox = require('confirmbox');

    var catalogTree = Widget.extend({
        attrs: {
            parent: {
                value: '',
                getter: function(val) {
                    return $(val);
                }
            },
            title: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            trigger: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            treeId: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            url: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            parmas: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            width: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            hasBtn: {
                value: true,
                getter: function(val) {
                    return val;
                }
            },
            onlyLeaf: {
                value: false,
                getter: function(val) {
                    return val;
                }
            },
            showBox: {
                value: '',
                getter: function(val) {
                    return val;
                }
            },
            cb: {
                value: '',
                getter: function(val) {
                    return val;
                }
            }
        },
        setup: function() {
            this._bindTriggers();
            this.render();
        },
        _initTree: function() {

            var that = this;
            var catalogTree = $('#' + that.get('treeId'));
            if(that.get('title')) {
                catalogTree.find('.catalog-tree-begin').text(that.get('title'));
            }
            if(!that.get('hasBtn')) {
                catalogTree.find('.catalog-tree-affirm').hide();
            }
            catalogTree.find('.catalog-tree-affirm').on('click', function(event) {
                that.get('cb')({
                    target: catalogTree.find('.catalog-target').data('id'),
                    path: catalogTree.find('.catalog-target').data('path'),
                    name: catalogTree.find('.catalog-target').data('name'),
                    idlist: catalogTree.find('.catalog-target').data('idlist')
                });
            });



            catalogTree.on('click', '.node-item',function(event){
                var self=$(this);
                event.stopPropagation();
                if(!self.hasClass('node-opened')){
                    $(self.find('.node-item-icon')[0]).html('&#9660;');
                    self.addClass('node-opened').removeClass('node-closed');
                    self.children('ul:first').show()
                }
                else
                {
                    $(self.find('.node-item-icon')[0]).html('&#9654; ');
                    self.addClass('node-closed').removeClass('node-opened');
                    self.children('ul:first').hide();
                }

                //移动到
                catalogTree.find('.node-item-picked').removeClass('node-item-picked');
                if(self.find('.node-indent').length > 0) {
                    self.children('.node-item-name').addClass('node-item-picked');
                }else {
                    self.addClass('node-item-picked');
                }


                if((that.get('onlyLeaf') && self.hasClass('node-leaf')) || !that.get('onlyLeaf')) {
                    var id = self.data('id'),
                        name = self.data('name'),
                        idlist = self.data('idlist'),
                        path = self.data('path');
                    catalogTree.find('.catalog-target').data('id', id).data('name', name).data('idlist', idlist).data('path', path).html(path);
                }

            });


        },
        _showTree: function(trigger) {
            var that = this;
            var tree = $('#' + that.get('treeId'));
            if(tree.length > 0) {
                tree.show();
            } else {
                $.get(that.get('url'), that.get('parmas'), function(result) {
                    var html = $('<div></div>').append($(result).attr('id', that.get('treeId'))).html();
                    if(!that.get('showBox')) {
                        Confirmbox.confirm(html, '', function() {
                            var tree = $('#' + that.get('treeId'));
                            that.get('cb')({
                                trigger: trigger,
                                target: tree.find('.catalog-target').data('id'),
                                path: tree.find('.catalog-target').data('path'),
                                name: tree.find('.catalog-target').data('name'),
                                idlist: tree.find('.catalog-target').data('idlist')
                            });
                        }, {
                            title: '',
                            closeTpl: '×',
                            width: that.get('width')
                        });
                    } else {
                        that.get('showBox')(html);
                    }
                    that._initTree();
                });
            }
        },
        _bindTriggers: function() {
            var that = this;
            if(that.get('parent').length > 0) {
                that.get('parent').on('click', that.get('trigger'),function(event){
                    event.preventDefault();
                    var trigger = $(this);
                    that._showTree(trigger);
                });
            } else {
                $(that.get('trigger')).on('click', function(event) {
                    event.preventDefault();
                    var trigger = $(this);
                    that._showTree(trigger);
                });
            }




        }
    });
    module.exports = catalogTree;
})