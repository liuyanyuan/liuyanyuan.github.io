define(function(require, exports, module) {
    var $ = require('$');
    var Uploader = require('upload');
    var Spin = require('spin');
    var Tip = require('../common/tip');
    require('jcrop');
    var browserInfo = null;
    var jc = null;
    var uploaderName = 'upfile';
    var spin = null;
    var uploader;
    var Confirmbox = require('confirmbox');
    var formatErr = false;





    exports.init = function(options) {

        jc = null;
        browserInfo = checkBrowser();

        /**
         * 上传头像
         */
        uploader = new Uploader({
            trigger: options.trigger,
            action: options.url,
            name: uploaderName,
            accept: 'image/*',
            multiple: false
        }).change(function(files) {

//                if(files[0].size > 5 * 1024 * 1024) {
//                    Confirmbox.show('图片大小超过5M，请上传小于5M的图片');
//                    this.refreshInput();
//                    formatErr = true;
//                    return false;
//                }

                $('[name="avatarData"]').data('x', '').data('y', '').data('w', '').data('h', '');
                if( browserInfo.Type == 'IE' && parseInt(browserInfo.Version) < 10 ) {
                    initJCinIE(this);
                }
                else {
                    initJCinNotIE(this, files);
                }

            }).success(function(result) {
                result = JSON.parse(result);
                if(result.success) {
                    options.callback(result);
                    jc.release();
                    jc.disable();
                    Tip.open('上传头像成功', 700);
                    //实时刷新大小头像
                    $('.avatar img').attr('src',$('.avatar img').attr('src')+'?'+Math.random());
                    $('.user-account-name img').attr('src',$('.user-account-name img').attr('src')+'?'+Math.random());

                } else {
                    Tip.open('上传头像失败，请重试', 700);
                }
                spin.stop();

            }).error(function(err) {
                console.log(err)
            });


        uploader._uploaders[0].form.css({
            top: 0,
            left: 0
        }).appendTo($(options.trigger));
    };

    exports.submit = uploadAvatar;

    /**
     * 检测浏览器版本，支持IE10 IE11
     * 暂时只检测了IE版本，其它浏览默认版本为100
     */
    function checkBrowser(){
        var ua = navigator.userAgent.toLocaleLowerCase();
        var browserType = '',
            browserVersion = '100';

        if( ua.match(/msie/) != null || ua.match(/trident/) != null){
            browserType = 'IE';
            browserVersion = ua.match(/msie ([\d.]+)/) != null ? ua.match(/msie ([\d.]+)/)[1] : ua.match(/rv ([\d.]+)/)[1];
        }else if(ua.match(/firefox/) != null){
            browserType = 'FIREFOX';
        }else if(ua.match(/opera/) != null){
            browserType = 'OPERA';
        }else if(ua.match(/chrome/) != null){
            browserType = 'CHROME';
        }else if(ua.match(/safari/) != null){
            browserType = 'SAFARI';
        }else{
            browserType = 'Other';
        }

        return {'Type':browserType,'Version':browserVersion}
    }

    /**
     * 初始化jcrop ie浏览器下
     */
    function initJCinIE(that) {


        $('[name='+ uploaderName + ']').select();
        var imgsrc = document.selection.createRange().text;
        var imgExt = imgsrc.substring(imgsrc.lastIndexOf('.') + 1);
        var cfe = checkFileExt(imgExt);
        if(!cfe.match) {
            Confirmbox.show(cfe.message);
            that.refreshInput();
            formatErr = true;
            return false;
        }
        formatErr = false;
        //当图片类型为GIF时，提醒用户不支持GIF动态图片效果
        if(imgsrc.indexOf('gif')>0){
            Tip.open('系统头像不支持GIF动态图片效果!',1000);
        }
        $('#avatarMain')
            .empty()
            .get(0).filters.item( 'DXImageTransform.Microsoft.AlphaImageLoader').src = imgsrc;
        $('#avatarPreview')
            .empty()
            .css({
                width: '100%',
                height:'100%',
                margin: 0
            })
            .get(0).filters.item( 'DXImageTransform.Microsoft.AlphaImageLoader').src = imgsrc;

        if(jc == null) {
            jc = $.Jcrop('#avatarMain', {
                aspectRatio:1,
                onChange:showCoords,
                onSelect:showCoords,
                bgColor: 'white',
                boxWidth: 275,
                boxHeight: 275
            });
        } else {
            jc.setImage(imgsrc);
            jc.enable();
        }
    }

    /**
     * 初始化jcrop 非ie浏览器下
     * @param files
     */
    function initJCinNotIE(that, files) {

        var cfe = checkFileExt(files[0].type);
        if(!cfe.match) {
            Confirmbox.show(cfe.message);
            that.refreshInput();
            formatErr = true;
            return false;
        }

        formatErr = false;
        var reader = new FileReader();
        reader.readAsDataURL(files[0]);
        reader.onload = function(e) {
            //当图片类型为GIF时，提醒用户不支持GIF动态图片效果
            if(files[0].type.indexOf('gif')>0){
                var imgText = unescape(atob(this.result.replace('data:image/gif;base64,','')));
                var chr = ''+
                    //String.fromCharCode(33)+
                    //String.fromCharCode(255)+
                    //String.fromCharCode(11)+
                    'NETSCAPE2.0';
                if(imgText.indexOf(chr)>0?true:false){
                    Tip.open('系统头像不支持GIF动态图片效果!',1000);
                }
            }

            var img = new Image();
            var that = this;
            img.onload = function() {
                $('#avatarMainImg').css({
                    'width': img.width + 'px',
                    'height': img.height + 'px'
                }).attr('src', that.result);
                $('#avatarPreviewImg').attr('src', that.result).css({
                    'width': '100%',
                    'height':'100%',
                    'margin': 0
                });
                if(jc == null) {
                    jc = $.Jcrop('#avatarMainImg', {
                        aspectRatio: 1,
                        onChange: showCoords,
                        onSelect: showCoords,
                        addClass: 'avatarJcrop',
                        bgColor: 'white',
                        boxWidth: 275,
                        boxHeight: 275
                    });
                } else {
                    jc.setImage(that.result);
                }
            }
            img.src = this.result;





        }
    }

    /**
     * 截取头像过程触发事件
     * @param obj
     */
    function showCoords(obj){
        var wrapper = null,
            main = null,
            preview = null;
        //当浏览器为IE其版本小于IE10时采用下面操作
        if(browserInfo.Type == 'IE' && parseInt(browserInfo.Version) < 10) {
            wrapper = $(".avatar-preview-wrapper");
            main = $("#avatarMain");
            preview = $("#avatarPreview");
        } else {
            wrapper = $(".avatar-preview");
            main = $("#avatarMainImg");
            preview = $("#avatarPreviewImg");
        }
        $('[name="avatarData"]').data('x', obj.x).data('y', obj.y).data('w', obj.w).data('h', obj.h);
        if(parseInt(obj.w) > 0){

            //计算预览区域图片缩放的比例，通过计算显示区域的宽度(与高度)与剪裁的宽度(与高度)之比得到
            var rx = wrapper.width() / obj.w;
            var ry = wrapper.height() / obj.h;

            //通过比例值控制图片的样式与显示
            preview.css({
                width:Math.round(rx * main.width()) + "px",	//预览图片宽度为计算比例值与原图片宽度的乘积
                height:Math.round(rx * main.height()) + "px",	//预览图片高度为计算比例值与原图片高度的乘积
                marginLeft:"-" + Math.round(rx * obj.x) + "px",
                marginTop:"-" + Math.round(ry * obj.y) + "px"
            });
        }
    }
    //判断图片格式
    function checkFileExt(imgExt) {
        var regex = (/jpg|jpeg|png|gif/i);
        if(!regex.test(imgExt)) {
            return {match: false, message: '上传图片格式错误，请上传JPG、JPEG、PNG、GIF(静态图)格式图片'}
        } else {
            return {match: true};
        }
    }

    /**
     * 上传头像
     * @param ele
     * @returns {boolean}
     */
    function uploadAvatar() {

        //防止用户上传不符合图片格式的头像
        if( formatErr ){
            return false;
        }

        var ele = $('[name="avatarData"]');
        spin = new Spin().spin(document.getElementById('avatarMain'));
        var obj = {};
        var sw = 275, sh = 275;
        //当为非IE或IE版本大于9时执行下面操作
        if( parseInt(browserInfo.Version) > 9 ) {
            sw = $('#avatarMainImg').width();
            sh = $('#avatarMainImg').height();
        }

        obj.x = parseInt(ele.data('x') || 0);
        obj.y = parseInt(ele.data('y') || 0);
        obj.width = parseInt(ele.data('w') || sw);
        obj.height = parseInt(ele.data('h') || sh);
        obj.sourceWidth = sw;
        obj.sourceHeight = sh;
        obj.displayWidth = 160;
        obj.displayHeight = 160;

        appendInput(obj);
        uploader.submit();
        return false;
    }

    /**
     * uploader增加表单数据
     * @param obj
     */
    function appendInput(obj) {
        var form = $('[name=' + uploaderName + ']').closest('form');
        $.each(obj, function(key, value) {
            if(form.find('[name=' + key + ']').length > 0) {
                form.find('[name=' + key + ']').val(value);
            } else {
                var input = $('<input type="hidden" name="' + key + '" value="' + value + '">');
                form.append(input);
            }

        });
    }


});


