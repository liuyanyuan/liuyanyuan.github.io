define(function(require, exports, module) {
    var constant = require('../constant');
    var $ = require('$');
    var Paging = require('../common/paging');
    var Tip = require('../common/tip');
    var Confirmbox = require('confirmbox');
    var Tab = require('./personal-tab');

    exports.init = function() {
        new Tab({element:$('.personal-qa-tab')});

        $('.ui-paging').each(function(i, obj) {
            new Paging({
                element: obj,
                url: constant.ROOT_PATH + 'users/questions/' + i,
                params: {limit: 1},
                targetId: 'qaBox',
                cb: function(data) {
                    if(i == 0) {

                        $('#publishQa').find('tbody').empty().html(data);
                    } else if(i == 1) {
                        console.log(data);
                        $('#replyQa').find('tbody').empty().html(data);
                    } else if(i == 2) {
                        $('#favouriteQa').find('tbody').empty().html(data);
                    }

                }
            })
        });
        $('.ui-table').on('click', '.qa-delete', function(event) {
            event.preventDefault();
            var ele = $(this),
                type = ele.data('type'),
                id = ele.data('id') || ele.data('answer-id'),
                tr = ele.closest('tr');

            Confirmbox.confirm('确定删除该问答？', '删除问答', function() {
                $.post(constant.ROOT_PATH + 'delete/question', {type: type, id: id}, function(result) {
                    if(result.success) {
                        Tip.open('删除成功',700);
                        tr.remove();
                    } else {
                        Tip.open('删除失败，请重试', 700);

                    }
                });
            }, {
                closeTpl: '×',
                hasMask: false,
                width: 400
            });
        });
    }

});