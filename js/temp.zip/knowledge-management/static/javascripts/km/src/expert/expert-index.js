/**
 * Created by yanyuan.liu on 14-6-26.
 */
define(function(require, exports, module) {
    var $ = require('$');
    var Confirmbox = require('confirmbox');
    var constant = require('../constant');
    var Tip = require('../common/tip');
    var Turntask = require('../common/turn-task');
    var questionToAsk = require('../question/toAsk');

    $(".expert-personnel-box").on("click","a",function(){
        var $this = $(this);
        var userId = $(this).parent().data("userid");
        var userName = $(this).parent().data("username");
        if($this.hasClass("toAsk")){
            $.get(constant.ROOT_PATH +'expert/addQuestion?type=2&userid='+userId+'&username='+userName,function(result){
                var comfirmbox = new Confirmbox({
                    title: '提问',
                    message: result,
                    width: 680,
                    cancelTpl: '',
                    confirmTpl: '',
                    closeTpl: 'X'
                }).show().after("hide", function () {
                    comfirmbox.destroy();
                });
                questionToAsk.initSelect_toAsk(2);
                $('#btn-submit').on('click', function () {
                    questionToAsk.addQuestion(2,comfirmbox);
                });
            })
        }
        if($this.hasClass("toTask")){
            Turntask.turnTask(
                {
                    tasktype: 3,//3 发任务
                    taskdata:{performers:{userId:userId,userName:userName}},
                    type: 1, //0:所有人必须完成 1:任意一人完成
                    cb:  function (result) {
                        if (result.success) {
                            Tip.open('任务求救成功！', 1000);
                        } else {
                            Tip.open('任务求救失败，请重试', 1000);
                        }
                    }
                }
            );
        }
    })

});
