define(function(require) {

  var km = require('../src/km');

  describe('km', function() {

    it('normal usage', function() {

    });
  });

});
