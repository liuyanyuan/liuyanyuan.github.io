# Demo

---

## Normal usage

````javascript
seajs.use('km', function(km) {

});
````
