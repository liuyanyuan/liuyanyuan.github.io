/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

define(function(require, exports, module){

    var layers = require('cqwrap/layers'),
        BaseScene = require('cqwrap/scenes').BaseScene;
    var GameLayer = layers.GameLayer, BgLayer = layers.BgLayer;
    var Button = require('cqwrap/buttons').Button;

    var UserData = require('cqwrap/data').UserData;
    var Audio = require('cqwrap/audio');

    var MyLayer = GameLayer.extend({

        init:function () {
            this._super();

            var cache = cc.SpriteFrameCache.getInstance();
            cache.addSpriteFrames("res/flappy_packer.plist", "res/flappy_packer.png");

            var ground = cc.createSprite('res/ground.png', {
                anchor: [0, 0],
                xy: [0, 0],
                zOrder: 3
            });

            ground.moveBy(0.5, cc.p(-120, 0)).moveBy(0, cc.p(120, 0)).repeatAll().act();

            this.addChild(ground);

            var ready = cc.createSprite('getready.png', {
                anchor: [0.5, 0],
                xy: [360 * 2, 780]
            });

            this.addChild(ready);

            var start = cc.createSprite('click.png', {
                anchor: [0.5, 0],
                xy: [360 * 2, 460]
            });

            this.addChild(start);

            var scoreSprite = cc.createSprite('@0', {
                anchor: [0.5, 0],
                xy: [360 * 2, 1000],
                fontSize: 64,
                zOrder: 10
            });

            this.addChild(scoreSprite);
            this.scoreSprite = scoreSprite;

            var bird = cc.createSprite('bird1.png', {
                anchor: [0.5, 0],
                xy: [220 * 2, 650],
                zOrder: 3
            });

            this.bird = bird;

            bird.animate(0.6, 'bird1.png', 'bird2.png', 'bird3.png').repeat().act();
            bird.moveBy(0.3, cc.p(0, -20)).reverse().repeatAll().act();

            this.addChild(bird);

            this.delegate(this);

            this.status = 'ready';

            var self = this;

            self.hoses = [];

            //其他小鸟集合，通过name去辨别，如 birds['kevin'] = bird
            self.birds = [];
            //其他小鸟的运动轨迹，防止数据没变化重复执行
            self.birdsTrack = [];

            //程序自动生成的固定random值，因为多人管道必须一样，不能每次都不一样
            self.randoms = [0.9558908399194479,0.16112179588526487,0.36758559313602746,0.9115350290667266,0.48178867739625275,0.8384827480185777,0.505022588884458,0.4668385658878833,0.4777647345326841,0.10499115753918886,0.44131848122924566,0.17273229476995766,0.40906124492175877,0.7580013971310109,0.9677456002682447,0.7777123767882586,0.36394078424200416,0.44456335599534214,0.3556021691765636,0.8350149872712791,0.17682229867205024,0.24362836102955043,0.7509427377954125,0.8261830797418952,0.8480422180145979,0.42361249099485576,0.66542077367194,0.34749547904357314,0.8411266168113798,0.9829325075261295,0.23063235636800528,0.41778310271911323,0.9825607896782458,0.4208069753367454,0.6781691645737737,0.16463241027668118,0.41963372891768813,0.9806786859408021,0.8471823646686971,0.5737284107599407,0.7342442793305963,0.8849243163131177,0.31522550457157195,0.1898917881771922,0.7719217396806926,0.1939962524920702,0.9028687502723187,0.06143612531013787,0.7965732137672603,0.7375237457454205,0.8941883305087686,0.5622211592271924,0.5141718371305615,0.4053016873076558,0.9837047830224037,0.3291249021422118,0.22595729609020054,0.9153752697166055,0.7059045990463346,0.20429467502981424,0.0905640225391835,0.8765404429286718,0.7826360177714378,0.11979564325883985,0.985473015345633,0.3142627580091357,0.6520129807759076,0.23084247601218522,0.22904522507451475,0.210396449547261,0.48713920055888593,0.5101544358767569,0.053683910286054015,0.04456675820983946,0.18061879673041403,0.4503705780953169,0.5363703996408731,0.06281265872530639,0.7885284661315382,0.7977419290691614,0.13086063438095152,0.41579724778421223,0.7076514326035976,0.8509069592691958,0.8094334278721362,0.006162914447486401,0.591713048517704,0.2330729691311717,0.9205077614169568,0.3927034605294466,0.06732471659779549,0.280339760472998,0.5705937668681145,0.41730761039070785,0.43382179317995906,0.07848331891000271,0.11204110481776297,0.14660718687810004,0.9708110790234059,0.6508343014866114];
            self.hoseIndex = 0;

            function createHose(dis){
                //cc.log('create hose '+self.hoseIndex);
                //获取固定random
                if(self.hoseIndex > self.randoms.length){
                    self.hoseIndex = 0;
                }
                var random = self.randoms[self.hoseIndex];
                self.hoseIndex++;
                //获取固定random结束

                var hoseHeight = 830;
                var acrossHeight = 250;
                var downHeight = 200 + (400 * random | 0);
                var upHeight = 1000 - downHeight - acrossHeight;
                
                var n = (self.hoses.length / 2) | 0;
                var hoseX = dis + 450 * n;

                var hoseDown = cc.createSprite('holdback1.png', {
                    anchor: [0.5, 0],
                    xy: [hoseX, 270 + downHeight - 830],
                });

                var hoseUp = cc.createSprite('holdback2.png', {
                    anchor: [0.5, 0],
                    xy: [hoseX, 270 + downHeight + acrossHeight],
                });

                self.addChild(hoseDown);
                self.addChild(hoseUp);

                var moveByDis = hoseX+500;

                hoseUp.moveBy(moveByDis/200, cc.p(-moveByDis, 0)).then(function(){
                    hoseUp.removeFromParent(true);
                }).act();
                hoseDown.moveBy(moveByDis/200, cc.p(-moveByDis, 0)).then(function(){
                    createHose(-500);
                    var idx = self.hoses.indexOf(hoseDown);
                    self.hoses.splice(idx, 2);
                    self.scoreBuf ++;
                    hoseDown.removeFromParent(true);
                }).act();
                self.hoses.push(hoseDown, hoseUp);
                
            };

            this.scoreBuf = 0;
            this.sc = 0;

            this.on('touchstart', function(){
                //cc.log('bird:', bird.getBoundingBox());
                Audio.playEffect('audio/sfx_wing.ogg')
                if(self.status == 'ready'){
                    for(var i = 0; i < 5; i++){
                        createHose(1200);
                    }

                    ready.fadeOut(0.5).act();
                    start.fadeOut(0.5).act();

                    //碰撞检测
                    self.checker = self.setInterval(function(){
                        //cc.log(111);
                        var sc = 0;

                        //这里可以用 boundingBox 的 上下左右的中间点来判断碰撞，会更准确一些
                        var box = bird.getBoundingBox();
                        var bottom = cc.p(box.x + box.width / 2, box.y);
                        var right = cc.p(box.x + box.width, box.y + box.height / 2);
                        var left = cc.p(box.x, box.y + box.height / 2);
                        var top = cc.p(box.x + box.width / 2, box.y + box.height);

                        self.hoses.some(function(hose){

                            if(self.status!='playing')return;//没在运行，不检查了

                            var box = hose.getBoundingBox();

                            if(hose.getPositionX() <= 220) sc ++;

                            //cc.log(score);

                            if(hose.getPositionX() > 0 && hose.getPositionX() < 720
                                //&& cc.rectIntersectsRect(hose.getBoundingBox(), bird.getBoundingBox())
                                && (cc.rectContainsPoint(box, left)
                                    || cc.rectContainsPoint(box, right)
                                    || cc.rectContainsPoint(box, top)
                                    || cc.rectContainsPoint(box, bottom))){
                                //cc.log([hose.getBoundingBox(), bird.getBoundingBox()]);
                                layerMask.fadeIn(0.1).fadeOut(0.1).act();
                                Audio.playEffect('audio/sfx_hit.ogg');
                                self.status = 'falling';
                                return true;
                            }
                        });

                        if(self.status == 'falling'){
                            self.clearInterval(self.checker);
                            //ground.stopAllActions();
                            /*
                            self.hoses.forEach(function(o){
                                //有其他bird,这里不stop hose的滚动
                                //o.stopAllActions();

                                //o.removeFromParent(true);
                            });*/
                        }

                        sc = Math.ceil(sc/2) + self.scoreBuf;

                        if(sc > self.sc){
                            self.sc = sc;
                            this.scoreSprite.setString(sc);
                            Audio.playEffect('audio/sfx_point.ogg');
                        }

                    }, 50)

                    self.status = 'playing';

                    //show other bird
                    setTimeout(function(){
                        cos.showOtherBird(self,cc);
                    },0)
                    //show other bird
                }
                if(self.status == 'playing'){
                    var birdX = bird.getPositionX();
                    var birdY = bird.getPositionY();
                    var fallTime = birdY / 1000;

                    bird.stopAllActions();
                    bird.animate(0.2, 'bird1.png', 'bird2.png', 'bird3.png').repeat().act();

                    var jumpHeight = Math.min(1280 - birdY, 120);
                    bird.moveBy(0.2, cc.p(0, jumpHeight), cc.EaseOut, 2).act();

                    bird.rotateTo(0.2, -20).act();
                    bird.delay(0.2).moveTo(fallTime, cc.p(birdX, 316), cc.EaseIn, 2)
                        .then(function(){
                            if(self.status == 'playing'){
                                //ground.stopAllActions();
                                /*
                                self.hoses.forEach(function(o){
                                    //有其他bird,这里不stop hose的滚动
                                    //o.stopAllActions();
                                    //o.removeFromParent(true);
                                });*/
                                layerMask.fadeIn(0.1).fadeOut(0.1).act();
                                Audio.playEffect('audio/sfx_hit.ogg');
                            }

                            cos.xycode(self , bird ,cc);

                            bird.stopAllActions();
                            self.status = 'gameover';

                            setTimeout(function(){
                                self.onGameOver();
                            }, 200)
                        }).act();
                    bird.delay(0.5).rotateTo(fallTime - 0.3, 90, 0, cc.EaseIn, 2).act();

                    //when touch action
                    if(!bird.clickCount){
                        bird.clickCount= 0 ;
                    }

                    cos.us(self,bird ,cc);

                    bird.clickCount++;
                    //when touch action end
                }
            });

            var label = cc.createSprite('@技术支持部-KM知识库-游戏中心', {
                anchor: [0.5, 0.5],
                xy: [1500, 80],
                fontSize: 44,
                zOrder: 99,
                color: '#0B75E6',
                font:'微软雅黑'
            });

            this.addChild(label);

            var layerMask = cc.LayerColor.create(cc.c4b(255,255,255, 255));
            layerMask.setZOrder(88);
            layerMask.setOpacity(0);
            this.addChild(layerMask);
            this.layerMask = layerMask;

            //load the top list
            cos.qtl(self,cc);
            cos.qob(self,cc);
            this.preInitGameOver();
            //load top list end

            return true;
        },
        backClicked: function(){
            director.end();
            //director.popScene();
        },
        preInitGameOver:function(){//将生成gameOver的资源提前创建，减少在游戏过程中对其他bird轨迹的影响
            var self = this;

            //加长版长度
            var widthChange = 400;

            var bestScore = UserData.get('best', 0);
            self.bestScore = cc.createSprite('@'+bestScore, {
                anchor: [0.5, 0],
                xy: [550 + widthChange, 555],
                fontSize: 64,
                zOrder: 10,
                opacity: 0,
            });

            //bestScore.delay(0.7).fadeIn(0.1).act();
            //this.addChild(bestScore);

            self.gameOver = cc.createSprite('gameover.png', {
                anchor: [0.5, 0],
                xy: [360 + widthChange, 850],
                zOrder: 5
            });

            //gameOver.moveBy(0.1, cc.p(0, 10)).reverse().act();

            //this.addChild(gameOver);

            self.scoreSpriteBase = cc.createSprite('base.png', {
                anchor: [0.5, 0],
                xy: [360 +widthChange, -520],
                zOrder: 5
            });

            //scoreSprite.delay(0.5).moveTo(0.2, cc.p(360 + widthChange, 520)).act();

            //this.addChild(scoreSprite);

            self.clickButton = new Button({
                texture: 'start.png',
                anchor: [0, 0],
                xy: [70 + widthChange, 256],
                zOrder: 5
            }, function(){
                //cc.log('aaa');
                director.replaceScene(cc.TransitionFade.create(0.5, new MyScene()));
            });

            self.clickButton.getContentSprite().setOpacity(0);
            //clickButton.getContentSprite().delay(0.8).fadeIn(0.1).act();

            //this.addChild(clickButton);

            var layerObj = this;
            self.gradeButton = new Button({
                texture: 'grade.png',
                anchor: [0, 0],
                xy: [370 + widthChange, 256],
                zOrder: 5
            }, function(){
                //load the top list
                cos.qtl(layerObj,cc);
                //load top list end
            });

            self.gradeButton.getContentSprite().setOpacity(0);
            //gradeButton.getContentSprite().delay(0.8).fadeIn(0.1).act();


            self.goldMedal = cc.createSprite( 'gold.png', {
                    anchor: [0.5, 0.5],
                    xy: [191 + widthChange, 651],
                    zOrder: 5
                });

            self.silverMedal = cc.createSprite( 'silver.png', {
                    anchor: [0.5, 0.5],
                    xy: [191 + widthChange, 651],
                    zOrder: 5
                });

            self.hahaText = ['@哎哟，简直弱！爆！了！^_V',
                '@继续努力吧，骚年~~~',
                '@智商是硬伤O(∩_∩)O~',
                '@小撸怡情，大撸伤身，强撸。。你懂的。。。',
                '@你这么*你父母知道么⊙﹏⊙b汗',
                '@哎呀呀，好腻害 ( ⊙o⊙ )',
                '@吓尿了( ⊙ o ⊙ )！',
                '@被鸟虐得好可怜，(*^__^*) 嘻嘻……'
            ];
            self.tetTemp = self.hahaText[((Math.random()*100 % self.hahaText.length)+'').substring(0,1)];

            self.hahaLabel = cc.createSprite(self.tetTemp, {
                anchor: [0.5, 0.5],
                xy: [362 * 2, 180],
                fontSize: 44,
                zOrder: 99,
                color: '#E64D0B',
                font:'微软雅黑'
            });
        },
        onGameOver: function(){
            cc.log('gameover');

            //加长版长度
            var widthChange = 400;

            this.scoreSprite.fadeOut(0.1).moveTo(0.6, cc.p(550 + widthChange, 665)).fadeIn(0.1).act();

            var bestScore = UserData.get('best', 0);
            if(this.score > bestScore){
                bestScore = this.score;
                UserData.set('best', bestScore);
            }

            var self = this;

            self.bestScore.delay(0.7).fadeIn(0.1).act();
            this.addChild(self.bestScore);

            self.gameOver.moveBy(0.1, cc.p(0, 10)).reverse().act();

            this.addChild(self.gameOver);

            self.scoreSpriteBase.delay(0.3).moveTo(0.2, cc.p(360 + widthChange, 520)).act();

            this.addChild(self.scoreSpriteBase);

            self.clickButton.getContentSprite().delay(0.3).fadeIn(0.1).act();

            this.addChild(self.clickButton);

            var layerObj = this;
            self.gradeButton.getContentSprite().delay(0.3).fadeIn(0.1).act();

            if(this.score >= 10){
                var material = this.score >= 20 ?self.goldMedal : self.silverMedal ;

                this.setTimeout(function(){
                    this.addChild(material);
                }, 800);
            }

            this.addChild(self.gradeButton);

            this.addChild(self.hahaLabel);

            //upload
            cos.fs(layerObj,layerObj.bird,cc);
            //end upload
        }
    });

    var MyScene = BaseScene.extend({
        init:function () {
            this._super();

            var bg = new BgLayer("res/bg.png");
            this.addChild(bg);

            var layer = new MyLayer();
            this.addChild(layer);
        }
    });

    module.exports = MyScene;
});


