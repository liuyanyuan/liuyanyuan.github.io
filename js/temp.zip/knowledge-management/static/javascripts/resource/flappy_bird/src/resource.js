var g_resources = [
    //image
    {src: "res/flappy_packer.png"},
    {src: "res/bg.png"},
    {src: "res/ground.png"},

    //plist
    {src: "res/flappy_packer.plist"},
    {src: "res/flappy_frame.plist"}
    
    //fnt

    //tmx

    //bgm

    //effect
];