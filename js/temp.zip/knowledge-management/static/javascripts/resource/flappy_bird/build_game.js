{      
    baseUrl: ".",    
    name: "./main-src",
    out: "main.min.js",
    removeCombined: true,
    //exclude: [ "cqwrap/index.js" ]
}