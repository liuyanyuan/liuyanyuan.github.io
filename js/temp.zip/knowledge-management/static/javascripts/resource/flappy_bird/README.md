flappy_bird
===========

flappy bird using [cocos2d-html5](https://github.com/cocos2d/cocos2d-html5) and [cqwrap](http://go.akira-cn.gitpress.org/)
