{      
    baseUrl: ".",    
    name: "cqwrap/index",
    out: "cqwrap-min.js",
    removeCombined: true,
}