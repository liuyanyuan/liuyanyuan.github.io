python -m SimpleHTTPServer
